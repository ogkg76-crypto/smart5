export type Language = 'ar' | 'en';
export type ThemeMode = 'light' | 'dark';
export type AccentTheme = 'electric' | 'purple' | 'emerald' | 'amber';
export type FontScale = 'sm' | 'md' | 'lg';
export type TutorPersona = 'professor' | 'simple' | 'exam_coach' | 'coding_mentor';

export type NavSection =
  | 'dashboard'
  | 'library'
  | 'tutor'
  | 'summaries'
  | 'exams'
  | 'flashcards'
  | 'mindmaps'
  | 'planner'
  | 'whiteboard'
  | 'coding'
  | 'progress'
  | 'profile';

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  college?: string;
  department?: string;
  academicYear?: string;
  semester?: string;
  planId: string;
  aiRequestsUsed: number;
  storageBytesUsed: number;
  studyHoursLogged: number;
  preferredLang: Language;
  themeMode: ThemeMode;
  accentTheme?: AccentTheme;
  fontScale?: FontScale;
  defaultPersona?: TutorPersona;
  explanationLang?: Language;
  voiceSpeed?: number;
  xpPoints?: number;
  streakDays?: number;
  lastStudyDate?: string;
  showOnLeaderboard?: boolean;
  notifStudyReminders?: boolean;
  notifExamAlerts?: boolean;
  notifAiReady?: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Subject {
  id: string;
  ownerId: string;
  name: string;
  code?: string;
  college?: string;
  department?: string;
  semester: string;
  academicYear?: string;
  colorToken?: string;
  understandingLevel: 'low' | 'medium' | 'high';
  priority: 'low' | 'medium' | 'high';
  examDate?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Folder {
  id: string;
  ownerId: string;
  subjectId: string;
  name: string;
  createdAt?: unknown;
}

export interface ExtractedPage {
  pageNumber: number;
  heading: string;
  content: string;
  timestamp?: string;
}

export type LectureFileType = 'pdf' | 'docx' | 'pptx' | 'image' | 'text' | 'audio' | 'video';

export interface Lecture {
  id: string;
  ownerId: string;
  subjectId: string;
  folderId?: string;
  title: string;
  fileName: string;
  fileType: LectureFileType;
  fileSizeBytes: number;
  semester?: string;
  progressPercent: number;
  lastPageRead: number;
  totalPages: number;
  extractedPages: ExtractedPage[];
  fullTextPreview: string;
  analysisStatus: 'ready' | 'processing' | 'error';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type ExplanationLevel = 'beginner' | 'intermediate' | 'advanced' | 'revision';

export interface ExplanationSection {
  title: string;
  sourcePage: string;
  simplifiedArabic: string;
  englishTerms: { term: string; meaning: string }[];
  practicalExample: string;
  codeOrFormula?: string;
  conceptComparison?: string;
}

export interface LectureExplanation {
  id: string;
  ownerId: string;
  lectureId: string;
  subjectId: string;
  level: ExplanationLevel;
  persona?: TutorPersona;
  overview: string;
  sections: ExplanationSection[];
  createdAt?: unknown;
}

export type SummaryDetailLevel = 'short' | 'medium' | 'detailed';

export interface LectureSummary {
  id: string;
  ownerId: string;
  lectureId: string;
  subjectId: string;
  title: string;
  detailLevel: SummaryDetailLevel;
  contentMarkdown: string;
  keyPoints?: string[];
  definitions?: { term: string; definition: string }[];
  formulas?: { name: string; expression: string; note?: string }[];
  comparisons?: { topicA: string; topicB: string; difference: string }[];
  revisionAlerts?: string[];
  isShared?: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type QuestionType =
  | 'mcq'
  | 'true_false'
  | 'fill_blank'
  | 'essay'
  | 'practical'
  | 'programming'
  | 'definition'
  | 'comparison';

export interface ExamQuestion {
  id: string;
  type: QuestionType;
  topic: string;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  sourceCitation: string;
  userAnswer?: string;
  isCorrect?: boolean;
  aiScore?: number;
  aiFeedback?: string;
}

export interface ExamAttempt {
  id: string;
  ownerId: string;
  subjectId: string;
  lectureIds: string[];
  title: string;
  difficulty: 'easy' | 'medium' | 'hard';
  durationMinutes: number;
  status: 'in_progress' | 'completed';
  scorePercent: number;
  totalQuestions: number;
  correctCount: number;
  questions: ExamQuestion[];
  weakTopics?: string[];
  strongTopics?: string[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Flashcard {
  id: string;
  ownerId: string;
  subjectId: string;
  lectureId?: string;
  front: string;
  back: string;
  imageUrl?: string;
  easeFactor: number;
  intervalDays: number;
  repetitions: number;
  nextReviewAt: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface MindMapNode {
  id: string;
  label: string;
  category: 'root' | 'topic' | 'subtopic' | 'definition' | 'formula' | 'classification';
  detail?: string;
  children?: MindMapNode[];
}

export interface MindMapDoc {
  id: string;
  ownerId: string;
  subjectId: string;
  lectureId: string;
  title: string;
  rootNodeJson: MindMapNode;
  createdAt?: unknown;
}

export interface StudyPlanTask {
  id: string;
  ownerId: string;
  subjectId?: string;
  subjectName: string;
  title: string;
  scheduledDate: string;
  durationMinutes: number;
  taskType: 'lecture' | 'review' | 'practice';
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ChatCitation {
  lectureTitle: string;
  page: string;
  excerpt: string;
}

export interface ChatMessageRecord {
  id: string;
  ownerId: string;
  subjectId?: string;
  lectureId?: string;
  sourceMode: 'lecture' | 'subject' | 'general';
  persona?: TutorPersona;
  role: 'user' | 'assistant';
  text: string;
  citations?: ChatCitation[];
  createdAt?: unknown;
}

export interface PodcastScriptLine {
  speaker: 'Professor' | 'Student';
  text: string;
}

export interface PodcastEpisode {
  id: string;
  ownerId: string;
  lectureId: string;
  subjectId: string;
  title: string;
  lengthMode: 'short' | 'long';
  lang: Language;
  summaryText?: string;
  scriptLines: PodcastScriptLine[];
  createdAt?: unknown;
}

export interface MistakeEntry {
  id: string;
  ownerId: string;
  subjectId: string;
  subjectName: string;
  examId?: string;
  topic: string;
  question: string;
  wrongAnswer: string;
  correctAnswer: string;
  explanation: string;
  mastered: boolean;
  reviewCount: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type WhiteboardAiMode = 'solve' | 'equation' | 'diagram' | 'ocr' | 'check';

export interface WhiteboardDoc {
  id: string;
  ownerId: string;
  subjectId?: string;
  title: string;
  aiMode: WhiteboardAiMode;
  snapshotDataUrl: string;
  aiAnalysis: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type CodingLanguage = 'python' | 'javascript' | 'c' | 'cpp' | 'java';

export interface CodingProject {
  id: string;
  ownerId: string;
  subjectId?: string;
  title: string;
  language: CodingLanguage;
  code: string;
  lastOutput: string;
  aiReview?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface BattleParticipant {
  uid: string;
  name: string;
  score: number;
  finishedAt: string;
}

export interface StudyBattle {
  id: string;
  ownerId: string;
  ownerName: string;
  title: string;
  subjectName: string;
  difficulty: 'easy' | 'medium' | 'hard';
  durationMinutes: number;
  status: 'open' | 'active' | 'finished';
  questions: ExamQuestion[];
  participants: BattleParticipant[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface GroupDiscussionMessage {
  id: string;
  ownerId: string;
  ownerName: string;
  groupId: string;
  text: string;
  createdAt?: unknown;
}

export interface StudyGroup {
  id: string;
  ownerId: string;
  ownerName: string;
  name: string;
  subjectName: string;
  description?: string;
  isPublic: boolean;
  memberCount: number;
  createdAt?: unknown;
}

export interface SharedResource {
  id: string;
  ownerId: string;
  ownerName: string;
  groupId: string;
  resourceType: 'summary' | 'quiz' | 'challenge';
  title: string;
  subjectName: string;
  contentPreview: string;
  consentConfirmed: boolean;
  createdAt?: unknown;
}

export interface ChallengeScore {
  id: string;
  ownerId: string;
  studentName: string;
  groupId: string;
  challengeTitle: string;
  score: number;
  createdAt?: unknown;
}

export interface ContentReport {
  id: string;
  reporterId: string;
  targetType: 'group' | 'resource' | 'other';
  targetId: string;
  reason: string;
  status: 'open' | 'resolved' | 'dismissed';
  createdAt?: unknown;
}

export interface AppNotification {
  id: string;
  ownerId: string;
  title: string;
  body: string;
  category: 'study' | 'exam' | 'ai' | 'system';
  isRead: boolean;
  createdAt?: unknown;
}

export interface SubscriptionPlan {
  id: string;
  nameAr: string;
  nameEn: string;
  priceMonthly: number;
  currency: string;
  aiRequestLimit: number;
  storageLimitMb: number;
  featuresAr?: string[];
  featuresEn?: string[];
  discountPercent?: number;
  isActive: boolean;
  updatedAt?: unknown;
}

export interface PaymentRecord {
  id: string;
  ownerId: string;
  userEmail: string;
  planId: string;
  planName: string;
  amount: number;
  currency: string;
  promoCode?: string;
  status: 'paid' | 'refunded' | 'pending';
  createdAt?: unknown;
}

export interface PromoCode {
  id: string;
  code: string;
  discountPercent: number;
  isActive: boolean;
  updatedAt?: unknown;
}

export interface SystemLog {
  id: string;
  userId: string;
  source: string;
  message: string;
  severity: 'info' | 'warn' | 'error';
  createdAt?: unknown;
}

// ============================================================
// SMART STUDENT DEVELOPER CONTROL CENTER TYPES
// ============================================================

export type AdminRoleType = 'owner' | 'admin' | 'support' | 'content_manager';

export type DevNavSection =
  | 'overview'
  | 'users'
  | 'subscriptions'
  | 'ai_control'
  | 'features'
  | 'content'
  | 'notifications'
  | 'support'
  | 'analytics'
  | 'monitoring'
  | 'audit_logs'
  | 'backups'
  | 'cost_simulator'
  | 'app_settings'
  | 'profile';

export interface DevSessionUser {
  id: string;
  email: string;
  displayName: string;
  role: AdminRoleType;
  permissions: string[];
  mustChangePassword: boolean;
  twoFactorEnabled: boolean;
}

export interface ControlUserRecord {
  uid: string;
  displayName: string;
  email: string;
  planId: string;
  status: 'active' | 'suspended';
  aiRequestsUsed: number;
  storageBytesUsed: number;
  lecturesCount: number;
  examsCount: number;
  summariesCount: number;
  flashcardsCount: number;
  studyHoursLogged: number;
  premiumGiftUntil?: string;
  lastLoginAt: string;
  createdAt: string;
  activityHistory: { at: string; action: string }[];
}

export interface ControlPlanConfig {
  id: string;
  nameAr: string;
  nameEn: string;
  priceMonthly: number;
  durationDays: number;
  currency: string;
  aiRequestLimit: number;
  storageLimitMb: number;
  maxFilesCount: number;
  maxExamsCount: number;
  featuresAr: string[];
  featuresEn: string[];
  discountPercent: number;
  googlePlayProductId?: string;
  isActive: boolean;
}

export interface ControlPromoConfig {
  code: string;
  discountPercent: number;
  maxUses: number;
  usedCount: number;
  expiresAt?: string;
  isActive: boolean;
}

export interface ControlPaymentRecord {
  id: string;
  uid: string;
  userEmail: string;
  planId: string;
  planName: string;
  amount: number;
  currency: string;
  provider: 'google_play' | 'promo' | 'manual';
  purchaseToken?: string;
  verifiedByBackend: boolean;
  promoCode?: string;
  status: 'paid' | 'refunded' | 'pending';
  createdAt: string;
}

export interface AiServiceConfig {
  id: string;
  name: string;
  provider: 'gemini' | 'openai' | 'anthropic';
  model: string;
  enabled: boolean;
  maxFileSizeMb: number;
  maxLectureLength: number;
  perUserDailyLimit: number;
  allowedPlans: string[];
  dailyBudgetUsd: number;
  monthlyBudgetUsd: number;
  autoStopOnBudget: boolean;
  successCount: number;
  failedCount: number;
  totalLatencyMs: number;
  estimatedCostUsd: number;
}

export interface FeatureFlagConfig {
  id: string;
  nameAr: string;
  nameEn: string;
  status: 'all' | 'plans' | 'beta' | 'maintenance' | 'disabled';
  allowedPlans: string[];
  betaEmails: string[];
  maintenanceMessageAr: string;
  maintenanceMessageEn: string;
  usageCount: number;
}

export type ContentKind =
  | 'university'
  | 'college'
  | 'major'
  | 'year'
  | 'cohort'
  | 'semester'
  | 'subject'
  | 'lecture'
  | 'exam'
  | 'summary';

export interface AcademicContentNode {
  id: string;
  kind: ContentKind;
  title: string;
  parentName?: string;
  category?: string;
  status: 'published' | 'hidden' | 'failed';
  sharedByStudent?: boolean;
  meta?: string;
  createdAt: string;
}

export interface TargetedNotificationRecord {
  id: string;
  target: 'all' | 'free' | 'pro' | 'elite' | 'user' | 'group';
  targetValue?: string;
  title: string;
  body: string;
  imageUrl?: string;
  linkSection?: string;
  scheduledFor?: string;
  status: 'sent' | 'scheduled';
  recipientCount: number;
  openedCount: number;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  ownerUid: string;
  ownerName: string;
  ownerEmail: string;
  category: 'login' | 'subscriptions' | 'lectures' | 'ai' | 'payment' | 'bug' | 'suggestion';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  subject: string;
  message: string;
  reply?: string;
  internalNote?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogEntry {
  id: string;
  actorEmail: string;
  actorRole: AdminRoleType;
  action: string;
  target: string;
  details: string;
  status: 'success' | 'denied' | 'failed';
  createdAt: string;
}

export interface BackupSnapshotInfo {
  id: string;
  label: string;
  sizeBytes: number;
  createdBy: string;
  createdAt: string;
}

export interface AppSettingsConfig {
  appName: string;
  appDescription: string;
  logoUrl: string;
  officialEmail: string;
  socialWebsite: string;
  socialTwitter: string;
  socialTelegram: string;
  privacyPolicyText: string;
  termsOfServiceText: string;
  androidStoreUrl: string;
  iosStoreUrl: string;
  availableLanguages: Language[];
  maxFileSizeMb: number;
  maintenanceMode: boolean;
  minVersion: string;
  forceUpdateMessage: string;
  backupSchedule: 'manual' | 'daily' | 'weekly';
  retentionCount: number;
}

export interface AdminAccountPublic {
  id: string;
  email: string;
  displayName: string;
  role: AdminRoleType;
  permissions: string[];
  twoFactorEnabled: boolean;
  lastLoginAt?: string;
  createdAt: string;
}

export interface PublicRuntimeConfig {
  featureFlags: Record<string, FeatureFlagConfig>;
  plans?: SubscriptionPlan[];
  appSettings: {
    appName: string;
    appDescription: string;
    officialEmail: string;
    maxFileSizeMb: number;
    maintenanceMode: boolean;
    minVersion: string;
    forceUpdateMessage: string;
    availableLanguages: Language[];
    privacyPolicyText: string;
    termsOfServiceText: string;
  };
}

