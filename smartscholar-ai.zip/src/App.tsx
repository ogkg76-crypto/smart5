import React, { useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, doc, onSnapshot, query, where } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import {
  AccentTheme,
  AppNotification,
  ChallengeScore,
  ChatMessageRecord,
  CodingProject,
  DevSessionUser,
  ExamAttempt,
  Flashcard,
  Folder,
  FontScale,
  Language,
  Lecture,
  LectureExplanation,
  LectureSummary,
  MindMapDoc,
  MistakeEntry,
  NavSection,
  PodcastEpisode,
  PublicRuntimeConfig,
  SharedResource,
  StudyBattle,
  StudyGroup,
  StudyPlanTask,
  Subject,
  SubscriptionPlan,
  ThemeMode,
  UserProfile,
  WhiteboardDoc,
} from './types';
import { t } from './i18n';
import {
  ensureUserProfile,
  updateUserPreferences,
} from './services/firestoreHelpers';
import { fetchPublicRuntimeConfig, syncStudentTelemetry } from './services/api';
import { AuthGate } from './components/AuthGate';
import { DeveloperControlCenter } from './components/DeveloperControlCenter';
import { DashboardView, NavigateOptions } from './components/DashboardView';
import { LibraryView } from './components/LibraryView';
import { TutorView } from './components/TutorView';
import { SummariesView } from './components/SummariesView';
import { ExamsView } from './components/ExamsView';
import { FlashcardsView } from './components/FlashcardsView';
import { MindMapsView } from './components/MindMapsView';
import { PlannerView } from './components/PlannerView';
import { WhiteboardView } from './components/WhiteboardView';
import { CodingPlaygroundView } from './components/CodingPlaygroundView';
import { ProgressSocialView } from './components/ProgressSocialView';
import { ProfileBillingView } from './components/ProfileBillingView';
import { SmartSearchModal } from './components/SmartSearchModal';
import {
  LayoutDashboard,
  FolderKanban,
  Brain,
  FileText,
  GraduationCap,
  Layers,
  GitBranch,
  Calendar,
  PenTool,
  Code2,
  BarChart3,
  User as UserIcon,
  Shield,
  Menu,
  X,
  Globe,
  Moon,
  Sun,
  Bell,
  BookOpen,
  Search,
  Sparkles,
} from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [theme, setTheme] = useState<ThemeMode>('dark');
  const [accentTheme, setAccentTheme] = useState<AccentTheme>('electric');
  const [fontScale, setFontScale] = useState<FontScale>('md');
  const [authReady, setAuthReady] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [, setAuthReloadTick] = useState(0);
  const [section, setSection] = useState<NavSection>('dashboard');

  // Deep-link navigation state
  const [contextLectureId, setContextLectureId] = useState<string | undefined>(undefined);
  const [contextPageNumber, setContextPageNumber] = useState<number | undefined>(undefined);
  const [contextTutorTab, setContextTutorTab] = useState<NavigateOptions['tutorTab']>(undefined);
  const [contextSummaryMode, setContextSummaryMode] =
    useState<NavigateOptions['summaryMode']>(undefined);
  const [contextExamMode, setContextExamMode] = useState<NavigateOptions['examMode']>(undefined);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const prefsHydratedRef = useRef(false);

  // Firestore synced state
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [lectures, setLectures] = useState<Lecture[]>([]);
  const [explanations, setExplanations] = useState<LectureExplanation[]>([]);
  const [summaries, setSummaries] = useState<LectureSummary[]>([]);
  const [exams, setExams] = useState<ExamAttempt[]>([]);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [mindMaps, setMindMaps] = useState<MindMapDoc[]>([]);
  const [studyPlans, setStudyPlans] = useState<StudyPlanTask[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessageRecord[]>([]);
  const [podcasts, setPodcasts] = useState<PodcastEpisode[]>([]);
  const [mistakes, setMistakes] = useState<MistakeEntry[]>([]);
  const [whiteboards, setWhiteboards] = useState<WhiteboardDoc[]>([]);
  const [codingProjects, setCodingProjects] = useState<CodingProject[]>([]);
  const [studyGroups, setStudyGroups] = useState<StudyGroup[]>([]);
  const [sharedResources, setSharedResources] = useState<SharedResource[]>([]);
  const [challengeScores, setChallengeScores] = useState<ChallengeScore[]>([]);
  const [studyBattles, setStudyBattles] = useState<StudyBattle[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);

  // In-memory only Developer Control Center session (never persisted to web storage)
  const [devToken, setDevToken] = useState<string | null>(null);
  const [devSession, setDevSession] = useState<DevSessionUser | null>(null);

  // Live Runtime Configuration & Student Account Status / Toast Inbox
  const [runtimeConfig, setRuntimeConfig] = useState<PublicRuntimeConfig | null>(null);
  const [planOverride, setPlanOverride] = useState<string | null>(null);
  const [studentSuspended, setStudentSuspended] = useState(false);
  const [adminBroadcasts, setAdminBroadcasts] = useState<
    { id: string; title: string; body: string; createdAt: string }[]
  >([]);

  // Sync HTML attributes (lang, dir, .dark, data-accent, data-font-scale)
  useEffect(() => {
    const html = document.documentElement;
    html.lang = lang;
    html.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  useEffect(() => {
    const html = document.documentElement;
    if (theme === 'dark') html.classList.add('dark');
    else html.classList.remove('dark');
  }, [theme]);

  useEffect(() => {
    document.documentElement.setAttribute('data-accent', accentTheme);
  }, [accentTheme]);

  useEffect(() => {
    document.documentElement.setAttribute('data-font-scale', fontScale);
  }, [fontScale]);

  // Global Cmd/Ctrl + K shortcut for Smart Search
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        if (firebaseUser?.emailVerified) {
          e.preventDefault();
          setSearchOpen((prev) => !prev);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [firebaseUser]);

  // Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      setAuthReady(true);
      if (!user) {
        prefsHydratedRef.current = false;
        setProfile(null);
        setPlanOverride(null);
      } else if (user.emailVerified) {
        await ensureUserProfile({
          uid: user.uid,
          displayName: user.displayName || user.email?.split('@')[0] || 'Student',
          email: user.email || '',
          photoURL: user.photoURL || '',
          preferredLang: lang,
          themeMode: theme,
        });
      }
    });
    return () => unsub();
  }, []);

  // Firestore real-time listeners (guarded behind verified user)
  useEffect(() => {
    if (!authReady || !firebaseUser || !firebaseUser.emailVerified) return;
    const uid = firebaseUser.uid;
    const unsubs: (() => void)[] = [];

    unsubs.push(
      onSnapshot(
        doc(db, 'users', uid),
        (snap) => {
          if (snap.exists()) {
            const data = snap.data() as UserProfile;
            setProfile(data);
            if (!prefsHydratedRef.current) {
              prefsHydratedRef.current = true;
              if (data.preferredLang === 'ar' || data.preferredLang === 'en') {
                setLang(data.preferredLang);
              }
              if (data.themeMode === 'dark' || data.themeMode === 'light') {
                setTheme(data.themeMode);
              }
              if (
                data.accentTheme === 'electric' ||
                data.accentTheme === 'purple' ||
                data.accentTheme === 'emerald' ||
                data.accentTheme === 'amber'
              ) {
                setAccentTheme(data.accentTheme);
              }
              if (data.fontScale === 'sm' || data.fontScale === 'md' || data.fontScale === 'lg') {
                setFontScale(data.fontScale);
              }
            }
          }
        },
        (err) => handleFirestoreError(err, OperationType.GET, `users/${uid}`)
      )
    );

    const bindOwned = <T,>(
      colName: string,
      setter: React.Dispatch<React.SetStateAction<T[]>>
    ) => {
      const q = query(collection(db, colName), where('ownerId', '==', uid));
      unsubs.push(
        onSnapshot(
          q,
          (snap) => {
            setter(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as T));
          },
          (err) => handleFirestoreError(err, OperationType.LIST, colName)
        )
      );
    };

    bindOwned<Subject>('subjects', setSubjects);
    bindOwned<Folder>('folders', setFolders);
    bindOwned<Lecture>('lectures', setLectures);
    bindOwned<LectureExplanation>('explanations', setExplanations);
    bindOwned<LectureSummary>('summaries', setSummaries);
    bindOwned<ExamAttempt>('exams', setExams);
    bindOwned<Flashcard>('flashcards', setFlashcards);
    bindOwned<MindMapDoc>('mindmaps', setMindMaps);
    bindOwned<StudyPlanTask>('studyPlans', setStudyPlans);
    bindOwned<ChatMessageRecord>('chatSessions', setChatMessages);
    bindOwned<PodcastEpisode>('podcasts', setPodcasts);
    bindOwned<MistakeEntry>('mistakes', setMistakes);
    bindOwned<WhiteboardDoc>('whiteboards', setWhiteboards);
    bindOwned<CodingProject>('codingProjects', setCodingProjects);
    bindOwned<AppNotification>('notifications', setNotifications);

    // Public/shared collections matching rule invariants
    unsubs.push(
      onSnapshot(
        query(collection(db, 'studyGroups'), where('isPublic', '==', true)),
        (snap) => setStudyGroups(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as StudyGroup)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'studyGroups')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'sharedResources'), where('consentConfirmed', '==', true)),
        (snap) =>
          setSharedResources(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as SharedResource)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'sharedResources')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'challengeScores'), where('score', '>=', 0)),
        (snap) =>
          setChallengeScores(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as ChallengeScore)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'challengeScores')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'studyBattles'), where('status', 'in', ['open', 'active', 'finished'])),
        (snap) =>
          setStudyBattles(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as StudyBattle)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'studyBattles')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'subscriptionPlans'), where('isActive', '==', true)),
        (snap) => setPlans(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as SubscriptionPlan)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'subscriptionPlans')
      )
    );

    return () => unsubs.forEach((u) => u());
  }, [authReady, firebaseUser]);

  // Poll public runtime config (feature flags + maintenance mode)
  useEffect(() => {
    const loadRuntime = () => {
      fetchPublicRuntimeConfig().then(setRuntimeConfig).catch(() => {});
    };
    loadRuntime();
    const timer = setInterval(loadRuntime, 45000);
    return () => clearInterval(timer);
  }, []);

  // Sync student telemetry & receive Admin notifications / account status / plan override
  useEffect(() => {
    if (!firebaseUser?.emailVerified) {
      setStudentSuspended(false);
      return;
    }
    const timer = setTimeout(() => {
      syncStudentTelemetry({
        displayName: profile?.displayName || firebaseUser.displayName || undefined,
        email: firebaseUser.email || undefined,
        planId: profile?.planId || 'free',
        aiRequestsUsed: profile?.aiRequestsUsed || 0,
        storageBytesUsed: profile?.storageBytesUsed || 0,
        lecturesCount: lectures.length,
        examsCount: exams.length,
        summariesCount: summaries.length,
        flashcardsCount: flashcards.length,
        studyHoursLogged: Number(
          (
            studyPlans.filter((t) => t.status === 'completed').reduce((s, t) => s + t.durationMinutes, 0) / 60
          ).toFixed(1)
        ),
        recentSubjects: subjects.slice(0, 15).map((s) => ({
          id: s.id,
          name: s.name,
          college: s.college,
          semester: s.semester,
        })),
        recentLectures: lectures.slice(0, 20).map((l) => ({
          id: l.id,
          title: l.title,
          fileType: l.fileType,
          analysisStatus: l.analysisStatus,
        })),
      })
        .then((res) => {
          setStudentSuspended(res.accountStatus === 'suspended');
          if (res.planOverride) setPlanOverride(res.planOverride);
          if (res.runtimeConfig) setRuntimeConfig(res.runtimeConfig);
          if (res.pendingNotifications?.length) {
            setAdminBroadcasts((prev) => [...res.pendingNotifications, ...prev].slice(0, 6));
          }
        })
        .catch(() => {});
    }, 1200);
    return () => clearTimeout(timer);
  }, [
    firebaseUser,
    profile?.planId,
    profile?.aiRequestsUsed,
    lectures.length,
    exams.length,
    summaries.length,
    flashcards.length,
    subjects.length,
  ]);

  const handleToggleLang = () => {
    const next: Language = lang === 'ar' ? 'en' : 'ar';
    setLang(next);
    if (firebaseUser?.emailVerified) {
      updateUserPreferences(firebaseUser.uid, { preferredLang: next }).catch(() => {});
    }
  };

  const handleToggleTheme = () => {
    const next: ThemeMode = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    if (firebaseUser?.emailVerified) {
      updateUserPreferences(firebaseUser.uid, { themeMode: next }).catch(() => {});
    }
  };

  const handleChangeAccent = (next: AccentTheme) => {
    setAccentTheme(next);
    if (firebaseUser?.emailVerified) {
      updateUserPreferences(firebaseUser.uid, { accentTheme: next }).catch(() => {});
    }
  };

  const handleChangeFontScale = (next: FontScale) => {
    setFontScale(next);
    if (firebaseUser?.emailVerified) {
      updateUserPreferences(firebaseUser.uid, { fontScale: next }).catch(() => {});
    }
  };

  // 1. Developer Control Center View (Unified Owner/Admin/Support/Content Manager route)
  if (devSession && devToken) {
    return (
      <DeveloperControlCenter
        token={devToken}
        devUser={devSession}
        lang={lang}
        theme={theme}
        onToggleLang={handleToggleLang}
        onToggleTheme={handleToggleTheme}
        onSessionUpdated={(freshToken, updatedUser) => {
          setDevToken(freshToken);
          setDevSession(updatedUser);
        }}
        onLogout={() => {
          setDevToken(null);
          setDevSession(null);
        }}
      />
    );
  }

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-[#0B1120] text-sm text-slate-400 gap-2">
        <Sparkles className="w-4 h-4 text-blue-500 animate-pulse" />
        <span>{t(lang).common.loading}</span>
      </div>
    );
  }

  if (!firebaseUser || !firebaseUser.emailVerified) {
    return (
      <AuthGate
        lang={lang}
        theme={theme}
        onToggleLang={handleToggleLang}
        onToggleTheme={handleToggleTheme}
        unverifiedUser={firebaseUser && !firebaseUser.emailVerified ? firebaseUser : null}
        onReloadUser={async () => {
          if (auth.currentUser) {
            await auth.currentUser.reload();
            setFirebaseUser(auth.currentUser);
            setAuthReloadTick((n) => n + 1);
          }
        }}
        onDevLoginSuccess={(token, user) => {
          setDevToken(token);
          setDevSession(user);
        }}
      />
    );
  }

  if (runtimeConfig?.appSettings.maintenanceMode) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#0B1120] flex items-center justify-center p-6">
        <div className="max-w-md w-full glass-surface border border-amber-500/40 rounded-2xl p-8 text-center space-y-4">
          <Sparkles className="w-10 h-10 text-amber-500 mx-auto" />
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">
            {lang === 'ar' ? 'التطبيق في وضع الصيانة المؤقتة' : 'Scheduled Maintenance'}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {lang === 'ar'
              ? 'نعمل حالياً على تحسين خدمات Smart Student. سنعود للعمل بعد قليل.'
              : 'Smart Student is undergoing scheduled upgrades. Please check back shortly.'}
          </p>
        </div>
      </div>
    );
  }

  if (studentSuspended) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#0B1120] flex items-center justify-center p-6">
        <div className="max-w-md w-full glass-surface border border-red-500/40 rounded-2xl p-8 text-center space-y-4">
          <Shield className="w-10 h-10 text-red-500 mx-auto" />
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">
            {lang === 'ar' ? 'تم إيقاف الحساب مؤقتاً' : 'Account Suspended'}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {lang === 'ar'
              ? 'يرجى التواصل مع الإدارة أو الدعم الفني لمراجعة حالة حسابك.'
              : 'Please contact support for assistance with your student account.'}
          </p>
          <button
            onClick={() => auth.signOut()}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900"
          >
            {lang === 'ar' ? 'تسجيل الخروج' : 'Sign Out'}
          </button>
        </div>
      </div>
    );
  }

  const dict = t(lang);
  const effectivePlanId = planOverride || profile?.planId || 'free';
  const catalogPlans = runtimeConfig?.plans?.length ? runtimeConfig.plans : plans;
  const activePlan =
    catalogPlans.find((p) => p.id === effectivePlanId) || {
      id: 'free',
      nameAr: 'الباقة المجانية',
      nameEn: 'Free Plan',
      priceMonthly: 0,
      currency: 'USD',
      aiRequestLimit: 30,
      storageLimitMb: 150,
      isActive: true,
    };

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const studentXp = profile?.xpPoints ?? 0;
  const studentLevel = Math.floor(studentXp / 150) + 1;

  const sectionFeatureMap: Partial<Record<NavSection, string>> = {
    tutor: 'aiTutor',
    exams: 'aiExams',
    flashcards: 'flashcards',
    mindmaps: 'mindMaps',
    planner: 'studyPlanner',
    whiteboard: 'aiProblemSolver',
    coding: 'codingPlayground',
  };

  const baseNavItems: { id: NavSection; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: dict.nav.dashboard, icon: <LayoutDashboard className="w-4 h-4 shrink-0" /> },
    { id: 'library', label: dict.nav.library, icon: <FolderKanban className="w-4 h-4 shrink-0" /> },
    { id: 'tutor', label: dict.nav.tutor, icon: <Brain className="w-4 h-4 shrink-0" /> },
    { id: 'summaries', label: dict.nav.summaries, icon: <FileText className="w-4 h-4 shrink-0" /> },
    { id: 'exams', label: dict.nav.exams, icon: <GraduationCap className="w-4 h-4 shrink-0" /> },
    { id: 'flashcards', label: dict.nav.flashcards, icon: <Layers className="w-4 h-4 shrink-0" /> },
    { id: 'mindmaps', label: dict.nav.mindmaps, icon: <GitBranch className="w-4 h-4 shrink-0" /> },
    { id: 'planner', label: dict.nav.planner, icon: <Calendar className="w-4 h-4 shrink-0" /> },
    { id: 'whiteboard', label: dict.nav.whiteboard, icon: <PenTool className="w-4 h-4 shrink-0" /> },
    { id: 'coding', label: dict.nav.coding, icon: <Code2 className="w-4 h-4 shrink-0" /> },
    { id: 'progress', label: dict.nav.progress, icon: <BarChart3 className="w-4 h-4 shrink-0" /> },
    { id: 'profile', label: dict.nav.profile, icon: <UserIcon className="w-4 h-4 shrink-0" /> },
  ];

  const navItems: { id: NavSection; label: string; icon: React.ReactNode }[] = baseNavItems.filter(
    (item) => {
      const flagId = sectionFeatureMap[item.id];
      if (!flagId || !runtimeConfig?.featureFlags?.[flagId]) return true;
      return runtimeConfig.featureFlags[flagId].status !== 'disabled';
    }
  );

  const mobileCoreTabs: { id: NavSection; ar: string; en: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', ar: 'الرئيسية', en: 'Home', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'library', ar: 'مكتبتي', en: 'Library', icon: <FolderKanban className="w-4 h-4" /> },
    { id: 'tutor', ar: 'المدرس', en: 'Tutor', icon: <Brain className="w-4 h-4" /> },
    { id: 'progress', ar: 'الإنجاز', en: 'Progress', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'profile', ar: 'حسابي', en: 'Profile', icon: <UserIcon className="w-4 h-4" /> },
  ];

  const navigateTo = (sec: NavSection, opts?: NavigateOptions) => {
    setSection(sec);
    if (opts?.lectureId !== undefined) setContextLectureId(opts.lectureId);
    setContextPageNumber(opts?.pageNumber);
    setContextTutorTab(opts?.tutorTab);
    setContextSummaryMode(opts?.summaryMode);
    setContextExamMode(opts?.examMode);
    setMobileMenuOpen(false);
  };

  const handleOpenLecturePage = (lectureId: string, pageNumber: number) => {
    navigateTo('library', { lectureId, pageNumber });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0B1120] text-slate-900 dark:text-slate-100 flex">
      {/* Desktop Sidebar */}
      <aside className="no-print hidden lg:flex w-64 shrink-0 flex-col border-e border-slate-200/80 dark:border-slate-800/80 glass-surface">
        <div className="h-16 px-5 border-b border-slate-200/80 dark:border-slate-800/80 flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl accent-btn-gradient text-white flex items-center justify-center shrink-0">
            <BookOpen className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <p className="font-bold text-sm tracking-tight whitespace-nowrap truncate">
              {dict.appName}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
              {dict.appSubtitle}
            </p>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const active = section === item.id;
            return (
              <button
                key={item.id}
                onClick={() => navigateTo(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                  active
                    ? 'accent-btn-gradient text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100/80 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                {item.icon}
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200/80 dark:border-slate-800/80 text-xs space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <p className="font-semibold text-slate-800 dark:text-slate-100 truncate">
              {profile?.displayName || firebaseUser.displayName}
            </p>
            <span className="px-2 py-0.5 rounded-md bg-blue-500/15 text-blue-600 dark:text-blue-300 font-semibold tabular-nums shrink-0">
              Lv.{studentLevel}
            </span>
          </div>
          <p className="text-slate-500 dark:text-slate-400 truncate">
            {lang === 'ar' ? activePlan.nameAr : activePlan.nameEn} ·{' '}
            <span className="tabular-nums">
              {profile?.aiRequestsUsed ?? 0}/{activePlan.aiRequestLimit}
            </span>
          </p>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="no-print fixed inset-0 z-50 lg:hidden flex">
          <div className="w-72 glass-surface border-e border-slate-200/80 dark:border-slate-800/80 flex flex-col h-full">
            <div className="h-14 px-4 border-b border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg accent-btn-gradient text-white flex items-center justify-center">
                  <BookOpen className="w-3.5 h-3.5" />
                </div>
                <span className="font-bold text-base">{dict.appName}</span>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap ${
                    section === item.id
                      ? 'accent-btn-gradient text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {item.icon}
                  <span className="truncate">{item.label}</span>
                </button>
              ))}
            </nav>
          </div>
          <div className="flex-1 bg-black/50 backdrop-blur-xs" onClick={() => setMobileMenuOpen(false)} />
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="no-print sticky top-0 z-30 h-14 sm:h-16 px-4 sm:px-6 border-b border-slate-200/80 dark:border-slate-800/80 glass-surface flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
              aria-label="Open navigation"
            >
              <Menu className="w-4 h-4" />
            </button>
            <span className="text-sm font-bold text-slate-800 dark:text-slate-100 truncate">
              {navItems.find((i) => i.id === section)?.label}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setSearchOpen(true)}
              className="px-2.5 sm:px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700/80 bg-white/60 dark:bg-slate-900/60 rounded-xl flex items-center gap-2 hover:border-blue-500/50 transition-colors whitespace-nowrap shrink-0"
              aria-label={dict.common.search}
            >
              <Search className="w-3.5 h-3.5 text-blue-500" />
              <span className="hidden sm:inline text-slate-500 dark:text-slate-400">
                {lang === 'ar' ? 'بحث ذكي' : 'Smart Search'}
              </span>
              <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[10px] rounded bg-slate-100 dark:bg-slate-800 text-slate-500 font-mono">
                ⌘K
              </kbd>
            </button>
            <button
              onClick={() => navigateTo('profile')}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700/80 rounded-xl flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
              aria-label="Notifications"
            >
              <Bell className="w-3.5 h-3.5" />
              <span className="tabular-nums">{unreadCount}</span>
            </button>
            <button
              onClick={handleToggleLang}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700/80 rounded-xl flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'EN' : 'AR'}</span>
            </button>
            <button
              onClick={handleToggleTheme}
              aria-label="Toggle theme"
              className="p-2 border border-slate-200 dark:border-slate-700/80 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 pb-24 lg:pb-8 max-w-7xl w-full mx-auto">
          {adminBroadcasts.length > 0 && (
            <div className="mb-5 space-y-2">
              {adminBroadcasts.map((msg) => (
                <div
                  key={msg.id}
                  className="p-3.5 rounded-2xl bg-blue-600/10 border border-blue-500/30 flex items-start justify-between gap-3 text-xs"
                >
                  <div>
                    <p className="font-bold text-blue-700 dark:text-sky-300">{msg.title}</p>
                    <p className="text-slate-600 dark:text-slate-300 mt-0.5">{msg.body}</p>
                  </div>
                  <button
                    onClick={() =>
                      setAdminBroadcasts((prev) => prev.filter((x) => x.id !== msg.id))
                    }
                    className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
          {(() => {
            const flagId = sectionFeatureMap[section];
            const flag = flagId ? runtimeConfig?.featureFlags?.[flagId] : undefined;
            if (flag && flag.status === 'maintenance') {
              return (
                <div className="glass-surface border border-amber-500/40 rounded-2xl p-8 text-center space-y-2">
                  <Sparkles className="w-8 h-8 text-amber-500 mx-auto" />
                  <h2 className="text-base font-bold text-slate-900 dark:text-white">
                    {lang === 'ar' ? flag.nameAr : flag.nameEn}
                  </h2>
                  <p className="text-xs text-slate-500">
                    {lang === 'ar' ? flag.maintenanceMessageAr : flag.maintenanceMessageEn}
                  </p>
                </div>
              );
            }
            return null;
          })()}
          {section === 'dashboard' && (
            <DashboardView
              lang={lang}
              profile={profile}
              activePlan={activePlan}
              subjects={subjects}
              lectures={lectures}
              summaries={summaries}
              exams={exams}
              flashcards={flashcards}
              tasks={studyPlans}
              mistakes={mistakes}
              onNavigate={navigateTo}
            />
          )}
          {section === 'library' && (
            <LibraryView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              subjects={subjects}
              folders={folders}
              lectures={lectures}
              initialLectureId={contextLectureId}
              initialPageNumber={contextPageNumber}
              onOpenSectionWithLecture={navigateTo}
            />
          )}
          {section === 'tutor' && (
            <TutorView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              activePlan={activePlan}
              subjects={subjects}
              lectures={lectures}
              explanations={explanations}
              chatMessages={chatMessages}
              podcasts={podcasts}
              initialLectureId={contextLectureId}
              initialTab={contextTutorTab}
              onOpenLecturePage={handleOpenLecturePage}
            />
          )}
          {section === 'summaries' && (
            <SummariesView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              activePlan={activePlan}
              subjects={subjects}
              lectures={lectures}
              summaries={summaries}
              mistakes={mistakes}
              studyGroups={studyGroups}
              initialLectureId={contextLectureId}
              initialMode={contextSummaryMode}
            />
          )}
          {section === 'exams' && (
            <ExamsView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              activePlan={activePlan}
              subjects={subjects}
              lectures={lectures}
              exams={exams}
              mistakes={mistakes}
              initialLectureId={contextLectureId}
              initialMode={contextExamMode}
            />
          )}
          {section === 'flashcards' && (
            <FlashcardsView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              activePlan={activePlan}
              subjects={subjects}
              lectures={lectures}
              flashcards={flashcards}
            />
          )}
          {section === 'mindmaps' && (
            <MindMapsView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              activePlan={activePlan}
              lectures={lectures}
              mindMaps={mindMaps}
              initialLectureId={contextLectureId}
            />
          )}
          {section === 'planner' && (
            <PlannerView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              activePlan={activePlan}
              subjects={subjects}
              lectures={lectures}
              tasks={studyPlans}
            />
          )}
          {section === 'whiteboard' && (
            <WhiteboardView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              activePlan={activePlan}
              subjects={subjects}
              whiteboards={whiteboards}
            />
          )}
          {section === 'coding' && (
            <CodingPlaygroundView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              activePlan={activePlan}
              subjects={subjects}
              projects={codingProjects}
            />
          )}
          {section === 'progress' && (
            <ProgressSocialView
              lang={lang}
              uid={firebaseUser.uid}
              profile={profile}
              subjects={subjects}
              lectures={lectures}
              exams={exams}
              mistakes={mistakes}
              studyGroups={studyGroups}
              sharedResources={sharedResources}
              challengeScores={challengeScores}
              studyBattles={studyBattles}
            />
          )}
          {section === 'profile' && (
            <ProfileBillingView
              lang={lang}
              theme={theme}
              accentTheme={accentTheme}
              fontScale={fontScale}
              uid={firebaseUser.uid}
              profile={profile}
              activePlanId={effectivePlanId}
              plans={catalogPlans.length ? catalogPlans : [activePlan]}
              notifications={notifications}
              onToggleLang={handleToggleLang}
              onToggleTheme={handleToggleTheme}
              onChangeAccent={handleChangeAccent}
              onChangeFontScale={handleChangeFontScale}
            />
          )}
        </main>
      </div>

      {/* Mobile 5-Tab Fixed Bottom Navigation Bar */}
      <nav
        aria-label="Mobile quick navigation"
        className="no-print lg:hidden fixed bottom-0 inset-x-0 z-40 h-16 glass-surface border-t border-slate-200/80 dark:border-slate-800/80 px-2 flex items-center justify-around"
      >
        {mobileCoreTabs.map((tabItem) => {
          const active = section === tabItem.id;
          return (
            <button
              key={tabItem.id}
              onClick={() => navigateTo(tabItem.id)}
              className={`flex flex-col items-center justify-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                active
                  ? 'text-blue-600 dark:text-blue-400'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {tabItem.icon}
              <span>{lang === 'ar' ? tabItem.ar : tabItem.en}</span>
            </button>
          );
        })}
      </nav>

      {/* Global Smart Search Modal */}
      <SmartSearchModal
        lang={lang}
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        subjects={subjects}
        lectures={lectures}
        summaries={summaries}
        flashcards={flashcards}
        exams={exams}
        mistakes={mistakes}
        chatMessages={chatMessages}
        onNavigate={(sec, lectureId, pageNum) =>
          navigateTo(sec, { lectureId, pageNumber: pageNum })
        }
      />
    </div>
  );
}
