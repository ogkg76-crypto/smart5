import { auth } from '../firebase';
import {
  ChatCitation,
  CodingLanguage,
  ExamQuestion,
  ExplanationLevel,
  ExplanationSection,
  ExtractedPage,
  LectureFileType,
  MindMapNode,
  PodcastScriptLine,
  QuestionType,
  SummaryDetailLevel,
  TutorPersona,
  WhiteboardAiMode,
} from '../types';

async function getAuthHeaders(isJson = true): Promise<Record<string, string>> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('Authentication required. Please sign in first.');
  }
  const token = await user.getIdToken();
  const headers: Record<string, string> = {
    Authorization: `Bearer ${token}`,
  };
  if (isJson) {
    headers['Content-Type'] = 'application/json';
  }
  return headers;
}

async function handleApiResponse<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data as T;
}

export async function extractLectureFile(file: File): Promise<{
  fileType: LectureFileType;
  pages: ExtractedPage[];
  fullTextPreview: string;
}> {
  const headers = await getAuthHeaders(false);
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch('/api/files/extract', {
    method: 'POST',
    headers,
    body: formData,
  });
  return handleApiResponse(res);
}

export async function generateExplanation(params: {
  lectureTitle: string;
  pages: ExtractedPage[];
  level: ExplanationLevel;
  persona?: TutorPersona;
  lang: 'ar' | 'en';
}): Promise<{ overview: string; sections: ExplanationSection[] }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/explain', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function reexplainSection(params: {
  sectionTitle: string;
  sourceText: string;
  style: 'simpler' | 'deeper' | 'examples';
  lang: 'ar' | 'en';
}): Promise<{ explanation: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/reexplain', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function generateSummary(params: {
  lectureTitle: string;
  fullText: string;
  detailLevel: SummaryDetailLevel;
  lang: 'ar' | 'en';
}): Promise<{
  contentMarkdown: string;
  keyPoints: string[];
  definitions: { term: string; definition: string }[];
  formulas: { name: string; expression: string; note?: string }[];
  comparisons: { topicA: string; topicB: string; difference: string }[];
  revisionAlerts: string[];
}> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/summarize', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function generateQuestions(params: {
  sourceText: string;
  count: number;
  types: QuestionType[];
  difficulty: 'easy' | 'medium' | 'hard';
  lang: 'ar' | 'en';
}): Promise<{
  questions: ExamQuestion[];
}> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/questions', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function gradeEssayAnswer(params: {
  question: string;
  expectedAnswer: string;
  studentAnswer: string;
  lang: 'ar' | 'en';
}): Promise<{ scoreOutOf10: number; isCorrect: boolean; feedback: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/grade-essay', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function sendTutorChat(params: {
  message: string;
  sourceMode: 'lecture' | 'subject' | 'general';
  persona?: TutorPersona;
  contextText: string;
  history: { role: 'user' | 'assistant'; text: string }[];
  lang: 'ar' | 'en';
}): Promise<{ reply: string; citations: ChatCitation[] }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/chat', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function solvePhotoProblem(
  imageFile: File,
  lang: 'ar' | 'en'
): Promise<{
  clarityStatus: string;
  unclearNote?: string;
  recognizedProblem: string;
  topic: string;
  coreConcept: string;
  steps: string[];
  finalAnswer: string;
}> {
  const headers = await getAuthHeaders(false);
  const formData = new FormData();
  formData.append('image', imageFile);
  formData.append('lang', lang);
  const res = await fetch('/api/ai/solve-photo', {
    method: 'POST',
    headers,
    body: formData,
  });
  return handleApiResponse(res);
}

export async function generateFlashcards(params: {
  lectureTitle: string;
  fullText: string;
  count: number;
  lang: 'ar' | 'en';
}): Promise<{ cards: { front: string; back: string }[] }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/flashcards', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function generateMindMap(params: {
  lectureTitle: string;
  fullText: string;
  lang: 'ar' | 'en';
}): Promise<{ rootNode: MindMapNode }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/mindmap', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function generateStudyPlan(params: {
  subjects: {
    subjectId: string;
    subjectName: string;
    lectureCount: number;
    examDate?: string;
    understandingLevel: string;
    priority: string;
  }[];
  dailyHours: number;
  startDate: string;
  lang: 'ar' | 'en';
}): Promise<{
  tasks: {
    subjectId?: string;
    subjectName: string;
    title: string;
    scheduledDate: string;
    durationMinutes: number;
    taskType: 'lecture' | 'review' | 'practice';
    priority: 'low' | 'medium' | 'high';
  }[];
}> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/study-plan', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function transcribeVoiceRecording(audioBlob: Blob): Promise<{ text: string }> {
  const headers = await getAuthHeaders(false);
  const formData = new FormData();
  formData.append('audio', audioBlob, 'voice-question.webm');
  const res = await fetch('/api/ai/transcribe-voice', {
    method: 'POST',
    headers,
    body: formData,
  });
  return handleApiResponse(res);
}

export async function synthesizeSpeech(
  text: string,
  voiceName = 'Kore'
): Promise<{ audioBase64: string; mimeType: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/tts', {
    method: 'POST',
    headers,
    body: JSON.stringify({ text, voiceName }),
  });
  return handleApiResponse(res);
}

export async function generatePodcastScript(params: {
  lectureTitle: string;
  fullText: string;
  lengthMode: 'short' | 'long';
  lang: 'ar' | 'en';
}): Promise<{ title: string; summaryText: string; scriptLines: PodcastScriptLine[] }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/podcast', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function synthesizePodcastAudio(params: {
  scriptLines: PodcastScriptLine[];
  lang: 'ar' | 'en';
}): Promise<{ audioBase64: string; mimeType: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/podcast-audio', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function analyzeWhiteboard(params: {
  imageBase64: string;
  mode: WhiteboardAiMode;
  prompt?: string;
  lang: 'ar' | 'en';
}): Promise<{ analysis: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/whiteboard-analyze', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function runSandboxedCode(params: {
  language: CodingLanguage;
  code: string;
  stdin?: string;
}): Promise<{
  success: boolean;
  stdout: string;
  stderr: string;
  exitCode: number;
  executionMs: number;
}> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/code/run', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function askCodeMentor(params: {
  language: CodingLanguage;
  code: string;
  stderr?: string;
  action: 'review' | 'debug' | 'explain';
  lang: 'ar' | 'en';
}): Promise<{ review: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/code-mentor', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function predictExamTopics(params: {
  subjectName: string;
  lecturesText: string;
  pastExamText?: string;
  lang: 'ar' | 'en';
}): Promise<{
  disclaimer: string;
  recurringTopics: { topic: string; importanceScore: number; rationale: string }[];
  predictedQuestions: ExamQuestion[];
}> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/exam-predict', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function translateLectureText(params: {
  text: string;
  targetLang: 'ar' | 'en';
}): Promise<{
  translatedText: string;
  glossary: { originalTerm: string; translatedTerm: string; note?: string }[];
}> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/translate', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function generateRevisionPack(params: {
  title: string;
  sourceText: string;
  weakTopics?: string[];
  lang: 'ar' | 'en';
}): Promise<{
  rapidBulletSummary: string[];
  mustKnowDefinitions: { term: string; definition: string }[];
  keyFormulasOrRules: string[];
  rapidQaCheck: { question: string; answer: string }[];
}> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/revision-pack', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function generateWeeklyReport(params: {
  metrics: Record<string, unknown>;
  lang: 'ar' | 'en';
}): Promise<{ report: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/weekly-report', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function semanticSearchCorpus(params: {
  queryText: string;
  items: { id: string; type: string; title: string; snippet: string }[];
  lang: 'ar' | 'en';
}): Promise<{ matches: { id: string; type: string; reason: string }[] }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/ai/semantic-search', {
    method: 'POST',
    headers,
    body: JSON.stringify(params),
  });
  return handleApiResponse(res);
}

export async function fetchPublicRuntimeConfig(): Promise<import('../types').PublicRuntimeConfig> {
  const res = await fetch('/api/public/runtime-config');
  return handleApiResponse(res);
}

export async function syncStudentTelemetry(payload: {
  displayName?: string;
  email?: string;
  planId?: string;
  aiRequestsUsed?: number;
  storageBytesUsed?: number;
  lecturesCount?: number;
  examsCount?: number;
  summariesCount?: number;
  flashcardsCount?: number;
  studyHoursLogged?: number;
  recentSubjects?: { id: string; name: string; college?: string; semester?: string }[];
  recentLectures?: { id: string; title: string; fileType?: string; analysisStatus?: string }[];
}): Promise<{
  accountStatus: 'active' | 'suspended';
  planOverride?: string;
  premiumGiftUntil?: string;
  pendingNotifications: { id: string; title: string; body: string; linkSection?: string; createdAt: string }[];
  runtimeConfig: import('../types').PublicRuntimeConfig;
}> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/student/telemetry', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });
  return handleApiResponse(res);
}

export async function submitSupportTicket(payload: {
  category: 'bug' | 'billing' | 'ai' | 'feature';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  subject: string;
  message: string;
  ownerName?: string;
}): Promise<{ ticket: import('../types').SupportTicket }> {
  const headers = await getAuthHeaders();
  const res = await fetch('/api/support/tickets', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });
  return handleApiResponse(res);
}
