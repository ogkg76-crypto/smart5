import { auth } from '../firebase';
import {
  AcademicContentNode,
  AdminAccountPublic,
  AdminRoleType,
  AiServiceConfig,
  AppSettingsConfig,
  AuditLogEntry,
  BackupSnapshotInfo,
  ContentKind,
  ControlPaymentRecord,
  ControlPlanConfig,
  ControlPromoConfig,
  ControlUserRecord,
  DevSessionUser,
  FeatureFlagConfig,
  SupportTicket,
  TargetedNotificationRecord,
} from '../types';

export interface UnifiedLoginResult {
  delegateToFirebase?: boolean;
  requiresFirstRunSetup?: boolean;
  requires2fa?: boolean;
  email?: string;
  role?: AdminRoleType;
  token?: string;
  user?: DevSessionUser;
}

export interface DevOverviewResponse {
  kpis: {
    totalUsers: number;
    activeUsers: number;
    newUsersToday: number;
    totalSubscriptions: number;
    freeCount: number;
    proCount: number;
    eliteCount: number;
    totalRevenue: number;
    totalAiCost: number;
    lecturesUploaded: number;
    filesProcessed: number;
    examsCreated: number;
    questionsGenerated: number;
    aiRequestsCount: number;
    summariesCount: number;
    openTickets: number;
  };
  serverHealth: {
    api: string;
    geminiConfigured: boolean;
    uptimeSeconds: number;
    maintenanceMode: boolean;
  };
  charts: {
    series: { date: string; users: number; revenue: number; aiCost: number; aiCalls: number }[];
    topFeatures: { id: string; nameEn: string; nameAr: string; count: number }[];
  };
  activityFeed: {
    id: string;
    type: string;
    label: string;
    detail: string;
    latencyMs?: number;
    costUsd?: number;
    createdAt: string;
  }[];
}

export interface DevAnalyticsResponse {
  summary: {
    totalUsers: number;
    activeUsers: number;
    retentionRatePercent: number;
    newSubscriptions: number;
    cancelledOrRefunded: number;
    totalRevenue: number;
    totalAiCost: number;
    avgCostPerUser: number;
    processedFiles: number;
    processingFailureRate: number;
  };
  featureBreakdown: { id: string; name: string; nameAr: string; count: number }[];
  aiBreakdown: {
    id: string;
    name: string;
    model: string;
    calls: number;
    failed: number;
    avgLatencyMs: number;
    costUsd: number;
  }[];
  topSubjects: { title: string; parentName: string }[];
}

export interface DevMonitoringResponse {
  services: { name: string; status: 'healthy' | 'degraded'; latencyMs: number; detail: string }[];
  system: {
    uptimeSeconds: number;
    rssMb: number;
    heapUsedMb: number;
    cpuLoad: number[];
    storageUsedBytes: number;
    totalAiErrors: number;
  };
  recentErrors: { id: string; label: string; detail: string; createdAt: string }[];
}

async function resolveBearerToken(explicitToken?: string | null): Promise<string> {
  if (explicitToken) return explicitToken;
  const user = auth.currentUser;
  if (!user) throw new Error('Authentication required.');
  return user.getIdToken();
}

async function devFetch<T>(
  url: string,
  token: string | null,
  options: RequestInit = {}
): Promise<T> {
  const bearer = await resolveBearerToken(token);
  const headers: Record<string, string> = {
    Authorization: `Bearer ${bearer}`,
    ...((options.headers as Record<string, string>) || {}),
  };
  if (options.body && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data as T;
}

export async function unifiedLogin(params: {
  email: string;
  password: string;
  totpCode?: string;
}): Promise<UnifiedLoginResult> {
  const res = await fetch('/api/auth/unified-login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Login failed (${res.status})`);
  }
  return data as UnifiedLoginResult;
}

export async function bootstrapOwnerPassword(params: {
  email: string;
  password: string;
}): Promise<{ token: string; user: DevSessionUser }> {
  const res = await fetch('/api/auth/owner-bootstrap', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Owner initialization failed (${res.status})`);
  }
  return data;
}

export const changeDevPassword = (
  token: string | null,
  currentPassword: string,
  newPassword: string
) =>
  devFetch<{ token: string; user: DevSessionUser }>('/api/auth/dev-change-password', token, {
    method: 'POST',
    body: JSON.stringify({ currentPassword, newPassword }),
  });

export const logoutAllDevDevices = (token: string | null) =>
  devFetch<{ ok: boolean }>('/api/auth/dev-logout-all', token, { method: 'POST' });

export const setupDev2fa = (token: string | null) =>
  devFetch<{ secret: string; otpauthUri: string }>('/api/auth/dev-2fa/setup', token, {
    method: 'POST',
  });

export const verifyEnableDev2fa = (token: string | null, code: string) =>
  devFetch<{ user: DevSessionUser }>('/api/auth/dev-2fa/verify-enable', token, {
    method: 'POST',
    body: JSON.stringify({ code }),
  });

export const disableDev2fa = (token: string | null) =>
  devFetch<{ user: DevSessionUser }>('/api/auth/dev-2fa/disable', token, { method: 'POST' });

export const fetchDevOverview = (
  token: string | null,
  range: '7d' | '30d' | '90d' | 'all' = '30d'
) => devFetch<DevOverviewResponse>(`/api/dev/overview?range=${range}`, token);

export const fetchDevUsers = (token: string | null) =>
  devFetch<{ users: ControlUserRecord[] }>('/api/dev/users', token);

export const patchDevUser = (
  token: string | null,
  uid: string,
  payload: {
    planId?: string;
    status?: 'active' | 'suspended';
    grantPremiumDays?: number;
    extendDays?: number;
    displayName?: string;
  }
) =>
  devFetch<{ user: ControlUserRecord }>(`/api/dev/users/${encodeURIComponent(uid)}`, token, {
    method: 'PATCH',
    body: JSON.stringify(payload),
  });

export const notifyDevUser = (
  token: string | null,
  uid: string,
  title: string,
  body: string
) =>
  devFetch<{ ok: boolean }>(`/api/dev/users/${encodeURIComponent(uid)}/notify`, token, {
    method: 'POST',
    body: JSON.stringify({ title, body }),
  });

export const fetchDevSubscriptions = (token: string | null) =>
  devFetch<{
    plans: ControlPlanConfig[];
    promoCodes: ControlPromoConfig[];
    payments: ControlPaymentRecord[];
  }>('/api/dev/subscriptions', token);

export const saveDevPlan = (token: string | null, plan: ControlPlanConfig) =>
  devFetch<{ plans: ControlPlanConfig[] }>('/api/dev/plans', token, {
    method: 'PUT',
    body: JSON.stringify(plan),
  });

export const saveDevPromo = (
  token: string | null,
  promo: { code: string; discountPercent: number; maxUses?: number; expiresAt?: string }
) =>
  devFetch<{ promoCodes: ControlPromoConfig[] }>('/api/dev/promos', token, {
    method: 'POST',
    body: JSON.stringify(promo),
  });

export const deleteDevPromo = (token: string | null, code: string) =>
  devFetch<{ promoCodes: ControlPromoConfig[] }>(
    `/api/dev/promos/${encodeURIComponent(code)}`,
    token,
    { method: 'DELETE' }
  );

export const patchDevPayment = (
  token: string | null,
  id: string,
  status: 'paid' | 'refunded' | 'pending'
) =>
  devFetch<{ payments: ControlPaymentRecord[] }>(
    `/api/dev/payments/${encodeURIComponent(id)}`,
    token,
    { method: 'PATCH', body: JSON.stringify({ status }) }
  );

export const fetchDevAiServices = (token: string | null) =>
  devFetch<{ aiServices: AiServiceConfig[] }>('/api/dev/ai-control', token);

export const updateDevAiService = (
  token: string | null,
  id: string,
  patch: Partial<AiServiceConfig>
) =>
  devFetch<{ aiServices: AiServiceConfig[] }>(
    `/api/dev/ai-control/${encodeURIComponent(id)}`,
    token,
    { method: 'PUT', body: JSON.stringify(patch) }
  );

export const simulateAiCost = (
  token: string | null,
  params: {
    expectedUsers: number;
    requestsPerUserPerDay: number;
    model: string;
    serviceType: string;
    avgFileSizeMb: number;
  }
) =>
  devFetch<{
    dailyRequests: number;
    monthlyRequests: number;
    costPerRequestUsd: number;
    dailyCostUsd: number;
    monthlyCostUsd: number;
    costPerUserMonthlyUsd: number;
  }>('/api/dev/ai-cost-simulate', token, {
    method: 'POST',
    body: JSON.stringify(params),
  });

export const fetchDevFeatures = (token: string | null) =>
  devFetch<{ featureFlags: FeatureFlagConfig[] }>('/api/dev/features', token);

export const updateDevFeature = (
  token: string | null,
  id: string,
  patch: Partial<FeatureFlagConfig>
) =>
  devFetch<{ featureFlags: FeatureFlagConfig[] }>(
    `/api/dev/features/${encodeURIComponent(id)}`,
    token,
    { method: 'PUT', body: JSON.stringify(patch) }
  );

export const fetchDevContent = (token: string | null) =>
  devFetch<{ contentNodes: AcademicContentNode[] }>('/api/dev/content', token);

export const createDevContent = (
  token: string | null,
  node: {
    kind: ContentKind;
    title: string;
    parentName?: string;
    category?: string;
    status?: 'published' | 'hidden' | 'failed';
    meta?: string;
  }
) =>
  devFetch<{ contentNodes: AcademicContentNode[] }>('/api/dev/content', token, {
    method: 'POST',
    body: JSON.stringify(node),
  });

export const patchDevContent = (
  token: string | null,
  id: string,
  patch: Partial<AcademicContentNode>
) =>
  devFetch<{ contentNodes: AcademicContentNode[] }>(
    `/api/dev/content/${encodeURIComponent(id)}`,
    token,
    { method: 'PATCH', body: JSON.stringify(patch) }
  );

export const deleteDevContent = (token: string | null, id: string) =>
  devFetch<{ contentNodes: AcademicContentNode[] }>(
    `/api/dev/content/${encodeURIComponent(id)}`,
    token,
    { method: 'DELETE' }
  );

export const fetchDevNotifications = (token: string | null) =>
  devFetch<{ notifications: TargetedNotificationRecord[] }>('/api/dev/notifications', token);

export const dispatchDevNotification = (
  token: string | null,
  payload: {
    target: 'all' | 'free' | 'pro' | 'elite' | 'user';
    targetValue?: string;
    title: string;
    body: string;
    imageUrl?: string;
    linkSection?: string;
    scheduledFor?: string;
  }
) =>
  devFetch<{ notifications: TargetedNotificationRecord[] }>('/api/dev/notifications', token, {
    method: 'POST',
    body: JSON.stringify(payload),
  });

export const fetchDevSupport = (token: string | null) =>
  devFetch<{ tickets: SupportTicket[] }>('/api/dev/support', token);

export const patchDevTicket = (
  token: string | null,
  id: string,
  patch: {
    status?: SupportTicket['status'];
    priority?: SupportTicket['priority'];
    reply?: string;
    internalNote?: string;
  }
) =>
  devFetch<{ tickets: SupportTicket[] }>(`/api/dev/support/${encodeURIComponent(id)}`, token, {
    method: 'PATCH',
    body: JSON.stringify(patch),
  });

export const fetchDevAnalytics = (token: string | null) =>
  devFetch<DevAnalyticsResponse>('/api/dev/analytics', token);

export const fetchDevMonitoring = (token: string | null) =>
  devFetch<DevMonitoringResponse>('/api/dev/monitoring', token);

export const fetchDevAuditLogs = (token: string | null) =>
  devFetch<{ auditLogs: AuditLogEntry[] }>('/api/dev/audit-logs', token);

export const fetchDevBackups = (token: string | null) =>
  devFetch<{
    backups: BackupSnapshotInfo[];
    schedule: string;
    retentionCount: number;
  }>('/api/dev/backups', token);

export const createDevBackup = (token: string | null) =>
  devFetch<{ ok: boolean; id: string }>('/api/dev/backups', token, { method: 'POST' });

export const restoreDevBackup = (token: string | null, id: string) =>
  devFetch<{ ok: boolean }>(`/api/dev/backups/${encodeURIComponent(id)}/restore`, token, {
    method: 'POST',
  });

export async function downloadDevBackupJson(token: string | null, id: string) {
  const bearer = await resolveBearerToken(token);
  const res = await fetch(`/api/dev/backups/${encodeURIComponent(id)}/download`, {
    headers: { Authorization: `Bearer ${bearer}` },
  });
  if (!res.ok) throw new Error('Failed to download backup.');
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${id}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export const fetchDevSettings = (token: string | null) =>
  devFetch<{ appSettings: AppSettingsConfig }>('/api/dev/settings', token);

export const updateDevSettings = (token: string | null, patch: Partial<AppSettingsConfig>) =>
  devFetch<{ appSettings: AppSettingsConfig }>('/api/dev/settings', token, {
    method: 'PUT',
    body: JSON.stringify(patch),
  });

export const fetchDevRoles = (token: string | null) =>
  devFetch<{ accounts: AdminAccountPublic[] }>('/api/dev/roles', token);

export const createDevRoleAccount = (
  token: string | null,
  payload: {
    email: string;
    displayName: string;
    role: Exclude<AdminRoleType, 'owner'>;
    password: string;
    permissions?: string[];
  }
) =>
  devFetch<{ accounts: AdminAccountPublic[] }>('/api/dev/roles', token, {
    method: 'POST',
    body: JSON.stringify(payload),
  });

export const deleteDevRoleAccount = (token: string | null, id: string) =>
  devFetch<{ accounts: AdminAccountPublic[] }>(`/api/dev/roles/${encodeURIComponent(id)}`, token, {
    method: 'DELETE',
  });
