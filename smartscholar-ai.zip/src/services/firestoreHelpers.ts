import {
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  increment,
  writeBatch,
  getDoc,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { AppNotification, Language, ThemeMode, UserProfile } from '../types';

export function makeId(prefix = 'id'): string {
  const rand = Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now().toString(36)}_${rand}`;
}

export async function ensureUserProfile(params: {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  preferredLang: Language;
  themeMode: ThemeMode;
}): Promise<void> {
  const path = `users/${params.uid}`;
  try {
    const ref = doc(db, 'users', params.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        uid: params.uid,
        displayName: (params.displayName || 'Student').slice(0, 120),
        email: params.email.slice(0, 160),
        photoURL: (params.photoURL || '').slice(0, 500),
        college: '',
        department: '',
        academicYear: '',
        semester: 'Fall 2026',
        planId: 'free',
        aiRequestsUsed: 0,
        storageBytesUsed: 0,
        studyHoursLogged: 0,
        preferredLang: params.preferredLang,
        themeMode: params.themeMode,
        accentTheme: 'electric',
        fontScale: 'md',
        defaultPersona: 'professor',
        explanationLang: params.preferredLang,
        voiceSpeed: 1,
        xpPoints: 0,
        streakDays: 0,
        lastStudyDate: '',
        showOnLeaderboard: false,
        notifStudyReminders: true,
        notifExamAlerts: true,
        notifAiReady: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function trackAiUsageAndNotify(params: {
  uid: string;
  notifTitle?: string;
  notifBody?: string;
  notifCategory?: AppNotification['category'];
  enableNotif?: boolean;
  xpDelta?: number;
}): Promise<void> {
  try {
    const batch = writeBatch(db);
    const userRef = doc(db, 'users', params.uid);
    const updates: Record<string, unknown> = {
      aiRequestsUsed: increment(1),
      updatedAt: serverTimestamp(),
    };
    if (params.xpDelta && params.xpDelta > 0) {
      updates.xpPoints = increment(params.xpDelta);
    }
    batch.update(userRef, updates);
    if (params.enableNotif && params.notifTitle && params.notifBody) {
      const notifId = makeId('notif');
      batch.set(doc(db, 'notifications', notifId), {
        ownerId: params.uid,
        title: params.notifTitle.slice(0, 160),
        body: params.notifBody.slice(0, 400),
        category: params.notifCategory || 'ai',
        isRead: false,
        createdAt: serverTimestamp(),
      });
    }
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${params.uid}`);
  }
}

export async function awardStudyXp(
  uid: string,
  profile: UserProfile | null,
  xpDelta: number
): Promise<void> {
  if (!uid || xpDelta <= 0) return;
  try {
    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 86_400_000).toISOString().slice(0, 10);
    const last = profile?.lastStudyDate || '';
    const currentStreak = profile?.streakDays || 0;
    let nextStreak = currentStreak;
    if (last === today) {
      nextStreak = Math.max(currentStreak, 1);
    } else if (last === yesterday) {
      nextStreak = currentStreak + 1;
    } else {
      nextStreak = 1;
    }
    await updateDoc(doc(db, 'users', uid), {
      xpPoints: increment(xpDelta),
      streakDays: nextStreak,
      lastStudyDate: today,
      updatedAt: serverTimestamp(),
    });
  } catch {
    // non-fatal gamification update
  }
}

export async function updateUserPreferences(
  uid: string,
  updates: Partial<
    Pick<
      UserProfile,
      | 'displayName'
      | 'college'
      | 'department'
      | 'academicYear'
      | 'semester'
      | 'preferredLang'
      | 'themeMode'
      | 'accentTheme'
      | 'fontScale'
      | 'defaultPersona'
      | 'explanationLang'
      | 'voiceSpeed'
      | 'showOnLeaderboard'
      | 'notifStudyReminders'
      | 'notifExamAlerts'
      | 'notifAiReady'
      | 'studyHoursLogged'
    >
  >
): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', uid), {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
  }
}

export async function deleteDocSafe(collectionName: string, id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, collectionName, id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${collectionName}/${id}`);
  }
}

export function getEffectiveLimit(aiRequestLimit: number, used: number): {
  percent: number;
  nearLimit: boolean;
  exceeded: boolean;
} {
  const safeLimit = Math.max(aiRequestLimit, 1);
  const percent = Math.min(Math.round((used / safeLimit) * 100), 100);
  return {
    percent,
    nearLimit: used >= safeLimit * 0.8 && used < safeLimit,
    exceeded: used >= safeLimit,
  };
}

// Offline IndexedDB audio cache for AI Podcasts
const PODCAST_DB_NAME = 'smart_student_audio_cache';
const PODCAST_STORE = 'episodes';

function openAudioDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(PODCAST_DB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(PODCAST_STORE)) {
        req.result.createObjectStore(PODCAST_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function cachePodcastAudio(episodeId: string, base64Wav: string): Promise<void> {
  try {
    const dbInst = await openAudioDb();
    await new Promise<void>((resolve, reject) => {
      const tx = dbInst.transaction(PODCAST_STORE, 'readwrite');
      tx.objectStore(PODCAST_STORE).put(base64Wav, episodeId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // IndexedDB unavailable; audio remains playable in-memory
  }
}

export async function getCachedPodcastAudio(episodeId: string): Promise<string | null> {
  try {
    const dbInst = await openAudioDb();
    return await new Promise<string | null>((resolve, reject) => {
      const tx = dbInst.transaction(PODCAST_STORE, 'readonly');
      const req = tx.objectStore(PODCAST_STORE).get(episodeId);
      req.onsuccess = () => resolve((req.result as string) || null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}
