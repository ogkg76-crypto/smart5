import React, { useState } from 'react';
import { DevNavSection, DevSessionUser, Language, ThemeMode } from '../types';
import {
  DevAiControlSection,
  DevFeaturesSection,
  DevOverviewSection,
  DevSubscriptionsSection,
  DevUsersSection,
} from './dev/DevCoreSections';
import {
  DevAnalyticsSection,
  DevContentSection,
  DevMonitoringSection,
  DevNotificationsSection,
  DevSupportSection,
} from './dev/DevOpsSections';
import {
  DevAppSettingsSection,
  DevAuditLogsSection,
  DevBackupsSection,
  DevCostSimulatorSection,
  DevProfileSecuritySection,
} from './dev/DevAdminSections';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Bell,
  Calculator,
  Cpu,
  CreditCard,
  DatabaseBackup,
  FileClock,
  FolderTree,
  Globe,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Menu,
  Moon,
  Settings,
  Shield,
  Sliders,
  Sun,
  UserCheck,
  Users,
  X,
} from 'lucide-react';

interface Props {
  token: string | null;
  devUser: DevSessionUser;
  lang: Language;
  theme: ThemeMode;
  onToggleLang: () => void;
  onToggleTheme: () => void;
  onSessionUpdated: (token: string, user: DevSessionUser) => void;
  onLogout: () => void;
}

export const DeveloperControlCenter: React.FC<Props> = ({
  token,
  devUser,
  lang,
  theme,
  onToggleLang,
  onToggleTheme,
  onSessionUpdated,
  onLogout,
}) => {
  const isAr = lang === 'ar';
  const [section, setSection] = useState<DevNavSection>('overview');
  const [mobileOpen, setMobileOpen] = useState(false);

  const allNavItems: {
    id: DevNavSection;
    perm: string;
    ar: string;
    en: string;
    icon: React.ReactNode;
  }[] = [
    { id: 'overview', perm: 'overview', ar: 'نظرة عامة', en: 'Overview', icon: <LayoutDashboard className="w-4 h-4 shrink-0" /> },
    { id: 'users', perm: 'users', ar: 'المستخدمون', en: 'Users', icon: <Users className="w-4 h-4 shrink-0" /> },
    { id: 'subscriptions', perm: 'subscriptions', ar: 'الاشتراكات', en: 'Subscriptions', icon: <CreditCard className="w-4 h-4 shrink-0" /> },
    { id: 'ai_control', perm: 'ai_control', ar: 'تحكم الذكاء الاصطناعي', en: 'AI Control Center', icon: <Cpu className="w-4 h-4 shrink-0" /> },
    { id: 'features', perm: 'features', ar: 'إدارة الميزات', en: 'Features Management', icon: <Sliders className="w-4 h-4 shrink-0" /> },
    { id: 'content', perm: 'content', ar: 'إدارة المحتوى', en: 'Content Management', icon: <FolderTree className="w-4 h-4 shrink-0" /> },
    { id: 'notifications', perm: 'notifications', ar: 'مركز الإشعارات', en: 'Notifications Center', icon: <Bell className="w-4 h-4 shrink-0" /> },
    { id: 'support', perm: 'support', ar: 'مركز الدعم', en: 'Support Center', icon: <LifeBuoy className="w-4 h-4 shrink-0" /> },
    { id: 'analytics', perm: 'analytics', ar: 'التحليلات والتقارير', en: 'Analytics & Reports', icon: <BarChart3 className="w-4 h-4 shrink-0" /> },
    { id: 'monitoring', perm: 'monitoring', ar: 'مراقبة النظام', en: 'System Monitoring', icon: <Activity className="w-4 h-4 shrink-0" /> },
    { id: 'audit_logs', perm: 'audit_logs', ar: 'سجل الأمان', en: 'Audit Logs', icon: <FileClock className="w-4 h-4 shrink-0" /> },
    { id: 'backups', perm: 'backups', ar: 'النسخ الاحتياطي', en: 'Backup & Recovery', icon: <DatabaseBackup className="w-4 h-4 shrink-0" /> },
    { id: 'cost_simulator', perm: 'cost_simulator', ar: 'محاكي التكاليف', en: 'AI Cost Simulator', icon: <Calculator className="w-4 h-4 shrink-0" /> },
    { id: 'app_settings', perm: 'app_settings', ar: 'إعدادات التطبيق', en: 'App Settings', icon: <Settings className="w-4 h-4 shrink-0" /> },
    { id: 'profile', perm: 'profile', ar: 'حساب المطور والأمان', en: 'Developer Profile', icon: <UserCheck className="w-4 h-4 shrink-0" /> },
  ];

  const visibleNav = allNavItems.filter(
    (item) => devUser.role === 'owner' || devUser.permissions.includes(item.perm)
  );

  const selectSection = (id: DevNavSection) => {
    setSection(id);
    setMobileOpen(false);
  };

  const renderSidebarContent = () => (
    <>
      <div className="h-16 px-5 border-b border-slate-200/80 dark:border-slate-800/80 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl accent-btn-gradient text-white flex items-center justify-center shrink-0 shadow-md">
          <Shield className="w-4 h-4" />
        </div>
        <div className="min-w-0">
          <p className="font-bold text-sm tracking-tight text-slate-900 dark:text-white truncate">
            SMART STUDENT
          </p>
          <p className="text-[10px] font-semibold tracking-wider text-blue-600 dark:text-sky-400 truncate uppercase">
            Developer Control Center
          </p>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {visibleNav.map((item) => {
          const active = section === item.id;
          return (
            <button
              key={item.id}
              onClick={() => selectSection(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap ${
                active
                  ? 'accent-btn-gradient text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100/80 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              {item.icon}
              <span className="truncate">{isAr ? item.ar : item.en}</span>
            </button>
          );
        })}

        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 transition-all whitespace-nowrap mt-2"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          <span>{isAr ? 'تسجيل الخروج' : 'Logout'}</span>
        </button>
      </nav>

      <div className="p-4 border-t border-slate-200/80 dark:border-slate-800/80 text-xs space-y-1">
        <div className="flex items-center justify-between gap-2">
          <p className="font-semibold text-slate-900 dark:text-white truncate">
            {devUser.displayName}
          </p>
          <span className="px-2 py-0.5 rounded bg-violet-500/15 text-violet-600 dark:text-violet-300 font-mono text-[10px] uppercase shrink-0">
            {devUser.role}
          </span>
        </div>
        <p className="text-[11px] text-slate-500 truncate">{devUser.email}</p>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0B1120] text-slate-900 dark:text-slate-100 flex">
      {/* Desktop Sidebar */}
      <aside className="no-print hidden lg:flex w-64 shrink-0 flex-col border-e border-slate-200/80 dark:border-slate-800/80 glass-surface">
        {renderSidebarContent()}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="no-print fixed inset-0 z-50 lg:hidden flex">
          <div className="w-72 glass-surface border-e border-slate-200/80 dark:border-slate-800/80 flex flex-col h-full">
            <div className="flex justify-end p-2">
              <button
                onClick={() => setMobileOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {renderSidebarContent()}
          </div>
          <div className="flex-1 bg-black/50 backdrop-blur-xs" onClick={() => setMobileOpen(false)} />
        </div>
      )}

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="no-print sticky top-0 z-30 h-16 px-4 sm:px-6 border-b border-slate-200/80 dark:border-slate-800/80 glass-surface flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 rounded-xl border border-slate-200 dark:border-slate-700"
            >
              <Menu className="w-4 h-4" />
            </button>
            <span className="text-sm font-bold truncate">
              {isAr
                ? visibleNav.find((n) => n.id === section)?.ar
                : visibleNav.find((n) => n.id === section)?.en}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onToggleLang}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'EN' : 'AR'}</span>
            </button>
            <button
              onClick={onToggleTheme}
              className="p-2 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>
        </header>

        {devUser.mustChangePassword && section !== 'profile' && (
          <div className="no-print mx-4 sm:mx-6 mt-4 p-3.5 rounded-xl bg-amber-500/15 border border-amber-500/40 flex flex-wrap items-center justify-between gap-2 text-xs text-amber-700 dark:text-amber-300">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>
                {isAr
                  ? 'يرجى تغيير كلمة المرور الأولية لحماية حساب المالك الأساسي.'
                  : 'Please change your initial Owner password for security.'}
              </span>
            </div>
            <button
              onClick={() => setSection('profile')}
              className="px-3 py-1 rounded-lg bg-amber-600 text-white font-semibold"
            >
              {isAr ? 'تغيير الآن' : 'Update Now'}
            </button>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {section === 'overview' && (
            <DevOverviewSection token={token} lang={lang} onJumpSection={setSection} />
          )}
          {section === 'users' && <DevUsersSection token={token} lang={lang} />}
          {section === 'subscriptions' && <DevSubscriptionsSection token={token} lang={lang} />}
          {section === 'ai_control' && <DevAiControlSection token={token} lang={lang} />}
          {section === 'features' && <DevFeaturesSection token={token} lang={lang} />}
          {section === 'content' && <DevContentSection token={token} lang={lang} />}
          {section === 'notifications' && <DevNotificationsSection token={token} lang={lang} />}
          {section === 'support' && <DevSupportSection token={token} lang={lang} />}
          {section === 'analytics' && <DevAnalyticsSection token={token} lang={lang} />}
          {section === 'monitoring' && <DevMonitoringSection token={token} lang={lang} />}
          {section === 'audit_logs' && <DevAuditLogsSection token={token} lang={lang} />}
          {section === 'backups' && (
            <DevBackupsSection token={token} lang={lang} isOwner={devUser.role === 'owner'} />
          )}
          {section === 'cost_simulator' && <DevCostSimulatorSection token={token} lang={lang} />}
          {section === 'app_settings' && <DevAppSettingsSection token={token} lang={lang} />}
          {section === 'profile' && (
            <DevProfileSecuritySection
              token={token}
              devUser={devUser}
              lang={lang}
              onSessionUpdated={onSessionUpdated}
              onForceRelogin={onLogout}
            />
          )}
        </main>
      </div>
    </div>
  );
};
