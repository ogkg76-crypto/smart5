import React, { useMemo, useState } from 'react';
import {
  ChatMessageRecord,
  ExamAttempt,
  Flashcard,
  Language,
  Lecture,
  LectureSummary,
  MistakeEntry,
  NavSection,
  Subject,
} from '../types';
import { semanticSearchCorpus } from '../services/api';
import {
  Search,
  X,
  Sparkles,
  BookOpen,
  FileText,
  Layers,
  GraduationCap,
  AlertTriangle,
  MessageSquare,
  Loader2,
} from 'lucide-react';

interface Props {
  lang: Language;
  isOpen: boolean;
  onClose: () => void;
  subjects: Subject[];
  lectures: Lecture[];
  summaries: LectureSummary[];
  flashcards: Flashcard[];
  exams: ExamAttempt[];
  mistakes: MistakeEntry[];
  chatMessages: ChatMessageRecord[];
  onNavigate: (section: NavSection, lectureId?: string, pageNum?: number) => void;
}

interface SearchHit {
  id: string;
  type: 'lecture' | 'summary' | 'flashcard' | 'exam' | 'mistake' | 'chat';
  title: string;
  snippet: string;
  section: NavSection;
  lectureId?: string;
  pageNumber?: number;
  aiReason?: string;
}

export const SmartSearchModal: React.FC<Props> = ({
  lang,
  isOpen,
  onClose,
  subjects,
  lectures,
  summaries,
  flashcards,
  exams,
  mistakes,
  chatMessages,
  onNavigate,
}) => {
  const isAr = lang === 'ar';
  const [queryText, setQueryText] = useState('');
  const [aiBusy, setAiBusy] = useState(false);
  const [semanticHits, setSemanticHits] = useState<SearchHit[]>([]);
  const [error, setError] = useState('');

  const allHits = useMemo<SearchHit[]>(() => {
    const q = queryText.trim().toLowerCase();
    if (!q) return [];
    const results: SearchHit[] = [];

    for (const lec of lectures) {
      const subjName = subjects.find((s) => s.id === lec.subjectId)?.name || '';
      if (lec.title.toLowerCase().includes(q) || lec.fullTextPreview.toLowerCase().includes(q)) {
        const matchedPage = lec.extractedPages.find((p) =>
          `${p.heading} ${p.content}`.toLowerCase().includes(q)
        );
        results.push({
          id: lec.id,
          type: 'lecture',
          title: lec.title,
          snippet: matchedPage
            ? `${subjName} · Page ${matchedPage.pageNumber}: ${matchedPage.content.slice(0, 120)}...`
            : `${subjName} · ${lec.fullTextPreview.slice(0, 120)}...`,
          section: 'library',
          lectureId: lec.id,
          pageNumber: matchedPage?.pageNumber || 1,
        });
      }
    }

    for (const sum of summaries) {
      if (sum.title.toLowerCase().includes(q) || sum.contentMarkdown.toLowerCase().includes(q)) {
        results.push({
          id: sum.id,
          type: 'summary',
          title: sum.title,
          snippet: sum.contentMarkdown.slice(0, 130),
          section: 'summaries',
          lectureId: sum.lectureId,
        });
      }
    }

    for (const fc of flashcards) {
      if (fc.front.toLowerCase().includes(q) || fc.back.toLowerCase().includes(q)) {
        results.push({
          id: fc.id,
          type: 'flashcard',
          title: fc.front,
          snippet: fc.back.slice(0, 120),
          section: 'flashcards',
        });
      }
    }

    for (const ex of exams) {
      if (ex.title.toLowerCase().includes(q)) {
        results.push({
          id: ex.id,
          type: 'exam',
          title: ex.title,
          snippet: `${ex.scorePercent}% · ${ex.totalQuestions} questions`,
          section: 'exams',
        });
      }
    }

    for (const m of mistakes) {
      if (m.question.toLowerCase().includes(q) || m.topic.toLowerCase().includes(q)) {
        results.push({
          id: m.id,
          type: 'mistake',
          title: m.topic,
          snippet: m.question.slice(0, 120),
          section: 'exams',
        });
      }
    }

    for (const c of chatMessages) {
      if (c.text.toLowerCase().includes(q)) {
        results.push({
          id: c.id,
          type: 'chat',
          title: c.role === 'user' ? (isAr ? 'سؤال سابق' : 'Past Question') : isAr ? 'إجابة AI' : 'AI Reply',
          snippet: c.text.slice(0, 130),
          section: 'tutor',
          lectureId: c.lectureId,
        });
      }
    }

    return results.slice(0, 20);
  }, [queryText, lectures, summaries, flashcards, exams, mistakes, chatMessages, subjects, isAr]);

  const handleSemanticSearch = async () => {
    const q = queryText.trim();
    if (!q) return;
    setAiBusy(true);
    setError('');
    try {
      const corpus: { id: string; type: string; title: string; snippet: string; section: NavSection; lectureId?: string }[] = [
        ...lectures.slice(0, 15).map((l) => ({
          id: l.id,
          type: 'lecture',
          title: l.title,
          snippet: l.fullTextPreview.slice(0, 250),
          section: 'library' as NavSection,
          lectureId: l.id,
        })),
        ...summaries.slice(0, 10).map((s) => ({
          id: s.id,
          type: 'summary',
          title: s.title,
          snippet: s.contentMarkdown.slice(0, 250),
          section: 'summaries' as NavSection,
          lectureId: s.lectureId,
        })),
        ...flashcards.slice(0, 10).map((f) => ({
          id: f.id,
          type: 'flashcard',
          title: f.front,
          snippet: f.back.slice(0, 180),
          section: 'flashcards' as NavSection,
        })),
      ];
      if (corpus.length === 0) {
        setSemanticHits([]);
        return;
      }
      const res = await semanticSearchCorpus({
        queryText: q,
        items: corpus.map(({ id, type, title, snippet }) => ({ id, type, title, snippet })),
        lang,
      });
      const mapped: SearchHit[] = [];
      for (const m of res.matches || []) {
        const orig = corpus.find((c) => c.id === m.id);
        if (orig) {
          mapped.push({
            id: orig.id,
            type: orig.type as SearchHit['type'],
            title: orig.title,
            snippet: orig.snippet,
            section: orig.section,
            lectureId: orig.lectureId,
            aiReason: m.reason,
          });
        }
      }
      setSemanticHits(mapped);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Semantic search failed.');
    } finally {
      setAiBusy(false);
    }
  };

  if (!isOpen) return null;

  const displayedHits = semanticHits.length > 0 ? semanticHits : allHits;

  const iconForType = (type: SearchHit['type']) => {
    if (type === 'lecture') return <BookOpen className="w-4 h-4 text-blue-500" />;
    if (type === 'summary') return <FileText className="w-4 h-4 text-purple-500" />;
    if (type === 'flashcard') return <Layers className="w-4 h-4 text-emerald-500" />;
    if (type === 'exam') return <GraduationCap className="w-4 h-4 text-sky-500" />;
    if (type === 'mistake') return <AlertTriangle className="w-4 h-4 text-amber-500" />;
    return <MessageSquare className="w-4 h-4 text-indigo-400" />;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-start justify-center p-4 pt-16">
      <div className="w-full max-w-2xl glass-surface border border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-blue-600 dark:text-sky-400 shrink-0" />
          <input
            autoFocus
            value={queryText}
            onChange={(e) => {
              setQueryText(e.target.value);
              setSemanticHits([]);
            }}
            placeholder={
              isAr
                ? 'ابحث داخل المحاضرات، الملخصات، البطاقات، الأسئلة، والأخطاء...'
                : 'Search inside lectures, summaries, flashcards, exams, and mistakes...'
            }
            className="flex-1 bg-transparent text-sm text-slate-900 dark:text-slate-100 focus:outline-none"
          />
          <button
            disabled={!queryText.trim() || aiBusy}
            onClick={handleSemanticSearch}
            className="px-3 py-1.5 text-xs font-semibold accent-btn-gradient text-white rounded-lg flex items-center gap-1.5 disabled:opacity-40 whitespace-nowrap"
          >
            {aiBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            <span>{isAr ? 'بحث دلالي AI' : 'Semantic AI'}</span>
          </button>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="px-4 py-2 text-xs text-red-500 border-b border-slate-200 dark:border-slate-800">
            {error}
          </div>
        )}

        <div className="max-h-[420px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
          {!queryText.trim() ? (
            <div className="p-10 text-center text-xs text-slate-500">
              {isAr
                ? 'اكتب أي كلمة أو مفهوم للبحث الفوري في كل ملفاتك وملاحظاتك، أو اضغط "بحث دلالي AI".'
                : 'Type any keyword to search across all your lectures, summaries, flashcards, and mistakes.'}
            </div>
          ) : displayedHits.length === 0 ? (
            <div className="p-10 text-center text-xs text-slate-500">
              {isAr ? 'لم يتم العثور على نتائج مطابقة.' : 'No matching results found.'}
            </div>
          ) : (
            displayedHits.map((hit) => (
              <button
                key={`${hit.type}-${hit.id}`}
                onClick={() => {
                  onNavigate(hit.section, hit.lectureId, hit.pageNumber);
                  onClose();
                }}
                className="w-full text-start p-4 hover:bg-slate-50 dark:hover:bg-slate-800/60 flex items-start gap-3 transition-colors"
              >
                <div className="mt-0.5 shrink-0">{iconForType(hit.type)}</div>
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                      {hit.title}
                    </p>
                    <span className="text-[11px] text-slate-400 uppercase font-mono shrink-0">
                      {hit.type}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                    {hit.aiReason ? `${hit.aiReason} — ${hit.snippet}` : hit.snippet}
                  </p>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
