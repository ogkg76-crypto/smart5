import React, { useState } from 'react';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import {
  CodingLanguage,
  CodingProject,
  Language,
  Subject,
  SubscriptionPlan,
  UserProfile,
} from '../types';
import { askCodeMentor, runSandboxedCode } from '../services/api';
import {
  awardStudyXp,
  deleteDocSafe,
  getEffectiveLimit,
  makeId,
  trackAiUsageAndNotify,
} from '../services/firestoreHelpers';
import {
  Code2,
  Play,
  Sparkles,
  Save,
  Trash2,
  Loader2,
  AlertCircle,
  Terminal,
  Bug,
  BookOpen,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  projects: CodingProject[];
}

const STARTER_CODE: Record<CodingLanguage, string> = {
  python: `def binary_search(arr, target):
    lo, hi = 0, len(arr) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1

nums = [2, 5, 8, 12, 16, 23, 38]
print("Index of 16:", binary_search(nums, 16))
`,
  javascript: `function fibonacci(n) {
  const dp = [0, 1];
  for (let i = 2; i <= n; i++) {
    dp[i] = dp[i - 1] + dp[i - 2];
  }
  return dp[n];
}

console.log("Fib(10) =", fibonacci(10));
`,
  c: `#include <stdio.h>

int main() {
    int sum = 0;
    for (int i = 1; i <= 10; i++) sum += i;
    printf("Sum 1..10 = %d\\n", sum);
    return 0;
}
`,
  cpp: `#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<int> v = {3, 1, 4, 1, 5, 9};
    int total = 0;
    for (int x : v) total += x;
    cout << "Vector sum = " << total << endl;
    return 0;
}
`,
  java: `public class Main {
    public static void main(String[] args) {
        int n = 5, fact = 1;
        for (int i = 1; i <= n; i++) fact *= i;
        System.out.println("Factorial = " + fact);
    }
}
`,
};

const CHALLENGES: { titleAr: string; titleEn: string; lang: CodingLanguage; code: string }[] = [
  {
    titleAr: 'تحدي 1: عكس قائمة مرتبطة / مصفوفة (Python)',
    titleEn: 'Challenge 1: Two-Pointer Reverse (Python)',
    lang: 'python',
    code: `# Implement reverse_in_place(nums) without using slicing [::-1]
def reverse_in_place(nums):
    left, right = 0, len(nums) - 1
    while left < right:
        nums[left], nums[right] = nums[right], nums[left]
        left += 1
        right -= 1
    return nums

print(reverse_in_place([10, 20, 30, 40, 50]))
`,
  },
  {
    titleAr: 'تحدي 2: فحص الأقواس المتوازنة (JavaScript)',
    titleEn: 'Challenge 2: Valid Parentheses Stack (JS)',
    lang: 'javascript',
    code: `function isValidBrackets(s) {
  const stack = [];
  const pairs = { ')': '(', ']': '[', '}': '{' };
  for (const ch of s) {
    if ('([{'.includes(ch)) stack.push(ch);
    else if (stack.pop() !== pairs[ch]) return false;
  }
  return stack.length === 0;
}

console.log(isValidBrackets("{[()]}"), isValidBrackets("{[(])}"));
`,
  },
];

export const CodingPlaygroundView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  subjects,
  projects,
}) => {
  const isAr = lang === 'ar';
  const [title, setTitle] = useState('');
  const [language, setLanguage] = useState<CodingLanguage>('python');
  const [code, setCode] = useState(STARTER_CODE.python);
  const [stdin, setStdin] = useState('');
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || '');

  const [running, setRunning] = useState(false);
  const [mentorBusy, setMentorBusy] = useState(false);
  const [stdout, setStdout] = useState('');
  const [stderr, setStderr] = useState('');
  const [execMs, setExecMs] = useState<number | null>(null);
  const [aiReview, setAiReview] = useState('');
  const [error, setError] = useState('');
  const [savedMsg, setSavedMsg] = useState('');

  const lineCount = code.split('\n').length;

  const handleLanguageChange = (nextLang: CodingLanguage) => {
    setLanguage(nextLang);
    setCode(STARTER_CODE[nextLang]);
    setStdout('');
    setStderr('');
    setExecMs(null);
  };

  const handleRun = async () => {
    setRunning(true);
    setError('');
    setStdout('');
    setStderr('');
    try {
      const res = await runSandboxedCode({ language, code, stdin });
      setStdout(res.stdout || '');
      setStderr(res.stderr || '');
      setExecMs(res.executionMs);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Execution failed.');
    } finally {
      setRunning(false);
    }
  };

  const handleMentor = async (action: 'review' | 'debug' | 'explain') => {
    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم بلوغ الحد الشهري لطلبات AI.' : 'Monthly AI quota reached.');
      return;
    }
    setMentorBusy(true);
    setError('');
    try {
      const res = await askCodeMentor({
        language,
        code,
        stderr,
        action,
        lang,
      });
      setAiReview(res.review);
      await trackAiUsageAndNotify({ uid, xpDelta: 15 });
      await awardStudyXp(uid, profile, 15);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'AI Code Mentor failed.');
    } finally {
      setMentorBusy(false);
    }
  };

  const handleSaveProject = async () => {
    const id = makeId('code');
    const cleanTitle =
      title.trim() || `${language.toUpperCase()} — ${new Date().toLocaleTimeString()}`;
    try {
      await setDoc(doc(db, 'codingProjects', id), {
        ownerId: uid,
        subjectId: selectedSubjectId || '',
        title: cleanTitle.slice(0, 160),
        language,
        code: code.slice(0, 50000),
        lastOutput: (`${stdout}\n${stderr}`).trim().slice(0, 20000),
        aiReview: aiReview.slice(0, 15000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setTitle('');
      setSavedMsg(isAr ? 'تم حفظ المشروع البرمجي.' : 'Coding project saved.');
      setTimeout(() => setSavedMsg(''), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save project.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            {isAr ? 'مختبر البرمجة الذكي (Coding Lab)' : 'Coding Playground & AI Code Mentor'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'تشغيل فعلي معزول لأكواد Python و JavaScript و C و C++ مع مرشد AI لشرح الكود وإصلاح الأخطاء.'
              : 'Live sandboxed execution for Python, JavaScript, C, and C++ plus Gemini AI Code Mentor.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={isAr ? 'اسم المشروع...' : 'Project title...'}
            className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
          <select
            value={selectedSubjectId}
            onChange={(e) => setSelectedSubjectId(e.target.value)}
            className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
          >
            <option value="">{isAr ? 'عام' : 'General'}</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <button
            onClick={handleSaveProject}
            className="px-3.5 py-2 text-xs font-semibold border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isAr ? 'حفظ' : 'Save'}</span>
          </button>
        </div>
      </div>

      {savedMsg && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {savedMsg}
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Language & Challenge Bar */}
      <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {(
            [
              { id: 'python', label: 'Python 3' },
              { id: 'javascript', label: 'JavaScript' },
              { id: 'c', label: 'C (GCC)' },
              { id: 'cpp', label: 'C++ (G++)' },
              { id: 'java', label: 'Java (AI Trace)' },
            ] as { id: CodingLanguage; label: string }[]
          ).map((l) => (
            <button
              key={l.id}
              onClick={() => handleLanguageChange(l.id)}
              className={`px-3 py-1.5 text-xs font-mono font-medium rounded-lg transition-colors whitespace-nowrap ${
                language === l.id
                  ? 'bg-blue-600 text-white'
                  : 'border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {CHALLENGES.map((ch, idx) => (
            <button
              key={idx}
              onClick={() => {
                setLanguage(ch.lang);
                setCode(ch.code);
              }}
              className="px-2.5 py-1.5 text-xs border border-purple-200 dark:border-purple-800/70 text-purple-700 dark:text-purple-300 rounded-lg hover:bg-purple-50 dark:hover:bg-purple-950/40"
            >
              {isAr ? ch.titleAr : ch.titleEn}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Code Editor + Console */}
        <div className="lg:col-span-8 space-y-4">
          <div className="rounded-2xl overflow-hidden border border-slate-800 bg-[#0B1120] text-slate-100">
            <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                <Code2 className="w-4 h-4 text-sky-400" />
                <span>main.{language === 'python' ? 'py' : language === 'javascript' ? 'mjs' : language}</span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  disabled={running}
                  onClick={handleRun}
                  className="px-3.5 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-lg flex items-center gap-1.5"
                >
                  {running ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isAr ? 'تشغيل الكود' : 'Run Code'}</span>
                </button>
                <button
                  disabled={mentorBusy}
                  onClick={() => handleMentor('explain')}
                  className="px-2.5 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1"
                >
                  <BookOpen className="w-3.5 h-3.5 text-sky-400" />
                  <span>{isAr ? 'اشرح الكود' : 'Explain'}</span>
                </button>
                <button
                  disabled={mentorBusy}
                  onClick={() => handleMentor('debug')}
                  className="px-2.5 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1"
                >
                  <Bug className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isAr ? 'اكتشف الخطأ' : 'Debug'}</span>
                </button>
                <button
                  disabled={mentorBusy}
                  onClick={() => handleMentor('review')}
                  className="px-2.5 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>{isAr ? 'تحسين الأداء' : 'Optimize'}</span>
                </button>
              </div>
            </div>

            <div className="flex" dir="ltr">
              <div className="py-3 px-2.5 bg-slate-900/50 border-r border-slate-800 text-slate-500 font-mono text-xs select-none text-right leading-6">
                {Array.from({ length: lineCount }, (_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                spellCheck={false}
                rows={15}
                className="flex-1 p-3 bg-transparent font-mono text-xs sm:text-sm leading-6 text-slate-100 focus:outline-none resize-y"
              />
            </div>

            <div className="px-4 py-2 border-t border-slate-800 bg-slate-900/40" dir="ltr">
              <input
                value={stdin}
                onChange={(e) => setStdin(e.target.value)}
                placeholder="Standard Input (stdin) optional..."
                className="w-full text-xs font-mono bg-transparent text-slate-300 placeholder:text-slate-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Output Console */}
          <div className="rounded-2xl border border-slate-800 bg-slate-950 text-slate-100 p-4 space-y-2" dir="ltr">
            <div className="flex items-center justify-between text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                Console Output
              </span>
              {execMs !== null && <span className="tabular-nums">{execMs} ms</span>}
            </div>
            {stdout && (
              <pre className="text-xs font-mono text-emerald-300 whitespace-pre-wrap">{stdout}</pre>
            )}
            {stderr && (
              <pre className="text-xs font-mono text-rose-400 whitespace-pre-wrap">{stderr}</pre>
            )}
            {!stdout && !stderr && (
              <p className="text-xs font-mono text-slate-600">
                Click "Run Code" to execute in an isolated sandbox (5s limit).
              </p>
            )}
          </div>
        </div>

        {/* AI Code Mentor & Saved Projects */}
        <div className="lg:col-span-4 space-y-5">
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 min-h-[260px]">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-500" />
              <span>{isAr ? 'مرشد البرمجة الذكي (AI Mentor)' : 'AI Code Mentor'}</span>
            </h2>
            {mentorBusy ? (
              <div className="py-10 flex flex-col items-center gap-2 text-xs text-slate-500">
                <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                <span>{isAr ? 'جاري فحص الكود وتعقيد الخوارزمية...' : 'Analyzing code & complexity...'}</span>
              </div>
            ) : !aiReview ? (
              <p className="text-xs text-slate-500 leading-relaxed py-6">
                {isAr
                  ? 'استخدم أزرار "اشرح الكود" أو "اكتشف الخطأ" أو "تحسين الأداء" للحصول على تحليل مفصل للكود وتعقيد الوقت Big-O.'
                  : 'Use Explain, Debug, or Optimize for line-by-line mentoring, bug fixes, and Big-O complexity analysis.'}
              </p>
            ) : (
              <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed max-h-[360px] overflow-y-auto">
                {aiReview}
              </div>
            )}
          </div>

          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              {isAr ? `أكوادك المحفوظة (${projects.length})` : `Saved Snippets (${projects.length})`}
            </h3>
            {projects.length === 0 ? (
              <p className="text-xs text-slate-500">
                {isAr ? 'لا توجد أكواد محفوظة بعد.' : 'No saved snippets yet.'}
              </p>
            ) : (
              <div className="space-y-2 max-h-52 overflow-y-auto">
                {projects.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      setLanguage(p.language);
                      setCode(p.code);
                      setStdout(p.lastOutput);
                      setAiReview(p.aiReview || '');
                    }}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {p.title}
                      </p>
                      <p className="text-[11px] font-mono text-slate-500">{p.language}</p>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteDocSafe('codingProjects', p.id);
                      }}
                      className="p-1 text-slate-400 hover:text-red-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
