import React, { useEffect, useState } from 'react';
import {
  doc,
  setDoc,
  updateDoc,
  serverTimestamp,
  increment,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Folder, Language, Lecture, NavSection, Subject, UserProfile } from '../types';
import { extractLectureFile, translateLectureText } from '../services/api';
import { awardStudyXp, deleteDocSafe, makeId, trackAiUsageAndNotify } from '../services/firestoreHelpers';
import { NavigateOptions } from './DashboardView';
import {
  FolderPlus,
  FileUp,
  Search,
  Trash2,
  Edit3,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Plus,
  Loader2,
  AlertCircle,
  Languages,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  subjects: Subject[];
  folders: Folder[];
  lectures: Lecture[];
  initialLectureId?: string;
  initialPageNumber?: number;
  onOpenSectionWithLecture: (section: NavSection, opts?: NavigateOptions) => void;
}

export const LibraryView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  subjects,
  folders,
  lectures,
  initialLectureId,
  initialPageNumber,
  onOpenSectionWithLecture,
}) => {
  const isAr = lang === 'ar';
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [selectedFolderId, setSelectedFolderId] = useState<string>('all');
  const [semesterFilter, setSemesterFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Create Subject Modal/Panel
  const [showNewSubject, setShowNewSubject] = useState(false);
  const [subjName, setSubjName] = useState('');
  const [subjCode, setSubjCode] = useState('');
  const [subjCollege, setSubjCollege] = useState(profile?.college || '');
  const [subjDept, setSubjDept] = useState(profile?.department || '');
  const [subjSemester, setSubjSemester] = useState(profile?.semester || 'Fall 2026');
  const [subjYear, setSubjYear] = useState(profile?.academicYear || '2026');
  const [subjExamDate, setSubjExamDate] = useState('');

  // Create Folder
  const [newFolderName, setNewFolderName] = useState('');

  // Upload Lecture
  const [uploadSubjectId, setUploadSubjectId] = useState<string>('');
  const [uploadFolderId, setUploadFolderId] = useState<string>('');
  const [uploading, setUploading] = useState(false);
  const [uploadProgressMsg, setUploadProgressMsg] = useState('');
  const [error, setError] = useState('');

  // Rename Lecture
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameText, setRenameText] = useState('');

  // Active Lecture Reader + Translator
  const [readingLectureId, setReadingLectureId] = useState<string | null>(initialLectureId || null);
  const readingLecture = lectures.find((l) => l.id === readingLectureId) || null;
  const [currentPageIdx, setCurrentPageIdx] = useState(
    initialPageNumber ? Math.max(0, initialPageNumber - 1) : 0
  );

  // Lecture Translator inside Reader
  const [showTranslator, setShowTranslator] = useState(false);
  const [translateTarget, setTranslateTarget] = useState<Language>(isAr ? 'ar' : 'en');
  const [translateInput, setTranslateInput] = useState('');
  const [translating, setTranslating] = useState(false);
  const [translationResult, setTranslationResult] = useState<{
    translatedText: string;
    glossary: { originalTerm: string; translatedTerm: string; note?: string }[];
  } | null>(null);

  useEffect(() => {
    if (initialLectureId) {
      setReadingLectureId(initialLectureId);
      if (initialPageNumber && initialPageNumber > 0) {
        setCurrentPageIdx(initialPageNumber - 1);
      }
      setTranslationResult(null);
    }
  }, [initialLectureId, initialPageNumber]);

  const uniqueSemesters = Array.from(new Set(subjects.map((s) => s.semester).filter(Boolean)));

  const filteredLectures = lectures.filter((l) => {
    if (selectedSubjectId !== 'all' && l.subjectId !== selectedSubjectId) return false;
    if (selectedFolderId !== 'all' && (l.folderId || '') !== selectedFolderId) return false;
    if (semesterFilter !== 'all' && (l.semester || '') !== semesterFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      return l.title.toLowerCase().includes(q) || l.fileName.toLowerCase().includes(q);
    }
    return true;
  });

  const handleCreateSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjName.trim()) return;
    const id = makeId('subj');
    try {
      await setDoc(doc(db, 'subjects', id), {
        ownerId: uid,
        name: subjName.trim().slice(0, 120),
        code: subjCode.trim().slice(0, 32),
        college: subjCollege.trim().slice(0, 120),
        department: subjDept.trim().slice(0, 120),
        semester: subjSemester.trim().slice(0, 40) || 'Fall 2026',
        academicYear: subjYear.trim().slice(0, 40),
        colorToken: 'blue',
        understandingLevel: 'medium',
        priority: 'medium',
        examDate: subjExamDate,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setSubjName('');
      setSubjCode('');
      setSubjExamDate('');
      setShowNewSubject(false);
      setSelectedSubjectId(id);
      setUploadSubjectId(id);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `subjects/${id}`);
    }
  };

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetSubj = selectedSubjectId !== 'all' ? selectedSubjectId : subjects[0]?.id;
    if (!targetSubj || !newFolderName.trim()) return;
    const id = makeId('fld');
    try {
      await setDoc(doc(db, 'folders', id), {
        ownerId: uid,
        subjectId: targetSubj,
        name: newFolderName.trim().slice(0, 120),
        createdAt: serverTimestamp(),
      });
      setNewFolderName('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `folders/${id}`);
    }
  };

  const handleFilesUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const targetSubjId =
      uploadSubjectId || (selectedSubjectId !== 'all' ? selectedSubjectId : subjects[0]?.id || '');

    if (!targetSubjId) {
      setError(
        isAr
          ? 'يرجى إنشاء مادة دراسية أولًا قبل رفع المحاضرات.'
          : 'Please create a subject first before uploading lectures.'
      );
      return;
    }

    const subjObj = subjects.find((s) => s.id === targetSubjId);
    setError('');
    setUploading(true);

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        setUploadProgressMsg(
          isAr
            ? `جاري تحليل واستخراج (${i + 1}/${files.length}): ${file.name}`
            : `Extracting (${i + 1}/${files.length}): ${file.name}`
        );

        const extracted = await extractLectureFile(file);
        const lecId = makeId('lec');
        const pages = extracted.pages.length
          ? extracted.pages
          : [{ pageNumber: 1, heading: file.name, content: extracted.fullTextPreview || '' }];

        await setDoc(doc(db, 'lectures', lecId), {
          ownerId: uid,
          subjectId: targetSubjId,
          folderId: uploadFolderId || '',
          title: file.name.replace(/\.[^/.]+$/, '').slice(0, 200),
          fileName: file.name.slice(0, 200),
          fileType: extracted.fileType,
          fileSizeBytes: file.size,
          semester: subjObj?.semester || profile?.semester || 'Fall 2026',
          progressPercent: 0,
          lastPageRead: 1,
          totalPages: pages.length,
          extractedPages: pages,
          fullTextPreview: extracted.fullTextPreview.slice(0, 48000),
          analysisStatus: 'ready',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        await updateDoc(doc(db, 'users', uid), {
          storageBytesUsed: increment(file.size),
          updatedAt: serverTimestamp(),
        });

        await trackAiUsageAndNotify({
          uid,
          enableNotif: profile?.notifAiReady !== false,
          notifTitle: isAr ? 'اكتمل تحليل المحاضرة' : 'Lecture Analysis Ready',
          notifBody: isAr
            ? `تم استخراج محتوى "${file.name}" (${pages.length} صفحة/قسم) بنجاح.`
            : `Extracted "${file.name}" (${pages.length} sections) successfully.`,
          notifCategory: 'ai',
          xpDelta: 20,
        });
        await awardStudyXp(uid, profile, 20);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploading(false);
      setUploadProgressMsg('');
      e.target.value = '';
    }
  };

  const handleRenameSubmit = async (lec: Lecture) => {
    if (!renameText.trim()) return;
    try {
      await updateDoc(doc(db, 'lectures', lec.id), {
        title: renameText.trim().slice(0, 200),
        updatedAt: serverTimestamp(),
      });
      setRenamingId(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `lectures/${lec.id}`);
    }
  };

  const openReader = (lec: Lecture) => {
    setReadingLectureId(lec.id);
    setCurrentPageIdx(Math.max(0, (lec.lastPageRead || 1) - 1));
    setTranslationResult(null);
    setTranslateInput('');
  };

  const updateReadingPage = async (lec: Lecture, newIdx: number) => {
    const clamped = Math.max(0, Math.min(newIdx, lec.extractedPages.length - 1));
    setCurrentPageIdx(clamped);
    setTranslationResult(null);
    const pct = Math.round(((clamped + 1) / Math.max(lec.extractedPages.length, 1)) * 100);
    try {
      await updateDoc(doc(db, 'lectures', lec.id), {
        lastPageRead: clamped + 1,
        progressPercent: Math.max(lec.progressPercent, pct),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `lectures/${lec.id}`);
    }
  };

  const handleTranslate = async (sourceText: string) => {
    const text = sourceText.trim();
    if (!text) return;
    setTranslating(true);
    setError('');
    try {
      const res = await translateLectureText({
        text,
        targetLang: translateTarget,
      });
      setTranslationResult(res);
      await trackAiUsageAndNotify({ uid });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Translation failed.');
    } finally {
      setTranslating(false);
    }
  };

  if (readingLecture) {
    const pages = readingLecture.extractedPages || [];
    const safeIdx = Math.max(0, Math.min(currentPageIdx, Math.max(pages.length - 1, 0)));
    const activePage = pages[safeIdx] || pages[0];
    return (
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div className="space-y-1">
            <button
              onClick={() => setReadingLectureId(null)}
              className="text-xs font-semibold text-blue-600 dark:text-sky-400 hover:underline"
            >
              {isAr ? '← العودة إلى المكتبة' : '← Back to Library'}
            </button>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              {readingLecture.title}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              {readingLecture.fileType.toUpperCase()} · {isAr ? 'صفحة' : 'Page'} {safeIdx + 1} /{' '}
              {pages.length} · {readingLecture.progressPercent}% {isAr ? 'تقدم' : 'progress'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowTranslator((v) => !v)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl flex items-center gap-1.5 border transition-colors ${
                showTranslator
                  ? 'bg-purple-600 text-white border-purple-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
              }`}
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{isAr ? 'ترجمة المحاضرة' : 'Translate'}</span>
            </button>
            <button
              onClick={() => onOpenSectionWithLecture('tutor', { lectureId: readingLecture.id, tutorTab: 'explain' })}
              className="px-3 py-1.5 text-xs font-semibold accent-btn-gradient text-white rounded-xl"
            >
              {isAr ? 'شرح المحاضرة AI' : 'AI Explain'}
            </button>
            <button
              onClick={() => onOpenSectionWithLecture('summaries', { lectureId: readingLecture.id })}
              className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200"
            >
              {isAr ? 'تلخيص' : 'Summarize'}
            </button>
            <button
              onClick={() => onOpenSectionWithLecture('exams', { lectureId: readingLecture.id })}
              className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200"
            >
              {isAr ? 'إنشاء أسئلة' : 'Quiz'}
            </button>
            <button
              onClick={() => onOpenSectionWithLecture('mindmaps', { lectureId: readingLecture.id })}
              className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200"
            >
              {isAr ? 'خريطة ذهنية' : 'Mind Map'}
            </button>
          </div>
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 max-h-[580px] overflow-y-auto space-y-1.5">
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 px-2 pb-2">
              {isAr ? 'أقسام وصفحات المحاضرة' : 'Lecture Pages & Chapters'}
            </p>
            {pages.map((p, idx) => (
              <button
                key={idx}
                onClick={() => updateReadingPage(readingLecture, idx)}
                className={`w-full text-start px-3 py-2 rounded-xl text-xs transition-colors ${
                  idx === safeIdx
                    ? 'bg-blue-50 dark:bg-sky-950/50 text-blue-700 dark:text-sky-300 font-semibold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span className="tabular-nums">{p.pageNumber}. </span>
                {p.heading}
                {p.timestamp ? ` (${p.timestamp})` : ''}
              </button>
            ))}
          </div>

          <div className="lg:col-span-8 space-y-6">
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col justify-between min-h-[420px]">
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                    {activePage?.heading}
                  </h2>
                  {activePage?.timestamp && (
                    <span className="text-xs font-mono text-slate-500">{activePage.timestamp}</span>
                  )}
                </div>
                <div className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {activePage?.content}
                </div>
              </div>

              <div className="flex items-center justify-between pt-6 mt-6 border-t border-slate-100 dark:border-slate-800">
                <button
                  disabled={safeIdx === 0}
                  onClick={() => updateReadingPage(readingLecture, safeIdx - 1)}
                  className="px-3.5 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl disabled:opacity-40 flex items-center gap-1"
                >
                  <ChevronRight className="w-4 h-4" />
                  <span>{isAr ? 'السابق' : 'Previous'}</span>
                </button>
                <span className="text-xs text-slate-500 tabular-nums">
                  {safeIdx + 1} / {pages.length}
                </span>
                <button
                  disabled={safeIdx >= pages.length - 1}
                  onClick={() => updateReadingPage(readingLecture, safeIdx + 1)}
                  className="px-3.5 py-1.5 text-xs font-medium bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl disabled:opacity-40 flex items-center gap-1"
                >
                  <span>{isAr ? 'التالي' : 'Next'}</span>
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Scientific Lecture Translator Panel */}
            {showTranslator && (
              <div className="glass-surface border border-purple-300/60 dark:border-purple-800/60 rounded-2xl p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Languages className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      {isAr ? 'المترجم الأكاديمي مع مسرد المصطلحات' : 'Academic Translator & Scientific Glossary'}
                    </h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={translateTarget}
                      onChange={(e) => setTranslateTarget(e.target.value as Language)}
                      className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                    >
                      <option value="ar">{isAr ? 'ترجمة إلى العربية' : 'Translate to Arabic'}</option>
                      <option value="en">{isAr ? 'ترجمة إلى الإنجليزية' : 'Translate to English'}</option>
                    </select>
                    <button
                      disabled={translating}
                      onClick={() => handleTranslate(translateInput.trim() || activePage?.content || '')}
                      className="px-3.5 py-1.5 text-xs font-semibold accent-btn-gradient text-white rounded-lg flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {translating && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      <span>{translateInput.trim() ? (isAr ? 'ترجمة المقطع' : 'Translate Snippet') : isAr ? 'ترجمة الصفحة الحالية' : 'Translate Current Page'}</span>
                    </button>
                  </div>
                </div>

                <textarea
                  rows={2}
                  value={translateInput}
                  onChange={(e) => setTranslateInput(e.target.value)}
                  placeholder={
                    isAr
                      ? 'الصق فقرة معينة لترجمتها، أو اتركه فارغًا لترجمة الصفحة الحالية بالكامل...'
                      : 'Optional: paste a specific paragraph to translate, or leave blank to translate the full current page...'
                  }
                  className="w-full p-3 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
                />

                {translationResult && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                        <p className="text-[11px] font-semibold text-slate-500">
                          {isAr ? 'النص الأصلي' : 'Original Text'}
                        </p>
                        <p className="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap max-h-60 overflow-y-auto">
                          {(translateInput.trim() || activePage?.content || '').slice(0, 3000)}
                        </p>
                      </div>
                      <div className="p-3.5 rounded-xl bg-purple-50/70 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900/60 space-y-1">
                        <p className="text-[11px] font-semibold text-purple-700 dark:text-purple-300">
                          {isAr ? 'الترجمة العلمية' : 'Translated Text'}
                        </p>
                        <p className="text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap max-h-60 overflow-y-auto leading-relaxed">
                          {translationResult.translatedText}
                        </p>
                      </div>
                    </div>

                    {translationResult.glossary?.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          {isAr ? 'المصطلحات العلمية المستخرجة:' : 'Extracted Scientific Glossary:'}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {translationResult.glossary.map((g, i) => (
                            <div
                              key={i}
                              className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                            >
                              <span className="font-bold text-slate-900 dark:text-white">{g.originalTerm}</span>
                              <span className="text-slate-400"> → </span>
                              <span className="font-semibold text-purple-700 dark:text-purple-300">{g.translatedTerm}</span>
                              {g.note && <p className="text-[11px] text-slate-500 mt-0.5">{g.note}</p>}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  const subjectFolders = folders.filter(
    (f) => selectedSubjectId === 'all' || f.subjectId === selectedSubjectId
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'مكتبتي والمواد الدراسية' : 'My Library & Courses'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'ارفع ملفات PDF، Word، PowerPoint، الصور (OCR)، النصوص، الصوتيات، والفيديو.'
              : 'Upload PDF, Word, PowerPoint, Images (OCR), Text, Audio, and Video lectures.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowNewSubject((v) => !v)}
            className="px-4 py-2 text-sm font-medium border border-slate-200 dark:border-slate-700 glass-surface text-slate-800 dark:text-slate-100 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'مادة دراسية جديدة' : 'New Subject'}</span>
          </button>

          <label className="px-4 py-2 text-sm font-semibold accent-btn-gradient text-white rounded-xl cursor-pointer flex items-center gap-2 whitespace-nowrap shrink-0 shadow-md">
            <FileUp className="w-4 h-4" />
            <span>{isAr ? 'رفع محاضرة / عدة ملفات' : 'Upload Lectures'}</span>
            <input
              type="file"
              multiple
              accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.md,.jpg,.jpeg,.png,.webp,.mp3,.wav,.webm,.m4a,.mp4,.mov"
              onChange={handleFilesUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {uploading && (
        <div className="p-4 rounded-xl bg-blue-50 dark:bg-sky-950/40 border border-blue-200 dark:border-sky-800 flex items-center gap-3 text-sm text-blue-900 dark:text-sky-200">
          <Loader2 className="w-4 h-4 animate-spin shrink-0" />
          <span>{uploadProgressMsg}</span>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {showNewSubject && (
        <form
          onSubmit={handleCreateSubject}
          className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
        >
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {isAr ? 'إضافة مادة دراسية' : 'Create Academic Subject'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <input
              required
              placeholder={isAr ? 'اسم المادة (مثل: هياكل البيانات)' : 'Subject Name'}
              value={subjName}
              onChange={(e) => setSubjName(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <input
              placeholder={isAr ? 'كود المادة (CS201)' : 'Course Code'}
              value={subjCode}
              onChange={(e) => setSubjCode(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <input
              placeholder={isAr ? 'الكلية' : 'College / Faculty'}
              value={subjCollege}
              onChange={(e) => setSubjCollege(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <input
              placeholder={isAr ? 'القسم / التخصص' : 'Department'}
              value={subjDept}
              onChange={(e) => setSubjDept(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <input
              placeholder={isAr ? 'الفصل الدراسي (Fall 2026)' : 'Semester'}
              value={subjSemester}
              onChange={(e) => setSubjSemester(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <input
              placeholder={isAr ? 'السنة الدراسية' : 'Academic Year'}
              value={subjYear}
              onChange={(e) => setSubjYear(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <input
              type="date"
              value={subjExamDate}
              onChange={(e) => setSubjExamDate(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <div className="flex items-center gap-2">
              <button
                type="submit"
                className="flex-1 py-2 px-4 accent-btn-gradient text-white text-sm font-semibold rounded-lg"
              >
                {isAr ? 'حفظ المادة' : 'Save Subject'}
              </button>
              <button
                type="button"
                onClick={() => setShowNewSubject(false)}
                className="py-2 px-3 border border-slate-200 dark:border-slate-700 text-sm rounded-lg"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Filters */}
      <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
        <div className="md:col-span-4 relative">
          <Search className="w-4 h-4 text-slate-400 absolute top-2.5 start-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'ابحث باسم المحاضرة...' : 'Search lecture by name...'}
            className="w-full ps-9 pe-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
        </div>

        <select
          value={selectedSubjectId}
          onChange={(e) => {
            setSelectedSubjectId(e.target.value);
            setUploadSubjectId(e.target.value === 'all' ? '' : e.target.value);
            setSelectedFolderId('all');
          }}
          className="md:col-span-3 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
        >
          <option value="all">{isAr ? 'جميع المواد الدراسية' : 'All Subjects'}</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name} {s.code ? `(${s.code})` : ''}
            </option>
          ))}
        </select>

        <select
          value={selectedFolderId}
          onChange={(e) => {
            setSelectedFolderId(e.target.value);
            setUploadFolderId(e.target.value === 'all' ? '' : e.target.value);
          }}
          className="md:col-span-2 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
        >
          <option value="all">{isAr ? 'كل المجلدات' : 'All Folders'}</option>
          {subjectFolders.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          ))}
        </select>

        <select
          value={semesterFilter}
          onChange={(e) => setSemesterFilter(e.target.value)}
          className="md:col-span-3 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
        >
          <option value="all">{isAr ? 'كل الفصول الدراسية' : 'All Semesters'}</option>
          {uniqueSemesters.map((sem) => (
            <option key={sem} value={sem}>
              {sem}
            </option>
          ))}
        </select>
      </div>

      {subjects.length > 0 && (
        <form onSubmit={handleCreateFolder} className="flex flex-wrap items-center gap-2">
          <input
            type="text"
            value={newFolderName}
            onChange={(e) => setNewFolderName(e.target.value)}
            placeholder={isAr ? 'اسم مجلد جديد داخل المادة المحددة...' : 'New folder inside selected subject...'}
            className="px-3 py-1.5 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-lg w-64"
          />
          <button
            type="submit"
            className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg glass-surface hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-1.5"
          >
            <FolderPlus className="w-3.5 h-3.5" />
            <span>{isAr ? 'إنشاء مجلد' : 'Add Folder'}</span>
          </button>
        </form>
      )}

      {filteredLectures.length === 0 ? (
        <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center space-y-3">
          <BookOpen className="w-9 h-9 text-slate-400 mx-auto" />
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {subjects.length === 0
              ? isAr
                ? 'ابدأ بإنشاء مادة دراسية ثم ارفع محاضراتك لتحليلها فورًا.'
                : 'Create your first academic subject, then upload lectures to analyze them.'
              : isAr
                ? 'لا توجد محاضرات مطابقة للبحث أو الفلتر الحالي.'
                : 'No lectures match the current filter.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLectures.map((lec) => {
            const subj = subjects.find((s) => s.id === lec.subjectId);
            const fld = folders.find((f) => f.id === lec.folderId);
            return (
              <div
                key={lec.id}
                className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between gap-4 hover:border-blue-500/50 transition-colors"
              >
                <div className="space-y-2">
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {subj?.name || 'Subject'}
                    {fld ? ` / ${fld.name}` : ''} · {lec.fileType.toUpperCase()}
                  </p>

                  {renamingId === lec.id ? (
                    <div className="flex items-center gap-2">
                      <input
                        value={renameText}
                        onChange={(e) => setRenameText(e.target.value)}
                        className="flex-1 px-2.5 py-1 text-sm border border-slate-300 dark:border-slate-700 rounded bg-slate-50 dark:bg-slate-950"
                      />
                      <button
                        onClick={() => handleRenameSubmit(lec)}
                        className="px-2.5 py-1 text-xs bg-blue-600 text-white rounded"
                      >
                        {isAr ? 'حفظ' : 'Save'}
                      </button>
                    </div>
                  ) : (
                    <h3 className="text-base font-bold text-slate-900 dark:text-white line-clamp-2">
                      {lec.title}
                    </h3>
                  )}

                  <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums flex items-center justify-between pt-1">
                    <span>
                      {lec.totalPages} {isAr ? 'صفحة/قسم' : 'pages'}
                    </span>
                    <span>{lec.progressPercent}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full accent-btn-gradient transition-all"
                      style={{ width: `${lec.progressPercent}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openReader(lec)}
                      className="px-3 py-1.5 text-xs font-semibold bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg"
                    >
                      {isAr ? 'قراءة' : 'Read'}
                    </button>
                    <button
                      onClick={() => onOpenSectionWithLecture('tutor', { lectureId: lec.id, tutorTab: 'explain' })}
                      className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      {isAr ? 'شرح AI' : 'AI Tutor'}
                    </button>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      aria-label="Rename"
                      onClick={() => {
                        setRenamingId(lec.id);
                        setRenameText(lec.title);
                      }}
                      className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-white"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      aria-label="Delete"
                      onClick={() => deleteDocSafe('lectures', lec.id)}
                      className="p-1.5 text-slate-500 hover:text-red-500"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
