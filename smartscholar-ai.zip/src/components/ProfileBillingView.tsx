import React, { useRef, useState } from 'react';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { signOut, deleteUser } from 'firebase/auth';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import {
  AccentTheme,
  AppNotification,
  FontScale,
  Language,
  SubscriptionPlan,
  ThemeMode,
  TutorPersona,
  UserProfile,
} from '../types';
import { updateUserPreferences } from '../services/firestoreHelpers';
import { submitSupportTicket } from '../services/api';
import {
  Bell,
  Check,
  CreditCard,
  LifeBuoy,
  LogOut,
  Palette,
  Send,
  Trash2,
  User,
} from 'lucide-react';

interface Props {
  lang: Language;
  theme: ThemeMode;
  accentTheme: AccentTheme;
  fontScale: FontScale;
  uid: string;
  profile: UserProfile | null;
  activePlanId: string;
  plans: SubscriptionPlan[];
  notifications: AppNotification[];
  onToggleLang: () => void;
  onToggleTheme: () => void;
  onChangeAccent: (a: AccentTheme) => void;
  onChangeFontScale: (f: FontScale) => void;
}

const ACCENT_OPTIONS: { id: AccentTheme; labelAr: string; labelEn: string; hex: string }[] = [
  { id: 'electric', labelAr: 'أزرق كهربائي', labelEn: 'Electric Blue', hex: '#2563eb' },
  { id: 'purple', labelAr: 'أرجواني عميق', labelEn: 'Deep Purple', hex: '#7c3aed' },
  { id: 'emerald', labelAr: 'أخضر زمردي', labelEn: 'Emerald', hex: '#059669' },
  { id: 'amber', labelAr: 'كهرماني دافئ', labelEn: 'Warm Amber', hex: '#d97706' },
];

export const ProfileBillingView: React.FC<Props> = ({
  lang,
  theme,
  accentTheme,
  fontScale,
  uid,
  profile,
  activePlanId,
  plans,
  notifications,
  onToggleLang,
  onToggleTheme,
  onChangeAccent,
  onChangeFontScale,
}) => {
  const isAr = lang === 'ar';
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [college, setCollege] = useState(profile?.college || '');
  const [department, setDepartment] = useState(profile?.department || '');
  const [academicYear, setAcademicYear] = useState(profile?.academicYear || '');
  const [semester, setSemester] = useState(profile?.semester || '');
  const [defaultPersona, setDefaultPersona] = useState<TutorPersona>(
    profile?.defaultPersona || 'professor'
  );
  const [explanationLang, setExplanationLang] = useState<Language>(
    profile?.explanationLang || lang
  );
  const [voiceSpeed, setVoiceSpeed] = useState<number>(profile?.voiceSpeed || 1);
  const [showOnLeaderboard, setShowOnLeaderboard] = useState<boolean>(
    Boolean(profile?.showOnLeaderboard)
  );
  const [notifStudy, setNotifStudy] = useState(profile?.notifStudyReminders !== false);
  const [notifExam, setNotifExam] = useState(profile?.notifExamAlerts !== false);
  const [notifAi, setNotifAi] = useState(profile?.notifAiReady !== false);
  const [savedMsg, setSavedMsg] = useState('');

  const [billingMsg, setBillingMsg] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);

  const supportFormRef = useRef<HTMLFormElement | null>(null);
  const [tktCategory, setTktCategory] = useState<'bug' | 'billing' | 'ai' | 'feature'>('bug');
  const [tktSubject, setTktSubject] = useState('');
  const [tktMessage, setTktMessage] = useState('');
  const [tktSentMsg, setTktSentMsg] = useState('');

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateUserPreferences(uid, {
      displayName: displayName.trim() || profile?.displayName || 'Student',
      college: college.trim(),
      department: department.trim(),
      academicYear: academicYear.trim(),
      semester: semester.trim(),
      accentTheme,
      fontScale,
      defaultPersona,
      explanationLang,
      voiceSpeed,
      showOnLeaderboard,
      notifStudyReminders: notifStudy,
      notifExamAlerts: notifExam,
      notifAiReady: notifAi,
    });
    setSavedMsg(isAr ? 'تم حفظ تفضيلاتك وإعدادات الواجهة.' : 'Profile & customization saved.');
    setTimeout(() => setSavedMsg(''), 3000);
  };

  const handleRequestUpgrade = (plan: SubscriptionPlan) => {
    setTktCategory('billing');
    setTktSubject(
      isAr ? `طلب ترقية إلى باقة ${plan.nameAr}` : `Upgrade request for ${plan.nameEn}`
    );
    setTktMessage(
      isAr
        ? `أرغب في تفعيل باقة ${plan.nameAr} لحسابي (${profile?.email || ''}).`
        : `I would like to activate the ${plan.nameEn} plan for my account (${profile?.email || ''}).`
    );
    supportFormRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const handleMarkNotifRead = async (n: AppNotification) => {
    try {
      await updateDoc(doc(db, 'notifications', n.id), { isRead: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notifications/${n.id}`);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await updateDoc(doc(db, 'users', uid), {
        displayName: 'Deleted Student',
        updatedAt: serverTimestamp(),
      });
      if (auth.currentUser) {
        await deleteUser(auth.currentUser);
      }
    } catch (err) {
      setBillingMsg(
        err instanceof Error
          ? err.message
          : isAr
            ? 'يرجى إعادة تسجيل الدخول لحذف الحساب.'
            : 'Please re-authenticate before deleting your account.'
      );
    }
  };

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tktSubject.trim() || !tktMessage.trim()) return;
    await submitSupportTicket({
      category: tktCategory,
      priority: 'medium',
      subject: tktSubject.trim(),
      message: tktMessage.trim(),
      ownerName: profile?.displayName,
    });
    setTktSubject('');
    setTktMessage('');
    setTktSentMsg(
      isAr ? 'تم إرسال تذكرتك لفريق الدعم الفني بنجاح.' : 'Support ticket submitted to the team.'
    );
    setTimeout(() => setTktSentMsg(''), 4000);
  };

  const activePlan = plans.find((p) => p.id === activePlanId) || plans[0];

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'حسابي، التخصيص الذكي، والاشتراكات' : 'Profile, Personalization & Plans'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {profile?.email} · {isAr ? 'الباقة الحالية:' : 'Current Plan:'}{' '}
            {activePlan ? (isAr ? activePlan.nameAr : activePlan.nameEn) : 'Free'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => signOut(auth)}
            className="px-4 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            <LogOut className="w-4 h-4" />
            <span>{isAr ? 'تسجيل الخروج' : 'Sign Out'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          onSubmit={handleSaveProfile}
          className="lg:col-span-6 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5"
        >
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <User className="w-4 h-4" />
            <span>{isAr ? 'البيانات الجامعية وتخصيص المدرس والواجهة' : 'Academic Profile & UI Personalization'}</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 block mb-1">{isAr ? 'الاسم' : 'Name'}</label>
              <input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">{isAr ? 'الكلية' : 'College'}</label>
              <input
                value={college}
                onChange={(e) => setCollege(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">{isAr ? 'القسم' : 'Department'}</label>
              <input
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">
                {isAr ? 'السنة / الفرقة الدراسية' : 'Academic Year'}
              </label>
              <input
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs text-slate-500 block mb-1">
                {isAr ? 'الفصل الدراسي الحالي' : 'Current Semester'}
              </label>
              <input
                value={semester}
                onChange={(e) => setSemester(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
          </div>

          {/* Theme Colors & Typography Scale */}
          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3">
            <p className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5" />
              <span>{isAr ? 'تخصيص الألوان وحجم الخط والمدرس' : 'Theme Color, Font Size & AI Defaults'}</span>
            </p>

            <div className="flex flex-wrap items-center gap-2">
              {ACCENT_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeAccent(opt.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border flex items-center gap-2 transition-colors ${
                    accentTheme === opt.id
                      ? 'border-slate-900 dark:border-white bg-slate-100 dark:bg-slate-800 font-semibold'
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0"
                    style={{ backgroundColor: opt.hex }}
                  />
                  <span>{isAr ? opt.labelAr : opt.labelEn}</span>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">
                  {isAr ? 'حجم الخط' : 'Font Scale'}
                </label>
                <select
                  value={fontScale}
                  onChange={(e) => onChangeFontScale(e.target.value as FontScale)}
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  <option value="sm">{isAr ? 'مدمج' : 'Compact'}</option>
                  <option value="md">{isAr ? 'قياسي' : 'Default'}</option>
                  <option value="lg">{isAr ? 'كبير مريح' : 'Large'}</option>
                </select>
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">
                  {isAr ? 'المدرس الافتراضي' : 'Default Persona'}
                </label>
                <select
                  value={defaultPersona}
                  onChange={(e) => setDefaultPersona(e.target.value as TutorPersona)}
                  className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  <option value="professor">{isAr ? 'الأستاذ الجامعي' : 'Professor'}</option>
                  <option value="simple">{isAr ? 'المبسط' : 'Simple Tutor'}</option>
                  <option value="exam_coach">{isAr ? 'مدرب الامتحان' : 'Exam Coach'}</option>
                  <option value="coding_mentor">{isAr ? 'مرشد البرمجة' : 'Coding Mentor'}</option>
                </select>
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">
                  {isAr ? 'لغة الشرح وسرعة الصوت' : 'AI Lang & Speed'}
                </label>
                <div className="flex gap-1.5">
                  <select
                    value={explanationLang}
                    onChange={(e) => setExplanationLang(e.target.value as Language)}
                    className="flex-1 px-2 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="ar">AR</option>
                    <option value="en">EN</option>
                  </select>
                  <select
                    value={voiceSpeed}
                    onChange={(e) => setVoiceSpeed(Number(e.target.value))}
                    className="flex-1 px-2 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                  >
                    <option value={0.85}>0.85x</option>
                    <option value={1}>1.0x</option>
                    <option value={1.25}>1.25x</option>
                    <option value={1.5}>1.5x</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2.5 text-xs">
            <p className="font-semibold text-slate-700 dark:text-slate-300">
              {isAr ? 'الإشعارات والخصوصية' : 'Notifications & Privacy'}
            </p>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={notifStudy}
                onChange={(e) => setNotifStudy(e.target.checked)}
              />
              <span>{isAr ? 'تذكير بمواعيد المذاكرة والمراجعة' : 'Study & revision reminders'}</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={notifExam}
                onChange={(e) => setNotifExam(e.target.checked)}
              />
              <span>{isAr ? 'تنبيهات مواعيد الامتحانات' : 'Exam countdown alerts'}</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={notifAi} onChange={(e) => setNotifAi(e.target.checked)} />
              <span>{isAr ? 'إشعارات اكتمال التحليل والتلخيص' : 'AI processing completion alerts'}</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={showOnLeaderboard}
                onChange={(e) => setShowOnLeaderboard(e.target.checked)}
              />
              <span>{isAr ? 'الظهور في لوحة متصدري التحديات' : 'Appear on public challenge leaderboard'}</span>
            </label>
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={onToggleLang}
                className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                {lang === 'ar' ? 'التبديل إلى English' : 'Switch to العربية'}
              </button>
              <button
                type="button"
                onClick={onToggleTheme}
                className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                {theme === 'dark' ? (isAr ? 'الوضع الفاتح' : 'Light Mode') : isAr ? 'الوضع الليلي' : 'Dark Mode'}
              </button>
            </div>
          </div>

          {savedMsg && <p className="text-xs text-emerald-600">{savedMsg}</p>}

          <button
            type="submit"
            className="w-full py-2.5 accent-btn-gradient text-white text-sm font-semibold rounded-xl"
          >
            {isAr ? 'حفظ التغييرات والتخصيص' : 'Save Profile & Customization'}
          </button>
        </form>

        {/* Notifications Center */}
        <div className="lg:col-span-6 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="w-4 h-4" />
            <span>
              {isAr
                ? `الإشعارات الذكية (${notifications.filter((n) => !n.isRead).length} غير مقروء)`
                : `Notifications (${notifications.filter((n) => !n.isRead).length} unread)`}
            </span>
          </h2>
          {notifications.length === 0 ? (
            <p className="text-sm text-slate-500 py-8 text-center">
              {isAr ? 'لا توجد إشعارات حاليًا.' : 'No notifications yet.'}
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-72 overflow-y-auto">
              {notifications.map((n) => (
                <div key={n.id} className="py-3 flex items-start justify-between gap-3">
                  <div>
                    <p
                      className={`text-sm font-medium ${
                        n.isRead ? 'text-slate-500' : 'text-slate-900 dark:text-white'
                      }`}
                    >
                      {n.title}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">{n.body}</p>
                  </div>
                  {!n.isRead && (
                    <button
                      onClick={() => handleMarkNotifRead(n)}
                      className="text-xs text-blue-600 dark:text-sky-400 shrink-0"
                    >
                      {isAr ? 'تحديد كمقروء' : 'Mark read'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Usage Breakdown */}
          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2 text-xs">
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              {isAr ? 'الاستهلاك الحالي للباقة' : 'Current Plan Consumption'}
            </p>
            <div className="flex justify-between tabular-nums">
              <span>{isAr ? 'طلبات الذكاء الاصطناعي:' : 'AI Requests:'}</span>
              <span>
                {profile?.aiRequestsUsed ?? 0} / {activePlan?.aiRequestLimit ?? 30}
              </span>
            </div>
            <div className="flex justify-between tabular-nums">
              <span>{isAr ? 'مساحة التخزين المستخدمة:' : 'Storage Used:'}</span>
              <span>
                {((profile?.storageBytesUsed ?? 0) / (1024 * 1024)).toFixed(2)} MB /{' '}
                {activePlan?.storageLimitMb ?? 150} MB
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Subscription Plans (Read-only info + Upgrade request via Management) */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              <span>{isAr ? 'باقات الاشتراك المتاحة' : 'Subscription Plans'}</span>
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {isAr
                ? 'يتم تفعيل وترقية الباقات ومراجعة الطلبات من خلال الإدارة.'
                : 'Plan activations and upgrades are managed by platform administration.'}
            </p>
          </div>
        </div>

        {billingMsg && (
          <div className="p-3 rounded-xl bg-blue-50 dark:bg-sky-950/30 border border-blue-200 dark:border-sky-800 text-xs text-blue-800 dark:text-sky-200">
            {billingMsg}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {plans
            .filter((p) => p.isActive)
            .map((plan) => {
              const isCurrent = activePlanId === plan.id;
              const features = isAr ? plan.featuresAr || [] : plan.featuresEn || [];
              return (
                <div
                  key={plan.id}
                  className={`glass-surface border rounded-2xl p-6 flex flex-col justify-between space-y-5 ${
                    isCurrent
                      ? 'border-blue-600 dark:border-sky-500 shadow-lg'
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="space-y-3">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {isAr ? plan.nameAr : plan.nameEn}
                    </h3>
                    <p className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums">
                      {plan.priceMonthly} {plan.currency}
                      <span className="text-xs font-normal text-slate-500">
                        /{isAr ? 'شهر' : 'mo'}
                      </span>
                    </p>
                    <p className="text-xs text-slate-500 tabular-nums">
                      {plan.aiRequestLimit} {isAr ? 'طلب AI' : 'AI requests'} · {plan.storageLimitMb} MB
                    </p>
                    <ul className="space-y-2 pt-2 text-xs text-slate-600 dark:text-slate-300">
                      {features.map((f, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {isCurrent ? (
                    <div className="w-full py-2.5 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 text-center">
                      {isAr ? 'الباقة الحالية' : 'Current Plan'}
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleRequestUpgrade(plan)}
                      className="w-full py-2.5 text-xs font-semibold rounded-xl accent-btn-gradient text-white"
                    >
                      {isAr ? 'طلب ترقية عبر الإدارة' : 'Request Upgrade'}
                    </button>
                  )}
                </div>
              );
            })}
        </div>
      </div>

      {/* Support Ticket & Delete Account */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          ref={supportFormRef}
          onSubmit={handleSubmitTicket}
          className="lg:col-span-6 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-3"
        >
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <LifeBuoy className="w-4 h-4 text-blue-500" />
            <span>{isAr ? 'الدعم الفني والتواصل مع الإدارة' : 'Help & Support Ticket'}</span>
          </h3>
          {tktSentMsg && <p className="text-xs text-emerald-600">{tktSentMsg}</p>}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <select
              value={tktCategory}
              onChange={(e) => setTktCategory(e.target.value as typeof tktCategory)}
              className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="bug">{isAr ? 'عطل تقني' : 'Bug'}</option>
              <option value="ai">{isAr ? 'خدمة AI' : 'AI Issue'}</option>
              <option value="billing">{isAr ? 'اشتراك / دفع' : 'Billing'}</option>
              <option value="feature">{isAr ? 'اقتراح ميزة' : 'Feature'}</option>
            </select>
            <input
              value={tktSubject}
              onChange={(e) => setTktSubject(e.target.value)}
              required
              placeholder={isAr ? 'عنوان المشكلة...' : 'Ticket subject...'}
              className="sm:col-span-2 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>
          <textarea
            rows={2}
            value={tktMessage}
            onChange={(e) => setTktMessage(e.target.value)}
            required
            placeholder={isAr ? 'اشرح المشكلة أو استفسارك بالتفصيل...' : 'Describe your issue...'}
            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl inline-flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isAr ? 'إرسال تذكرة الدعم' : 'Submit Ticket'}</span>
          </button>
        </form>

        <div className="lg:col-span-6 glass-surface border border-red-200 dark:border-red-900/60 rounded-2xl p-6 space-y-3">
          <h3 className="text-sm font-bold text-red-700 dark:text-red-400">
            {isAr ? 'حذف الحساب والبيانات' : 'Delete Account'}
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            {isAr
              ? 'سيتم إزالة حسابك وبياناتك الشخصية نهائيًا.'
              : 'Permanently remove your student account and personal records.'}
          </p>
          {!confirmDelete ? (
            <button
              onClick={() => setConfirmDelete(true)}
              className="px-4 py-2 text-xs font-medium border border-red-300 text-red-700 dark:text-red-400 rounded-xl flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{isAr ? 'حذف الحساب' : 'Delete Account'}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={handleDeleteAccount}
                className="px-4 py-2 text-xs font-medium bg-red-600 text-white rounded-xl"
              >
                {isAr ? 'تأكيد الحذف النهائي' : 'Confirm Deletion'}
              </button>
              <button
                onClick={() => setConfirmDelete(false)}
                className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-xl"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
