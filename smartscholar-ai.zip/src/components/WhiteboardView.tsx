import React, { useEffect, useRef, useState } from 'react';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import {
  Language,
  Subject,
  SubscriptionPlan,
  UserProfile,
  WhiteboardAiMode,
  WhiteboardDoc,
} from '../types';
import { analyzeWhiteboard } from '../services/api';
import {
  awardStudyXp,
  deleteDocSafe,
  getEffectiveLimit,
  makeId,
  trackAiUsageAndNotify,
} from '../services/firestoreHelpers';
import {
  PenTool,
  Eraser,
  Minus,
  Square,
  Circle,
  Type as TypeIcon,
  Undo2,
  Redo2,
  Trash2,
  Sparkles,
  Download,
  Save,
  Loader2,
  AlertCircle,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  whiteboards: WhiteboardDoc[];
}

type DrawTool = 'pen' | 'eraser' | 'line' | 'rect' | 'circle' | 'text';

const MATH_SYMBOLS = ['∑', '∫', '√', 'π', 'θ', 'Δ', '≤', '≥', '≠', '∞', '→', 'λ'];
const COLORS = ['#0f172a', '#2563eb', '#7c3aed', '#dc2626', '#059669', '#d97706'];

export const WhiteboardView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  subjects,
  whiteboards,
}) => {
  const isAr = lang === 'ar';
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const snapshotBeforeShapeRef = useRef<ImageData | null>(null);

  const [tool, setTool] = useState<DrawTool>('pen');
  const [color, setColor] = useState('#2563eb');
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [drawing, setDrawing] = useState(false);
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null);

  const [history, setHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);

  const [textDraft, setTextDraft] = useState('');
  const [boardTitle, setBoardTitle] = useState('');
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || '');
  const [aiMode, setAiMode] = useState<WhiteboardAiMode>('solve');
  const [aiNote, setAiNote] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [savedNotice, setSavedNotice] = useState('');

  const initBlankCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    // Subtle engineering dot grid
    ctx.fillStyle = '#e2e8f0';
    for (let x = 24; x < canvas.width; x += 28) {
      for (let y = 24; y < canvas.height; y += 28) {
        ctx.fillRect(x, y, 1.5, 1.5);
      }
    }
    const url = canvas.toDataURL('image/png');
    setHistory([url]);
    setHistoryIdx(0);
  };

  useEffect(() => {
    initBlankCanvas();
  }, []);

  const pushHistory = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    setHistory((prev) => {
      const sliced = prev.slice(0, historyIdx + 1);
      const next = [...sliced, url].slice(-25);
      setHistoryIdx(next.length - 1);
      return next;
    });
  };

  const restoreHistoryAt = (idx: number) => {
    const canvas = canvasRef.current;
    if (!canvas || !history[idx]) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const img = new Image();
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
    };
    img.src = history[idx];
    setHistoryIdx(idx);
  };

  const getPointerPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) * canvas.width) / rect.width,
      y: ((e.clientY - rect.top) * canvas.height) / rect.height,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pos = getPointerPos(e);

    if (tool === 'text') {
      const content = textDraft.trim();
      if (!content) return;
      ctx.fillStyle = color;
      ctx.font = `600 ${Math.max(16, strokeWidth * 4 + 8)}px "IBM Plex Mono", "Cairo", sans-serif`;
      ctx.fillText(content, pos.x, pos.y);
      pushHistory();
      return;
    }

    canvas.setPointerCapture(e.pointerId);
    setDrawing(true);
    setStartPos(pos);

    if (tool === 'pen' || tool === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
      ctx.lineWidth = tool === 'eraser' ? strokeWidth * 4 : strokeWidth;
    } else {
      snapshotBeforeShapeRef.current = ctx.getImageData(0, 0, canvas.width, canvas.height);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing || !canvasRef.current || !startPos) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    const pos = getPointerPos(e);

    if (tool === 'pen' || tool === 'eraser') {
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
      return;
    }

    if (snapshotBeforeShapeRef.current) {
      ctx.putImageData(snapshotBeforeShapeRef.current, 0, 0);
    }
    ctx.strokeStyle = color;
    ctx.lineWidth = strokeWidth;
    ctx.beginPath();
    if (tool === 'line') {
      ctx.moveTo(startPos.x, startPos.y);
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    } else if (tool === 'rect') {
      ctx.strokeRect(startPos.x, startPos.y, pos.x - startPos.x, pos.y - startPos.y);
    } else if (tool === 'circle') {
      const rx = Math.hypot(pos.x - startPos.x, pos.y - startPos.y);
      ctx.arc(startPos.x, startPos.y, rx, 0, Math.PI * 2);
      ctx.stroke();
    }
  };

  const handlePointerUp = () => {
    if (!drawing) return;
    setDrawing(false);
    setStartPos(null);
    snapshotBeforeShapeRef.current = null;
    pushHistory();
  };

  const handleAnalyzeBoard = async (mode: WhiteboardAiMode) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم بلوغ الحد الشهري لطلبات AI.' : 'Monthly AI quota reached.');
      return;
    }
    setAiMode(mode);
    setBusy(true);
    setError('');
    try {
      const imageBase64 = canvas.toDataURL('image/png');
      const res = await analyzeWhiteboard({
        imageBase64,
        mode,
        prompt: aiNote,
        lang,
      });
      setAiResult(res.analysis);
      await trackAiUsageAndNotify({ uid, xpDelta: 15 });
      await awardStudyXp(uid, profile, 15);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Whiteboard AI analysis failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleSaveSnapshot = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    // Scale down thumbnail PNG so snapshotDataUrl stays comfortably under 350KB
    const thumb = document.createElement('canvas');
    thumb.width = 720;
    thumb.height = 420;
    const tctx = thumb.getContext('2d');
    if (tctx) {
      tctx.fillStyle = '#ffffff';
      tctx.fillRect(0, 0, thumb.width, thumb.height);
      tctx.drawImage(canvas, 0, 0, thumb.width, thumb.height);
    }
    const snapshotDataUrl = thumb.toDataURL('image/jpeg', 0.72).slice(0, 340000);
    const id = makeId('wb');
    try {
      await setDoc(doc(db, 'whiteboards', id), {
        ownerId: uid,
        subjectId: selectedSubjectId || '',
        title: (boardTitle.trim() || `${isAr ? 'سبورة' : 'Board'} ${new Date().toLocaleDateString()}`).slice(0, 200),
        aiMode,
        snapshotDataUrl,
        aiAnalysis: (aiResult || (isAr ? 'مسودة محفوظة' : 'Saved sketch')).slice(0, 12000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setBoardTitle('');
      setSavedNotice(isAr ? 'تم حفظ السبورة في مكتبتك.' : 'Whiteboard saved to cloud.');
      setTimeout(() => setSavedNotice(''), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save whiteboard.');
    }
  };

  const handleLoadSaved = (wb: WhiteboardDoc) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const img = new Image();
    img.onload = () => {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      pushHistory();
    };
    img.src = wb.snapshotDataUrl;
    setAiResult(wb.aiAnalysis);
    setAiMode(wb.aiMode);
  };

  const handleDownloadPng = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.href = canvasRef.current.toDataURL('image/png');
    link.download = `${boardTitle || 'smart-student-whiteboard'}.png`;
    link.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            {isAr ? 'السبورة الذكية التفاعلية AI' : 'Interactive AI Whiteboard'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'ارسم مسألة أو معادلة أو مخططًا هندسيًا ليقوم الذكاء الاصطناعي بحلها، تصحيح خطواتك، أو تحويلها لنص.'
              : 'Sketch math problems, equations, or engineering diagrams for Gemini Vision solving, OCR, and step checking.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            value={boardTitle}
            onChange={(e) => setBoardTitle(e.target.value)}
            placeholder={isAr ? 'عنوان السبورة...' : 'Board title...'}
            className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
          <select
            value={selectedSubjectId}
            onChange={(e) => setSelectedSubjectId(e.target.value)}
            className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
          >
            <option value="">{isAr ? 'بدون مادة' : 'General'}</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <button
            onClick={handleSaveSnapshot}
            className="px-3.5 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-lg flex items-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isAr ? 'حفظ السبورة' : 'Save Board'}</span>
          </button>
          <button
            onClick={handleDownloadPng}
            className="px-3 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>PNG</span>
          </button>
        </div>
      </div>

      {savedNotice && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {savedNotice}
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Drawing Toolbar */}
      <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {(
            [
              { id: 'pen', icon: <PenTool className="w-4 h-4" />, label: isAr ? 'قلم' : 'Pen' },
              { id: 'eraser', icon: <Eraser className="w-4 h-4" />, label: isAr ? 'ممحاة' : 'Eraser' },
              { id: 'line', icon: <Minus className="w-4 h-4" />, label: isAr ? 'خط' : 'Line' },
              { id: 'rect', icon: <Square className="w-4 h-4" />, label: isAr ? 'مربع' : 'Rect' },
              { id: 'circle', icon: <Circle className="w-4 h-4" />, label: isAr ? 'دائرة' : 'Circle' },
              { id: 'text', icon: <TypeIcon className="w-4 h-4" />, label: isAr ? 'نص/معادلة' : 'Text' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              onClick={() => setTool(item.id)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
                tool === item.id
                  ? 'bg-blue-600 text-white'
                  : 'border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`w-6 h-6 rounded-full border-2 ${
                  color === c ? 'border-slate-900 dark:border-white scale-110' : 'border-transparent'
                }`}
                style={{ backgroundColor: c }}
                aria-label={`Color ${c}`}
              />
            ))}
          </div>

          <input
            type="range"
            min={1}
            max={12}
            value={strokeWidth}
            onChange={(e) => setStrokeWidth(Number(e.target.value))}
            className="w-20 accent-blue-600"
            title={isAr ? 'سمك الخط' : 'Stroke width'}
          />

          <button
            disabled={historyIdx <= 0}
            onClick={() => restoreHistoryAt(historyIdx - 1)}
            className="p-1.5 border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-40"
            title={isAr ? 'تراجع' : 'Undo'}
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            disabled={historyIdx >= history.length - 1}
            onClick={() => restoreHistoryAt(historyIdx + 1)}
            className="p-1.5 border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-40"
            title={isAr ? 'إعادة' : 'Redo'}
          >
            <Redo2 className="w-4 h-4" />
          </button>
          <button
            onClick={initBlankCanvas}
            className="px-2.5 py-1.5 text-xs border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 rounded-lg"
          >
            {isAr ? 'مسح اللوحة' : 'Clear'}
          </button>
        </div>
      </div>

      {/* Text / Equation Symbol Injector when Text Tool Active */}
      {tool === 'text' && (
        <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex flex-wrap items-center gap-2">
          <input
            value={textDraft}
            onChange={(e) => setTextDraft(e.target.value)}
            placeholder={isAr ? 'اكتب نصًا أو معادلة ثم اضغط على اللوحة لوضعه...' : 'Type text or formula, then click canvas...'}
            className="flex-1 min-w-[220px] px-3 py-1.5 text-xs font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
          <div className="flex flex-wrap gap-1">
            {MATH_SYMBOLS.map((sym) => (
              <button
                key={sym}
                type="button"
                onClick={() => setTextDraft((d) => `${d}${sym}`)}
                className="px-2 py-1 text-xs font-mono border border-slate-200 dark:border-slate-700 rounded hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                {sym}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Canvas Workspace */}
        <div className="lg:col-span-8 space-y-4">
          <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white shadow-sm">
            <canvas
              ref={canvasRef}
              width={960}
              height={540}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerLeave={handlePointerUp}
              className="w-full h-auto touch-none cursor-crosshair block"
            />
          </div>

          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
            <input
              value={aiNote}
              onChange={(e) => setAiNote(e.target.value)}
              placeholder={
                isAr ? 'ملاحظة اختيارية للذكاء الاصطناعي (مثال: أوجد قيمة x)...' : 'Optional question or note for AI Vision...'
              }
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <div className="flex flex-wrap gap-2">
              {(
                [
                  { id: 'solve', ar: 'حل المسألة المرسومة', en: 'Solve Problem' },
                  { id: 'equation', ar: 'التعرف على المعادلة', en: 'Read Equations' },
                  { id: 'diagram', ar: 'شرح الرسم التوضيحي', en: 'Explain Diagram' },
                  { id: 'ocr', ar: 'تحويل الخط لنص', en: 'Handwriting OCR' },
                  { id: 'check', ar: 'تصحيح خطوات الحل', en: 'Check My Solution' },
                ] as { id: WhiteboardAiMode; ar: string; en: string }[]
              ).map((m) => (
                <button
                  key={m.id}
                  disabled={busy}
                  onClick={() => handleAnalyzeBoard(m.id)}
                  className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-sky-300 hover:bg-blue-100 dark:hover:bg-blue-900/50 flex items-center gap-1.5 disabled:opacity-50"
                >
                  {busy && aiMode === m.id ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5" />
                  )}
                  <span>{isAr ? m.ar : m.en}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* AI Result & Saved Boards */}
        <div className="lg:col-span-4 space-y-5">
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 min-h-[260px]">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600 dark:text-sky-400" />
              <span>{isAr ? 'تحليل وحل السبورة' : 'AI Whiteboard Output'}</span>
            </h2>
            {busy ? (
              <div className="py-12 flex flex-col items-center gap-2 text-xs text-slate-500">
                <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                <span>{isAr ? 'جاري قراءة السبورة وتحليلها...' : 'Analyzing your sketch...'}</span>
              </div>
            ) : !aiResult ? (
              <p className="text-xs text-slate-500 leading-relaxed py-8">
                {isAr
                  ? 'اكتب معادلة أو ارسم مسألة أو مخططًا على السبورة ثم اختر أحد أوامر الذكاء الاصطناعي بالأسفل.'
                  : 'Draw an equation, problem, or diagram on the board, then pick an AI analysis action.'}
              </p>
            ) : (
              <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed max-h-[340px] overflow-y-auto">
                {aiResult}
              </div>
            )}
          </div>

          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              {isAr ? `السبورات المحفوظة (${whiteboards.length})` : `Saved Boards (${whiteboards.length})`}
            </h3>
            {whiteboards.length === 0 ? (
              <p className="text-xs text-slate-500">
                {isAr ? 'لا توجد سبورات محفوظة بعد.' : 'No saved whiteboards yet.'}
              </p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto">
                {whiteboards.map((wb) => (
                  <div
                    key={wb.id}
                    onClick={() => handleLoadSaved(wb)}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={wb.snapshotDataUrl}
                        alt={wb.title}
                        className="w-12 h-8 object-cover rounded border border-slate-200 dark:border-slate-700 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {wb.title}
                        </p>
                        <p className="text-[11px] text-slate-500">{wb.aiMode}</p>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteDocSafe('whiteboards', wb.id);
                      }}
                      className="p-1 text-slate-400 hover:text-red-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
