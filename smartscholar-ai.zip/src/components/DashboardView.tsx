import React from 'react';
import {
  ExamAttempt,
  Flashcard,
  Language,
  Lecture,
  LectureSummary,
  MistakeEntry,
  NavSection,
  StudyPlanTask,
  Subject,
  SubscriptionPlan,
  UserProfile,
} from '../types';
import { awardStudyXp, getEffectiveLimit } from '../services/firestoreHelpers';
import { doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  AlertTriangle,
  Award,
  BookOpen,
  BookMarked,
  Brain,
  Calendar,
  Camera,
  CheckCircle2,
  Clock,
  Code2,
  FileText,
  FileUp,
  Flame,
  GraduationCap,
  Headphones,
  Layers,
  Network,
  PenTool,
  Sparkles,
  TrendingUp,
} from 'lucide-react';

export interface NavigateOptions {
  lectureId?: string;
  pageNumber?: number;
  tutorTab?: 'explain' | 'chat' | 'voice' | 'podcast' | 'photo';
  summaryMode?: 'summary' | 'revision';
  examMode?: 'simulator' | 'mistakes' | 'predict';
}

interface Props {
  lang: Language;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  lectures: Lecture[];
  summaries: LectureSummary[];
  exams: ExamAttempt[];
  flashcards: Flashcard[];
  tasks: StudyPlanTask[];
  mistakes: MistakeEntry[];
  onNavigate: (section: NavSection, opts?: NavigateOptions) => void;
}

export const DashboardView: React.FC<Props> = ({
  lang,
  profile,
  activePlan,
  subjects,
  lectures,
  summaries,
  exams,
  flashcards,
  tasks,
  mistakes,
  onNavigate,
}) => {
  const isAr = lang === 'ar';
  const completedLectures = lectures.filter((l) => l.progressPercent >= 80).length;
  const studyCompletionPct =
    lectures.length > 0
      ? Math.round(lectures.reduce((s, l) => s + (l.progressPercent || 0), 0) / lectures.length)
      : 0;
  const completedExams = exams.filter((e) => e.status === 'completed');
  const avgScore =
    completedExams.length > 0
      ? Math.round(completedExams.reduce((s, e) => s + e.scorePercent, 0) / completedExams.length)
      : 0;
  const now = Date.now();
  const dueCards = flashcards.filter((c) => c.nextReviewAt <= now).length;
  const todayStr = new Date().toISOString().slice(0, 10);
  const todayTasks = tasks.filter((t) => t.scheduledDate === todayStr || t.status !== 'completed');
  const completedTasksCount = tasks.filter((t) => t.status === 'completed').length;
  const pendingTasks = tasks.filter((t) => t.status !== 'completed').slice(0, 5);
  const unmasteredMistakes = mistakes.filter((m) => !m.mastered).length;

  const xp = profile?.xpPoints ?? 0;
  const level = Math.floor(xp / 200) + 1;
  const levelProgressPct = Math.round(((xp % 200) / 200) * 100);
  const streak = profile?.streakDays ?? 0;

  // Next upcoming exam from subjects
  const upcomingExams = subjects
    .filter((s) => s.examDate && s.examDate >= todayStr)
    .sort((a, b) => (a.examDate || '').localeCompare(b.examDate || ''));
  const nextExam = upcomingExams[0] || null;
  const daysToNextExam = nextExam?.examDate
    ? Math.max(0, Math.ceil((new Date(nextExam.examDate).getTime() - Date.now()) / 86_400_000))
    : null;

  const aiLimit = activePlan?.aiRequestLimit ?? 30;
  const aiUsed = profile?.aiRequestsUsed ?? 0;
  const quota = getEffectiveLimit(aiLimit, aiUsed);

  const toggleTaskDone = async (task: StudyPlanTask) => {
    const nextStatus = task.status === 'completed' ? 'pending' : 'completed';
    try {
      await updateDoc(doc(db, 'studyPlans', task.id), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
      if (nextStatus === 'completed' && profile?.uid) {
        await awardStudyXp(profile.uid, profile, 15);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `studyPlans/${task.id}`);
    }
  };

  const initials = (profile?.displayName || 'SS')
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() || '')
    .join('');

  const hubCards: {
    id: string;
    section: NavSection;
    opts?: NavigateOptions;
    title: string;
    subtitle: string;
    metric: string;
    icon: React.ComponentType<{ className?: string }>;
    accent: string;
  }[] = [
    {
      id: 'library',
      section: 'library',
      title: isAr ? 'مكتبتي' : 'My Library',
      subtitle: isAr ? 'المواد والمحاضرات والترجمة' : 'Courses, OCR & Translator',
      metric: `${lectures.length} ${isAr ? 'محاضرة' : 'lectures'}`,
      icon: BookOpen,
      accent: 'from-blue-600/20 to-sky-500/10 text-blue-500 dark:text-sky-400',
    },
    {
      id: 'tutor',
      section: 'tutor',
      opts: { tutorTab: 'explain' },
      title: isAr ? 'المدرس الذكي' : 'AI Tutor',
      subtitle: isAr ? 'شخصيات تعليمية ومحادثة صوتية' : 'Personal Professor & Voice',
      metric: isAr ? '4 شخصيات' : '4 personas',
      icon: Brain,
      accent: 'from-purple-600/20 to-indigo-500/10 text-purple-600 dark:text-purple-400',
    },
    {
      id: 'exams',
      section: 'exams',
      opts: { examMode: 'simulator' },
      title: isAr ? 'الامتحانات' : 'Exams',
      subtitle: isAr ? 'محاكاة وتصحيح وتوقع الأسئلة' : 'Simulator & Predictor',
      metric: `${completedExams.length} ${isAr ? 'مكتمل' : 'done'}`,
      icon: GraduationCap,
      accent: 'from-emerald-600/20 to-teal-500/10 text-emerald-600 dark:text-emerald-400',
    },
    {
      id: 'mindmaps',
      section: 'mindmaps',
      title: isAr ? 'الخرائط الذهنية' : 'Mind Maps',
      subtitle: isAr ? 'مخططات تفاعلية قابلة للتعديل' : 'Interactive Visual Maps',
      metric: isAr ? 'تفاعلي' : 'Editable SVG',
      icon: Network,
      accent: 'from-indigo-600/20 to-blue-500/10 text-indigo-600 dark:text-indigo-400',
    },
    {
      id: 'planner',
      section: 'planner',
      title: isAr ? 'خطة المذاكرة' : 'Study Planner',
      subtitle: isAr ? 'جداول ذكية وعد تنازلي للامتحان' : 'Daily/Weekly & Countdowns',
      metric: `${pendingTasks.length} ${isAr ? 'مهام' : 'pending'}`,
      icon: Calendar,
      accent: 'from-amber-500/20 to-orange-500/10 text-amber-600 dark:text-amber-400',
    },
    {
      id: 'progress',
      section: 'progress',
      title: isAr ? 'تقدمي والمجتمع' : 'My Progress',
      subtitle: isAr ? 'النقاط، التحديات، ومجموعات المذاكرة' : 'XP, Battles & Study Groups',
      metric: `${xp} XP`,
      icon: TrendingUp,
      accent: 'from-cyan-600/20 to-blue-500/10 text-cyan-600 dark:text-cyan-400',
    },
    {
      id: 'flashcards',
      section: 'flashcards',
      title: isAr ? 'البطاقات الذكية' : 'Flashcards',
      subtitle: isAr ? 'تكرار متباعد ومخططات بصرية' : 'SM-2 Spaced Repetition',
      metric: `${dueCards} ${isAr ? 'للمراجعة' : 'due'}`,
      icon: Layers,
      accent: 'from-pink-600/20 to-purple-500/10 text-pink-600 dark:text-pink-400',
    },
    {
      id: 'podcast',
      section: 'tutor',
      opts: { tutorTab: 'podcast' },
      title: isAr ? 'بودكاست AI' : 'AI Podcast',
      subtitle: isAr ? 'حوار صوتي ثنائي من محاضراتك' : 'Dual-Voice Lecture Audio',
      metric: isAr ? 'استوديو صوتي' : 'Audio Studio',
      icon: Headphones,
      accent: 'from-violet-600/20 to-fuchsia-500/10 text-violet-600 dark:text-violet-400',
    },
    {
      id: 'whiteboard',
      section: 'whiteboard',
      title: isAr ? 'السبورة الذكية' : 'AI Whiteboard',
      subtitle: isAr ? 'ارسم مسألة أو مخططًا واحصل على الحل' : 'Draw Math & Diagrams',
      metric: isAr ? 'تحليل بصري' : 'Vision AI',
      icon: PenTool,
      accent: 'from-sky-600/20 to-blue-500/10 text-sky-600 dark:text-sky-400',
    },
    {
      id: 'coding',
      section: 'coding',
      title: isAr ? 'مختبر البرمجة' : 'Coding Lab',
      subtitle: isAr ? 'تشغيل Python وJS وC/C++ ومراجعة AI' : 'Live Sandbox + Mentor',
      metric: 'PY / JS / C++',
      icon: Code2,
      accent: 'from-emerald-600/20 to-lime-500/10 text-emerald-600 dark:text-emerald-400',
    },
    {
      id: 'revision',
      section: 'summaries',
      opts: { summaryMode: 'revision' },
      title: isAr ? 'مراجعة ليلة الامتحان' : 'Revision Mode',
      subtitle: isAr ? 'ملخصات مكثفة لمادة كاملة' : 'Full-Subject Cram Pack',
      metric: `${summaries.length} ${isAr ? 'ملخص' : 'summaries'}`,
      icon: Sparkles,
      accent: 'from-orange-500/20 to-rose-500/10 text-orange-600 dark:text-orange-400',
    },
    {
      id: 'mistakes',
      section: 'exams',
      opts: { examMode: 'mistakes' },
      title: isAr ? 'دفتر الأخطاء' : 'Mistake Notebook',
      subtitle: isAr ? 'تتبع أخطائك وتدرب عليها' : 'Review & Re-Quiz Errors',
      metric: `${unmasteredMistakes} ${isAr ? 'متبقي' : 'to review'}`,
      icon: BookMarked,
      accent: 'from-rose-600/20 to-red-500/10 text-rose-600 dark:text-rose-400',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Premium Glass Hero Banner */}
      <section className="premium-hero-gradient rounded-2xl p-6 sm:p-8 border border-slate-700/60 text-white shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            {profile?.photoURL ? (
              <img
                src={profile.photoURL}
                alt={profile.displayName}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-sky-400/50 shadow-lg shrink-0"
              />
            ) : (
              <div className="w-16 h-16 rounded-2xl accent-btn-gradient flex items-center justify-center text-xl font-bold shadow-lg shrink-0">
                {initials}
              </div>
            )}
            <div className="space-y-1.5">
              <p className="text-xs font-medium text-sky-300/90">
                {profile?.college || (isAr ? 'منصة Smart Student الجامعية' : 'Smart Student University Workspace')}
                {profile?.department ? ` · ${profile.department}` : ''}
                {profile?.semester ? ` · ${profile.semester}` : ''}
              </p>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
                {isAr
                  ? `مرحبًا، ${profile?.displayName || 'طالبنا الذكي'}`
                  : `Welcome back, ${profile?.displayName || 'Scholar'}`}
              </h1>
              <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-slate-300 tabular-nums">
                <span className="flex items-center gap-1.5 font-semibold text-amber-300">
                  <Award className="w-4 h-4" />
                  {isAr ? `المستوى ${level}` : `Level ${level}`} · {xp} XP
                </span>
                <span className="flex items-center gap-1.5 font-semibold text-orange-300">
                  <Flame className="w-4 h-4" />
                  {streak} {isAr ? 'يوم متتالي' : 'day streak'}
                </span>
                {daysToNextExam !== null && nextExam && (
                  <span className="flex items-center gap-1.5 text-sky-200">
                    <Clock className="w-4 h-4" />
                    {isAr
                      ? `امتحان ${nextExam.name} خلال ${daysToNextExam} يوم`
                      : `${nextExam.name} exam in ${daysToNextExam}d`}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('library')}
              className="px-4 py-2.5 accent-btn-gradient text-white text-sm font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap shrink-0 shadow-lg"
            >
              <FileUp className="w-4 h-4" />
              <span>{isAr ? 'رفع محاضرة جديدة' : 'Upload Lecture'}</span>
            </button>
            <button
              onClick={() => onNavigate('tutor', { tutorTab: 'explain' })}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 text-white text-sm font-medium rounded-xl transition-colors flex items-center gap-2 whitespace-nowrap shrink-0"
            >
              <Brain className="w-4 h-4" />
              <span>{isAr ? 'اسأل المدرس الذكي' : 'Open AI Tutor'}</span>
            </button>
          </div>
        </div>

        {/* XP Level Progress Bar */}
        <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-8 space-y-1.5">
            <div className="flex justify-between text-xs text-slate-300 tabular-nums">
              <span>
                {isAr
                  ? `التقدم نحو المستوى ${level + 1}`
                  : `Progress to Level ${level + 1}`}
              </span>
              <span>{levelProgressPct}%</span>
            </div>
            <div className="w-full h-2 bg-slate-900/70 rounded-full overflow-hidden">
              <div
                className="h-full accent-btn-gradient transition-all duration-500"
                style={{ width: `${Math.max(4, levelProgressPct)}%` }}
              />
            </div>
          </div>
          <div className="md:col-span-4 flex items-center justify-between md:justify-end gap-4 text-xs text-slate-300 tabular-nums">
            <span>
              {isAr ? 'إنجاز المحاضرات:' : 'Course completion:'}{' '}
              <strong className="text-white">{studyCompletionPct}%</strong>
            </span>
            <span>
              {isAr ? 'الباقة:' : 'Plan:'}{' '}
              <strong className="text-sky-300">
                {activePlan ? (isAr ? activePlan.nameAr.split('—')[0] : activePlan.nameEn) : 'Free'}
              </strong>
            </span>
          </div>
        </div>
      </section>

      {/* 4-Column Performance KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr ? 'المحاضرات والمواد' : 'Lectures & Subjects'}
          </p>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
            {lectures.length}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {isAr
              ? `${completedLectures} مكتملة · ${subjects.length} مواد`
              : `${completedLectures} completed · ${subjects.length} subjects`}
          </p>
        </div>

        <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr ? 'متوسط الامتحانات' : 'Exam Average'}
          </p>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
            {avgScore}%
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {isAr
              ? `${completedExams.length} امتحان · ${unmasteredMistakes} خطأ للمراجعة`
              : `${completedExams.length} exams · ${unmasteredMistakes} mistakes`}
          </p>
        </div>

        <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr ? 'المهام والبطاقات' : 'Tasks & Flashcards'}
          </p>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
            {dueCards}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {isAr
              ? `بطاقة مستحقة · ${completedTasksCount}/${tasks.length} مهام`
              : `cards due · ${completedTasksCount}/${tasks.length} tasks`}
          </p>
        </div>

        <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr ? 'استهلاك الذكاء الاصطناعي' : 'AI Usage Quota'}
          </p>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
            {aiUsed} / {aiLimit}
          </p>
          <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full mt-2 overflow-hidden">
            <div
              className={`h-full transition-all ${
                quota.exceeded ? 'bg-red-500' : quota.nearLimit ? 'bg-amber-500' : 'bg-blue-600'
              }`}
              style={{ width: `${quota.percent}%` }}
            />
          </div>
        </div>
      </div>

      {(quota.nearLimit || quota.exceeded) && (
        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <p className="text-sm text-amber-900 dark:text-amber-200">
              {quota.exceeded
                ? isAr
                  ? 'لقد استنفدت حد الذكاء الاصطناعي الشهري لباقتك الحالية.'
                  : 'You have reached the monthly AI request limit for your current plan.'
                : isAr
                  ? 'اقتربت من الحد الشهري لاستخدام الذكاء الاصطناعي.'
                  : 'You are approaching your monthly AI request quota.'}
            </p>
          </div>
          <button
            onClick={() => onNavigate('profile')}
            className="px-3.5 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white rounded-xl whitespace-nowrap shrink-0"
          >
            {isAr ? 'إدارة الباقة' : 'Manage Plan'}
          </button>
        </div>
      )}

      {/* Interactive Learning Hub Grid */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {isAr ? 'بوابة الأدوات التعليمية الذكية' : 'Interactive Learning Hub'}
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {isAr ? 'اضغط على أي أداة لفتحها فورًا' : 'Select any module to launch'}
          </span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5">
          {hubCards.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.id}
                onClick={() => onNavigate(card.section, card.opts)}
                className="group glass-surface border border-slate-200 dark:border-slate-800/90 hover:border-blue-500/60 dark:hover:border-sky-500/60 rounded-2xl p-4 text-start transition-all duration-200 hover:-translate-y-0.5 flex flex-col justify-between gap-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.accent} flex items-center justify-center shrink-0`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 tabular-nums">
                    {card.metric}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-sky-400 transition-colors">
                    {card.title}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                    {card.subtitle}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Main Content Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Recent Lectures & Latest Summaries */}
        <div className="lg:col-span-7 space-y-6">
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'أحدث المحاضرات' : 'Recent Lectures'}
              </h2>
              <button
                onClick={() => onNavigate('library')}
                className="text-xs font-semibold text-blue-600 dark:text-sky-400 hover:underline"
              >
                {isAr ? 'عرض المكتبة' : 'View Library'}
              </button>
            </div>

            {lectures.length === 0 ? (
              <div className="py-10 text-center space-y-3">
                <BookOpen className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  {isAr
                    ? 'لم ترفع أي محاضرات بعد. ابدأ بإنشاء مادة ورفع محاضرة PDF أو Word أو صوت أو فيديو.'
                    : 'No lectures uploaded yet. Create a subject and upload a lecture to begin.'}
                </p>
                <button
                  onClick={() => onNavigate('library')}
                  className="px-4 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl"
                >
                  {isAr ? 'إضافة مادة ومحاضرة' : 'Add Subject & Lecture'}
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {lectures.slice(0, 5).map((lec) => {
                  const subj = subjects.find((s) => s.id === lec.subjectId);
                  return (
                    <div key={lec.id} className="py-3.5 flex items-center justify-between gap-4">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                          {lec.title}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                          {subj?.name || (isAr ? 'مادة دراسية' : 'Subject')} · {lec.fileType.toUpperCase()} ·{' '}
                          <span className="tabular-nums">{lec.totalPages}</span> {isAr ? 'صفحة' : 'pages'} ·{' '}
                          <span className="tabular-nums">{lec.progressPercent}%</span>
                        </p>
                      </div>
                      <button
                        onClick={() => onNavigate('tutor', { lectureId: lec.id, tutorTab: 'explain' })}
                        className="px-3 py-1.5 text-xs font-semibold border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
                      >
                        {isAr ? 'اشرح لي' : 'Explain'}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Latest Summaries */}
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'آخر الملخصات المحفوظة' : 'Latest Saved Summaries'}
              </h2>
              <button
                onClick={() => onNavigate('summaries')}
                className="text-xs font-semibold text-blue-600 dark:text-sky-400 hover:underline"
              >
                {isAr ? 'فتح التلخيص' : 'Open Summaries'}
              </button>
            </div>
            {summaries.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400 py-4">
                {isAr
                  ? 'لم تنشئ أي ملخص بعد. افتح نظام التلخيص لتحويل محاضراتك إلى نقاط مركزة.'
                  : 'No summaries generated yet. Use Smart Summaries to distill key formulas and definitions.'}
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {summaries.slice(0, 4).map((sum) => (
                  <button
                    key={sum.id}
                    onClick={() => onNavigate('summaries', { lectureId: sum.lectureId })}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-blue-500/50 text-start space-y-1.5 transition-colors"
                  >
                    <div className="flex items-center gap-2 text-blue-600 dark:text-sky-400">
                      <FileText className="w-4 h-4 shrink-0" />
                      <span className="text-xs font-semibold truncate">{sum.title}</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                      {sum.contentMarkdown.slice(0, 120)}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Daily Study Tasks & Mobile Home Widget Preview */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'مهام المذاكرة اليومية' : 'Daily Study Tasks'}
              </h2>
              <button
                onClick={() => onNavigate('planner')}
                className="text-xs font-semibold text-blue-600 dark:text-sky-400 hover:underline"
              >
                {isAr ? 'إدارة الجدول' : 'Manage Plan'}
              </button>
            </div>
            {pendingTasks.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-4">
                {isAr
                  ? 'لا توجد مهام مجدولة. أنشئ خطة مذاكرة ذكية بناءً على مواعيد امتحاناتك.'
                  : 'No scheduled tasks yet. Build an AI study plan from your exam dates.'}
              </p>
            ) : (
              <div className="space-y-2.5">
                {pendingTasks.map((task) => (
                  <button
                    key={task.id}
                    onClick={() => toggleTaskDone(task)}
                    className="w-full text-start p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 flex items-start gap-3 transition-colors"
                  >
                    <CheckCircle2 className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                        {task.title}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                        {task.subjectName} · {task.scheduledDate} · {task.durationMinutes} {isAr ? 'د' : 'min'}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Mobile Quick Widget Summary Card */}
          <div className="rounded-2xl p-5 bg-gradient-to-br from-slate-900 to-indigo-950 text-white border border-indigo-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-sky-300">
                {isAr ? 'ويدجت المتابعة السريعة' : 'Quick Study Snapshot'}
              </p>
              <span className="text-xs font-mono text-slate-300 tabular-nums">{todayStr}</span>
            </div>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                <p className="text-lg font-bold tabular-nums">{todayTasks.length}</p>
                <p className="text-[11px] text-slate-300">{isAr ? 'مهام اليوم' : 'Today Tasks'}</p>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                <p className="text-lg font-bold tabular-nums">{studyCompletionPct}%</p>
                <p className="text-[11px] text-slate-300">{isAr ? 'الإنجاز' : 'Completion'}</p>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                <p className="text-lg font-bold tabular-nums">
                  {daysToNextExam !== null ? `${daysToNextExam}d` : '--'}
                </p>
                <p className="text-[11px] text-slate-300">{isAr ? 'أقرب امتحان' : 'Next Exam'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('tutor', { tutorTab: 'photo' })}
                className="flex-1 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>{isAr ? 'حل مسألة' : 'Photo Solver'}</span>
              </button>
              <button
                onClick={() => onNavigate('tutor', { tutorTab: 'voice' })}
                className="flex-1 py-2 px-3 rounded-xl accent-btn-gradient text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Brain className="w-3.5 h-3.5" />
                <span>{isAr ? 'المدرس الصوتي' : 'Voice Tutor'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
