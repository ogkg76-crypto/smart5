import React, { useEffect, useRef, useState } from 'react';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import {
  ChatMessageRecord,
  ExplanationLevel,
  Language,
  Lecture,
  LectureExplanation,
  PodcastEpisode,
  Subject,
  SubscriptionPlan,
  TutorPersona,
  UserProfile,
} from '../types';
import {
  generateExplanation,
  reexplainSection,
  sendTutorChat,
  solvePhotoProblem,
  synthesizeSpeech,
  transcribeVoiceRecording,
} from '../services/api';
import { awardStudyXp, getEffectiveLimit, makeId, trackAiUsageAndNotify } from '../services/firestoreHelpers';
import { PodcastPanel } from './PodcastPanel';
import {
  Brain,
  MessageSquare,
  Camera,
  Volume2,
  Pause,
  Mic,
  Square,
  Send,
  RefreshCw,
  Loader2,
  AlertCircle,
  Upload,
  Headphones,
  ExternalLink,
  UserCheck,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  lectures: Lecture[];
  explanations: LectureExplanation[];
  chatMessages: ChatMessageRecord[];
  podcasts: PodcastEpisode[];
  initialLectureId?: string;
  initialTab?: 'explain' | 'chat' | 'voice' | 'podcast' | 'photo';
  onOpenLecturePage?: (lectureId: string, pageNumber: number) => void;
}

const PERSONAS: { id: TutorPersona; arTitle: string; enTitle: string; arDesc: string; enDesc: string }[] = [
  {
    id: 'professor',
    arTitle: 'الأستاذ الجامعي',
    enTitle: 'Professor',
    arDesc: 'شرح أكاديمي منظم وعميق',
    enDesc: 'Rigorous structured academic teaching',
  },
  {
    id: 'simple',
    arTitle: 'المبسط من الصفر',
    enTitle: 'Simple Tutor',
    arDesc: 'كلمات بسيطة وتدرج سهل',
    enDesc: 'Plain words from first principles',
  },
  {
    id: 'exam_coach',
    arTitle: 'مدرب الامتحانات',
    enTitle: 'Exam Coach',
    arDesc: 'نقاط الامتحان والأخطاء الشائعة',
    enDesc: 'High-yield traps & model phrasing',
  },
  {
    id: 'coding_mentor',
    arTitle: 'مرشد البرمجة',
    enTitle: 'Coding Mentor',
    arDesc: 'خوارزميات وأكواد وتعقيد زمني',
    enDesc: 'Algorithms, trace & Big-O intuition',
  },
];

function parsePageNumber(pageLabel: string): number | null {
  const m = (pageLabel || '').match(/\d+/);
  return m ? Math.max(1, Number(m[0])) : null;
}

export const TutorView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  subjects,
  lectures,
  explanations,
  chatMessages,
  podcasts,
  initialLectureId,
  initialTab,
  onOpenLecturePage,
}) => {
  const isAr = lang === 'ar';
  const [activeTab, setActiveTab] = useState<'explain' | 'chat' | 'voice' | 'podcast' | 'photo'>(
    initialTab || 'explain'
  );
  const [selectedLectureId, setSelectedLectureId] = useState<string>(
    initialLectureId || lectures[0]?.id || ''
  );
  const [level, setLevel] = useState<ExplanationLevel>('intermediate');
  const [persona, setPersona] = useState<TutorPersona>(profile?.defaultPersona || 'professor');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  // Re-explain modal/inline state
  const [reexplainIdx, setReexplainIdx] = useState<number | null>(null);
  const [reexplainResult, setReexplainResult] = useState<Record<number, string>>({});

  // TTS audio playback state
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [ttsLoading, setTtsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackRate, setPlaybackRate] = useState<number>(profile?.voiceSpeed || 1);

  // Chat & Voice Tutor state
  const [sourceMode, setSourceMode] = useState<'lecture' | 'subject' | 'general'>('lecture');
  const [chatInput, setChatInput] = useState('');
  const [recording, setRecording] = useState(false);
  const [voiceAutoSpeak, setVoiceAutoSpeak] = useState(true);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Photo Solver state
  const [photoPreview, setPhotoPreview] = useState<string>('');
  const [photoSolution, setPhotoSolution] = useState<{
    clarityStatus: string;
    unclearNote?: string;
    recognizedProblem: string;
    topic: string;
    coreConcept: string;
    steps: string[];
    finalAnswer: string;
  } | null>(null);

  useEffect(() => {
    if (initialTab) setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (initialLectureId) {
      setSelectedLectureId(initialLectureId);
    } else if (!selectedLectureId && lectures[0]?.id) {
      setSelectedLectureId(lectures[0].id);
    }
  }, [initialLectureId, lectures, selectedLectureId]);

  const selectedLecture = lectures.find((l) => l.id === selectedLectureId) || null;
  const activeExplanation =
    explanations.find(
      (e) => e.lectureId === selectedLectureId && e.level === level && (e.persona || 'professor') === persona
    ) ||
    explanations.find((e) => e.lectureId === selectedLectureId && e.level === level) ||
    explanations.find((e) => e.lectureId === selectedLectureId) ||
    null;

  const checkQuota = (): boolean => {
    const limit = activePlan?.aiRequestLimit ?? 30;
    const used = profile?.aiRequestsUsed ?? 0;
    if (getEffectiveLimit(limit, used).exceeded) {
      setError(
        isAr
          ? 'تم الوصول للحد الأقصى لاستخدام الذكاء الاصطناعي في باقتك الحالية. يرجى الترقية من صفحة حسابي.'
          : 'You have reached your AI request limit. Please upgrade in Profile & Plans.'
      );
      return false;
    }
    return true;
  };

  const handleExplainLecture = async () => {
    if (!selectedLecture) return;
    if (!checkQuota()) return;
    setError('');
    setBusy(true);
    try {
      const targetLang = profile?.explanationLang || lang;
      const result = await generateExplanation({
        lectureTitle: selectedLecture.title,
        pages: selectedLecture.extractedPages,
        level,
        persona,
        lang: targetLang,
      });

      const expId = makeId('exp');
      await setDoc(doc(db, 'explanations', expId), {
        ownerId: uid,
        lectureId: selectedLecture.id,
        subjectId: selectedLecture.subjectId,
        level,
        persona,
        overview: result.overview,
        sections: result.sections,
        createdAt: serverTimestamp(),
      });

      await trackAiUsageAndNotify({
        uid,
        enableNotif: profile?.notifAiReady !== false,
        notifTitle: isAr ? 'تم إعداد الشرح الذكي' : 'AI Explanation Ready',
        notifBody: isAr
          ? `تم شرح محاضرة "${selectedLecture.title}" بنجاح.`
          : `Explanation for "${selectedLecture.title}" is ready.`,
        notifCategory: 'ai',
        xpDelta: 20,
      });
      await awardStudyXp(uid, profile, 20);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate explanation.');
    } finally {
      setBusy(false);
    }
  };

  const handleReexplain = async (
    idx: number,
    title: string,
    content: string,
    style: 'simpler' | 'deeper' | 'examples'
  ) => {
    if (!checkQuota()) return;
    setReexplainIdx(idx);
    setError('');
    try {
      const res = await reexplainSection({
        sectionTitle: title,
        sourceText: content,
        style,
        lang: profile?.explanationLang || lang,
      });
      setReexplainResult((prev) => ({ ...prev, [idx]: res.explanation }));
      await trackAiUsageAndNotify({ uid });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Re-explain failed.');
    } finally {
      setReexplainIdx(null);
    }
  };

  const playTtsString = async (textToRead: string, fresh = true) => {
    if (!fresh && isPlaying && audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
      return;
    }
    setTtsLoading(true);
    setError('');
    try {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      const res = await synthesizeSpeech(textToRead);
      const audio = new Audio(`data:${res.mimeType};base64,${res.audioBase64}`);
      audio.playbackRate = playbackRate;
      audio.onended = () => setIsPlaying(false);
      audioRef.current = audio;
      await audio.play();
      setIsPlaying(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'TTS playback failed.');
    } finally {
      setTtsLoading(false);
    }
  };

  const sendQuestionInternal = async (msgText: string, speakReply = false) => {
    const msg = msgText.trim();
    if (!msg) return;
    if (!checkQuota()) return;

    setBusy(true);
    setError('');

    try {
      const userMsgId = makeId('chat');
      await setDoc(doc(db, 'chatSessions', userMsgId), {
        ownerId: uid,
        subjectId: selectedLecture?.subjectId || '',
        lectureId: selectedLecture?.id || '',
        sourceMode,
        persona,
        role: 'user',
        text: msg.slice(0, 12000),
        citations: [],
        createdAt: serverTimestamp(),
      });

      let contextText = '';
      if (sourceMode === 'lecture' && selectedLecture) {
        contextText = `Lecture: ${selectedLecture.title}\n${selectedLecture.fullTextPreview}`;
      } else if (sourceMode === 'subject' && selectedLecture) {
        const subjectLectures = lectures.filter((l) => l.subjectId === selectedLecture.subjectId);
        contextText = subjectLectures
          .map((l) => `=== Lecture: ${l.title} ===\n${l.fullTextPreview.slice(0, 12000)}`)
          .join('\n\n');
      }

      const recentHistory = chatMessages.slice(-6).map((m) => ({ role: m.role, text: m.text }));
      const aiResp = await sendTutorChat({
        message: msg,
        sourceMode,
        persona,
        contextText,
        history: recentHistory,
        lang: profile?.explanationLang || lang,
      });

      const botMsgId = makeId('chat');
      await setDoc(doc(db, 'chatSessions', botMsgId), {
        ownerId: uid,
        subjectId: selectedLecture?.subjectId || '',
        lectureId: selectedLecture?.id || '',
        sourceMode,
        persona,
        role: 'assistant',
        text: aiResp.reply.slice(0, 12000),
        citations: (aiResp.citations || []).slice(0, 10),
        createdAt: serverTimestamp(),
      });

      await trackAiUsageAndNotify({ uid, xpDelta: 10 });
      await awardStudyXp(uid, profile, 10);

      if (speakReply) {
        await playTtsString(aiResp.reply, true);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Chat failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleSendChat = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const msg = chatInput.trim();
    if (!msg) return;
    setChatInput('');
    await sendQuestionInternal(msg, activeTab === 'voice' && voiceAutoSpeak);
  };

  const toggleVoiceRecording = async (autoSend = false) => {
    if (recording && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setRecording(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) audioChunksRef.current.push(ev.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setBusy(true);
        try {
          const res = await transcribeVoiceRecording(blob);
          if (res.text) {
            if (autoSend) {
              await sendQuestionInternal(res.text, voiceAutoSpeak);
            } else {
              setChatInput(res.text);
            }
          }
        } catch (err) {
          setError(err instanceof Error ? err.message : 'Voice transcription failed.');
        } finally {
          setBusy(false);
        }
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setRecording(true);
    } catch {
      setError(isAr ? 'يرجى السماح بالوصول إلى الميكروفون.' : 'Microphone permission is required.');
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!checkQuota()) return;

    setPhotoPreview(URL.createObjectURL(file));
    setPhotoSolution(null);
    setBusy(true);
    setError('');
    try {
      const res = await solvePhotoProblem(file, profile?.explanationLang || lang);
      setPhotoSolution(res);
      await trackAiUsageAndNotify({ uid, xpDelta: 15 });
      await awardStudyXp(uid, profile, 15);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Photo solver failed.');
    } finally {
      setBusy(false);
      e.target.value = '';
    }
  };

  const visibleMessages = chatMessages.filter(
    (m) => !selectedLectureId || !m.lectureId || m.lectureId === selectedLectureId
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'المدرس الذكي ومساعد المذاكرة' : 'AI Personal Professor & Assistant'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'اختر شخصية الأستاذ، اسأل محاضرتك بالمصدر، تحدّث صوتيًا، أو حوّل المحاضرة لبودكاست.'
              : 'Choose a teaching persona, ask page-cited questions, speak via Voice Tutor, or listen to AI Podcasts.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl self-start">
          {[
            { id: 'explain' as const, ar: 'شرح المحاضرة', en: 'Explain', icon: Brain },
            { id: 'chat' as const, ar: 'اسأل محاضرتك', en: 'Ask Lecture', icon: MessageSquare },
            { id: 'voice' as const, ar: 'المدرس الصوتي', en: 'Voice Tutor', icon: Mic },
            { id: 'podcast' as const, ar: 'بودكاست AI', en: 'AI Podcast', icon: Headphones },
            { id: 'photo' as const, ar: 'حل بالتصوير', en: 'Photo Solver', icon: Camera },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{isAr ? tab.ar : tab.en}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Personal Professor Selector Strip */}
      {(activeTab === 'explain' || activeTab === 'chat' || activeTab === 'voice') && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {PERSONAS.map((p) => {
            const active = persona === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setPersona(p.id)}
                className={`p-3 rounded-xl border text-start transition-all ${
                  active
                    ? 'border-blue-600 dark:border-sky-500 bg-blue-50/70 dark:bg-sky-950/30 shadow-sm'
                    : 'glass-surface border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    {isAr ? p.arTitle : p.enTitle}
                  </span>
                  {active && <UserCheck className="w-3.5 h-3.5 text-blue-600 dark:text-sky-400 shrink-0" />}
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
                  {isAr ? p.arDesc : p.enDesc}
                </p>
              </button>
            );
          })}
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {activeTab === 'explain' && (
        <div className="space-y-6">
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 flex-1">
              <select
                value={selectedLectureId}
                onChange={(e) => {
                  setSelectedLectureId(e.target.value);
                  if (audioRef.current) {
                    audioRef.current.pause();
                    audioRef.current = null;
                    setIsPlaying(false);
                  }
                }}
                className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg min-w-[220px]"
              >
                <option value="">{isAr ? 'اختر محاضرة...' : 'Select a lecture...'}</option>
                {lectures.map((l) => {
                  const s = subjects.find((sub) => sub.id === l.subjectId);
                  return (
                    <option key={l.id} value={l.id}>
                      {s ? `${s.name} — ` : ''}
                      {l.title}
                    </option>
                  );
                })}
              </select>

              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as ExplanationLevel)}
                className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="beginner">{isAr ? 'مستوى المبتدئين (من الصفر)' : 'Beginner (From Scratch)'}</option>
                <option value="intermediate">{isAr ? 'المستوى المتوسط (أكاديمي مبسط)' : 'Intermediate (Simplified)'}</option>
                <option value="advanced">{isAr ? 'المستوى المتقدم (عميق وتفصيلي)' : 'Advanced (Deep Rigor)'}</option>
                <option value="revision">{isAr ? 'مستوى المراجعة (مختصر وسريع)' : 'Quick Revision'}</option>
              </select>
            </div>

            <button
              disabled={!selectedLecture || busy}
              onClick={handleExplainLecture}
              className="px-5 py-2.5 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap shrink-0"
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
              <span>{isAr ? 'شرح المحاضرة' : 'Explain Lecture'}</span>
            </button>
          </div>

          {!activeExplanation ? (
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center space-y-2">
              <p className="text-sm text-slate-600 dark:text-slate-400">
                {selectedLecture
                  ? isAr
                    ? 'اختر شخصية الأستاذ والمستوى واضغط "شرح المحاضرة" للحصول على شرح تفصيلي مرتبط بصفحات الملف.'
                    : 'Choose a persona & level and click "Explain Lecture" to generate a page-grounded breakdown.'
                  : isAr
                    ? 'ارفع محاضرة أولًا من مكتبتي لتبدأ الشرح الذكي.'
                    : 'Upload a lecture in My Library first to start AI tutoring.'}
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                    {isAr ? 'النظرة الشاملة للمحاضرة' : 'Lecture Overview'}
                  </h2>
                  <div className="flex items-center gap-2">
                    <button
                      disabled={ttsLoading}
                      onClick={() => {
                        if (isPlaying && audioRef.current) {
                          audioRef.current.pause();
                          setIsPlaying(false);
                          return;
                        }
                        playTtsString(
                          `${activeExplanation.overview}\n\n${activeExplanation.sections
                            .map((s) => `${s.title}. ${s.simplifiedArabic}`)
                            .join('\n')}`
                        );
                      }}
                      className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      {ttsLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : isPlaying ? (
                        <Pause className="w-3.5 h-3.5" />
                      ) : (
                        <Volume2 className="w-3.5 h-3.5" />
                      )}
                      <span>{isPlaying ? (isAr ? 'إيقاف الصوت' : 'Pause Audio') : isAr ? 'استماع للشرح' : 'Listen (TTS)'}</span>
                    </button>
                    <select
                      value={playbackRate}
                      onChange={(e) => {
                        const rate = Number(e.target.value);
                        setPlaybackRate(rate);
                        if (audioRef.current) audioRef.current.playbackRate = rate;
                      }}
                      className="px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-950 font-mono"
                    >
                      <option value={0.75}>0.75x</option>
                      <option value={1}>1.0x</option>
                      <option value={1.25}>1.25x</option>
                      <option value={1.5}>1.5x</option>
                    </select>
                  </div>
                </div>
                <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                  {activeExplanation.overview}
                </p>
              </div>

              <div className="space-y-4">
                {activeExplanation.sections.map((sec, idx) => (
                  <div
                    key={idx}
                    className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                      <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {isAr ? 'المصدر:' : 'Source:'} {sec.sourcePage}
                        </p>
                        <h3 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                          {idx + 1}. {sec.title}
                        </h3>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          disabled={reexplainIdx === idx}
                          onClick={() => handleReexplain(idx, sec.title, sec.simplifiedArabic, 'simpler')}
                          className="px-2.5 py-1 text-xs border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-1"
                        >
                          <RefreshCw className={`w-3 h-3 ${reexplainIdx === idx ? 'animate-spin' : ''}`} />
                          <span>{isAr ? 'أعد الشرح ببساطة' : 'Simplify'}</span>
                        </button>
                        <button
                          disabled={reexplainIdx === idx}
                          onClick={() => handleReexplain(idx, sec.title, sec.simplifiedArabic, 'examples')}
                          className="px-2.5 py-1 text-xs border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800"
                        >
                          {isAr ? 'أمثلة إضافية' : 'More Examples'}
                        </button>
                      </div>
                    </div>

                    <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                      {sec.simplifiedArabic}
                    </p>

                    {sec.englishTerms && sec.englishTerms.length > 0 && (
                      <div className="pt-2">
                        <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">
                          {isAr ? 'المصطلحات الإنجليزية ومعانيها:' : 'Key Terms:'}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {sec.englishTerms.map((term, ti) => (
                            <div
                              key={ti}
                              className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/70 dark:border-slate-800 text-xs"
                            >
                              <span className="font-semibold text-slate-900 dark:text-white">
                                {term.term}
                              </span>
                              <span className="text-slate-500"> — </span>
                              <span className="text-slate-700 dark:text-slate-300">{term.meaning}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {sec.practicalExample && (
                      <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                        <p className="font-semibold text-slate-800 dark:text-slate-200">
                          {isAr ? 'مثال عملي:' : 'Practical Example:'}
                        </p>
                        <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                          {sec.practicalExample}
                        </p>
                      </div>
                    )}

                    {sec.codeOrFormula && (
                      <pre
                        dir="ltr"
                        className="p-3.5 rounded-xl bg-slate-900 text-slate-100 text-xs font-mono overflow-x-auto"
                      >
                        {sec.codeOrFormula}
                      </pre>
                    )}

                    {sec.conceptComparison && (
                      <div className="text-xs text-slate-600 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800 pt-2.5">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {isAr ? 'مقارنة وتوضيح الفروق: ' : 'Comparison: '}
                        </span>
                        {sec.conceptComparison}
                      </div>
                    )}

                    {reexplainResult[idx] && (
                      <div className="p-4 rounded-xl bg-blue-50 dark:bg-sky-950/30 border border-blue-200 dark:border-sky-800 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap">
                        {reexplainResult[idx]}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {(activeTab === 'chat' || activeTab === 'voice') && (
        <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col h-[640px]">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <select
              value={selectedLectureId}
              onChange={(e) => setSelectedLectureId(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="">{isAr ? 'بدون محاضرة محددة' : 'No lecture selected'}</option>
              {lectures.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.title}
                </option>
              ))}
            </select>

            <div className="flex flex-wrap items-center gap-2">
              {activeTab === 'voice' && (
                <label className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 me-2">
                  <input
                    type="checkbox"
                    checked={voiceAutoSpeak}
                    onChange={(e) => setVoiceAutoSpeak(e.target.checked)}
                  />
                  <span>{isAr ? 'نطق الرد تلقائيًا' : 'Auto-speak replies'}</span>
                </label>
              )}

              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                {(['lecture', 'subject', 'general'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setSourceMode(mode)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
                      sourceMode === mode
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {mode === 'lecture'
                      ? isAr
                        ? 'المحاضرة الحالية'
                        : 'This Lecture'
                      : mode === 'subject'
                        ? isAr
                          ? 'كل محاضرات المادة'
                          : 'All Subject'
                        : isAr
                          ? 'معرفة عامة'
                          : 'General AI'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {activeTab === 'voice' && (
            <div className="px-5 py-3 bg-indigo-50/70 dark:bg-indigo-950/30 border-b border-indigo-200/60 dark:border-indigo-900/50 flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-0.5">
                <p className="text-xs font-bold text-indigo-900 dark:text-indigo-200">
                  {isAr ? 'وضع المحادثة الصوتية التفاعلية' : 'Interactive Voice Tutor'}
                </p>
                <p className="text-[11px] text-indigo-700 dark:text-indigo-300">
                  {isAr
                    ? 'يستخدم الميكروفون بعد موافقتك لتحويل سؤالك الصوتي وإجابة المدرس بصوت مسموع.'
                    : 'Uses microphone with consent to transcribe your spoken question and speak back the answer.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => toggleVoiceRecording(true)}
                disabled={busy}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors ${
                  recording
                    ? 'bg-red-600 text-white animate-pulse'
                    : 'accent-btn-gradient text-white'
                }`}
              >
                {recording ? <Square className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                <span>
                  {recording
                    ? isAr
                      ? 'إيقاف وإرسال السؤال'
                      : 'Stop & Ask Tutor'
                    : isAr
                      ? 'تحدث مع المدرس الآن'
                      : 'Speak to AI Tutor'}
                </span>
              </button>
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {visibleMessages.length === 0 ? (
              <div className="text-center text-sm text-slate-500 dark:text-slate-400 py-16">
                {isAr
                  ? 'اسأل المدرس الذكي عن أي نقطة من المحاضرة وسيرد عليك مع ذكر رقم الصفحة.'
                  : 'Ask your AI Tutor about any concept from the lecture for page-cited answers.'}
              </div>
            ) : (
              visibleMessages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                      m.role === 'user'
                        ? 'accent-btn-gradient text-white'
                        : 'bg-slate-100 dark:bg-slate-800/90 text-slate-900 dark:text-slate-100'
                    }`}
                  >
                    {m.text}
                    {m.role === 'assistant' && (
                      <div className="mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-end">
                        <button
                          type="button"
                          onClick={() => playTtsString(m.text, true)}
                          className="text-[11px] font-medium text-blue-600 dark:text-sky-400 flex items-center gap-1 hover:underline"
                        >
                          <Volume2 className="w-3 h-3" />
                          <span>{isAr ? 'استماع للإجابة' : 'Speak Reply'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                  {m.citations && m.citations.length > 0 && (
                    <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 space-y-1 max-w-[85%]">
                      {m.citations.map((c, i) => {
                        const pageNum = parsePageNumber(c.page);
                        const targetLec =
                          lectures.find((l) => l.title === c.lectureTitle) || selectedLecture;
                        return (
                          <div key={i} className="flex flex-wrap items-center gap-2">
                            <span>
                              {c.lectureTitle} · {c.page} — "{c.excerpt}"
                            </span>
                            {pageNum && targetLec && onOpenLecturePage && (
                              <button
                                type="button"
                                onClick={() => onOpenLecturePage(targetLec.id, pageNum)}
                                className="text-[11px] font-semibold text-blue-600 dark:text-sky-400 hover:underline inline-flex items-center gap-1"
                              >
                                <ExternalLink className="w-3 h-3" />
                                <span>{isAr ? `الانتقال لصفحة ${pageNum}` : `Go to Page ${pageNum}`}</span>
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          <form
            onSubmit={handleSendChat}
            className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
          >
            <button
              type="button"
              onClick={() => toggleVoiceRecording(false)}
              className={`p-2.5 rounded-xl border transition-colors ${
                recording
                  ? 'bg-red-600 text-white border-red-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title={isAr ? 'تسجيل سؤال صوتي' : 'Voice Question'}
            >
              {recording ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder={
                isAr ? 'اكتب سؤالك هنا أو استخدم الميكروفون...' : 'Type your question or use the microphone...'
              }
              className="flex-1 px-4 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
            <button
              type="submit"
              disabled={busy || !chatInput.trim()}
              className="px-4 py-2 accent-btn-gradient disabled:opacity-50 text-white rounded-xl flex items-center gap-1.5 text-sm font-semibold"
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              <span>{isAr ? 'إرسال' : 'Send'}</span>
            </button>
          </form>
        </div>
      )}

      {activeTab === 'podcast' && (
        <PodcastPanel
          lang={lang}
          uid={uid}
          profile={profile}
          activePlan={activePlan}
          subjects={subjects}
          lectures={lectures}
          podcasts={podcasts}
          selectedLectureId={selectedLectureId}
          onSelectLecture={setSelectedLectureId}
        />
      )}

      {activeTab === 'photo' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isAr ? 'تصوير أو رفع مسألة دراسية' : 'Capture or Upload Question Photo'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isAr
                ? 'يدعم المسائل الرياضية، الفيزيائية، الأكواد البرمجية، والأسئلة النظرية مع كشف أي جزء غير واضح.'
                : 'Supports math, physics, programming code, and theory questions with ambiguity checks.'}
            </p>
            <label className="w-full py-8 border border-dashed border-slate-300 dark:border-slate-700 rounded-2xl flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50">
              <Upload className="w-6 h-6 text-blue-600 dark:text-sky-400" />
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">
                {isAr ? 'التقاط صورة أو اختيار ملف' : 'Capture Camera or Select Image'}
              </span>
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </label>
            {photoPreview && (
              <img
                src={photoPreview}
                alt="Uploaded academic problem"
                className="w-full max-h-64 object-contain rounded-xl border border-slate-200 dark:border-slate-800"
              />
            )}
          </div>

          <div className="lg:col-span-7 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            {busy ? (
              <div className="py-16 flex flex-col items-center justify-center gap-3 text-slate-500">
                <Loader2 className="w-6 h-6 animate-spin" />
                <span className="text-sm">
                  {isAr ? 'جاري قراءة المسألة وحلها خطوة بخطوة...' : 'Reading and solving step-by-step...'}
                </span>
              </div>
            ) : !photoSolution ? (
              <div className="py-16 text-center text-sm text-slate-500 dark:text-slate-400">
                {isAr
                  ? 'ارفع صورة المسألة لعرض خطوات الحل والفكرة المستخدمة.'
                  : 'Upload a question image to see the step-by-step solution.'}
              </div>
            ) : (
              <div className="space-y-4">
                {photoSolution.clarityStatus === 'unclear' && photoSolution.unclearNote && (
                  <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-200">
                    {photoSolution.unclearNote}
                  </div>
                )}
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {isAr ? 'الموضوع:' : 'Topic:'} {photoSolution.topic}
                  </p>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                    {photoSolution.recognizedProblem}
                  </h3>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs">
                  <span className="font-semibold">{isAr ? 'الفكرة الأساسية: ' : 'Core Concept: '}</span>
                  {photoSolution.coreConcept}
                </div>
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    {isAr ? 'خطوات الحل:' : 'Solution Steps:'}
                  </p>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-slate-700 dark:text-slate-300">
                    {photoSolution.steps.map((step, i) => (
                      <li key={i}>{step}</li>
                    ))}
                  </ol>
                </div>
                <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                  <p className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                    {isAr ? 'الإجابة النهائية:' : 'Final Answer:'}
                  </p>
                  <p className="text-sm font-bold text-emerald-900 dark:text-emerald-100 mt-1">
                    {photoSolution.finalAnswer}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
