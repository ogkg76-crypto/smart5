import React, { useEffect, useState } from 'react';
import { doc, setDoc, updateDoc, serverTimestamp, increment } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  ExamAttempt,
  ExamQuestion,
  Language,
  Lecture,
  MistakeEntry,
  QuestionType,
  Subject,
  SubscriptionPlan,
  UserProfile,
} from '../types';
import {
  extractLectureFile,
  generateQuestions,
  gradeEssayAnswer,
  predictExamTopics,
} from '../services/api';
import {
  awardStudyXp,
  deleteDocSafe,
  getEffectiveLimit,
  makeId,
  trackAiUsageAndNotify,
} from '../services/firestoreHelpers';
import {
  CheckCircle2,
  XCircle,
  Clock,
  GraduationCap,
  Loader2,
  AlertCircle,
  RefreshCw,
  BookMarked,
  Sparkles,
  Trash2,
  FileUp,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  lectures: Lecture[];
  exams: ExamAttempt[];
  mistakes: MistakeEntry[];
  initialLectureId?: string;
  initialMode?: 'simulator' | 'mistakes' | 'predict';
}

const QUESTION_TYPES: { id: QuestionType; ar: string; en: string }[] = [
  { id: 'mcq', ar: 'اختيار من متعدد', en: 'Multiple Choice' },
  { id: 'true_false', ar: 'صح أم خطأ', en: 'True / False' },
  { id: 'fill_blank', ar: 'أكمل الفراغ', en: 'Fill in the Blank' },
  { id: 'essay', ar: 'سؤال مقالي', en: 'Essay' },
  { id: 'practical', ar: 'سؤال عملي', en: 'Practical' },
  { id: 'programming', ar: 'سؤال برمجي', en: 'Programming' },
  { id: 'definition', ar: 'تعريفات', en: 'Definitions' },
  { id: 'comparison', ar: 'مقارنات', en: 'Comparisons' },
];

export const ExamsView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  subjects,
  lectures,
  exams,
  mistakes,
  initialLectureId,
  initialMode,
}) => {
  const isAr = lang === 'ar';
  const [subMode, setSubMode] = useState<'simulator' | 'mistakes' | 'predict'>(
    initialMode || 'simulator'
  );
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || '');
  const [selectedLectureIds, setSelectedLectureIds] = useState<string[]>(
    initialLectureId ? [initialLectureId] : []
  );
  const [pageRangeNote, setPageRangeNote] = useState('');
  const [selectedTypes, setSelectedTypes] = useState<QuestionType[]>(['mcq', 'true_false', 'essay']);
  const [count, setCount] = useState(6);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [durationMinutes, setDurationMinutes] = useState(15);
  const [displayMode, setDisplayMode] = useState<'single' | 'all'>('single');

  const [activeExamId, setActiveExamId] = useState<string>('');
  const [currentQIdx, setCurrentQIdx] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [busy, setBusy] = useState(false);
  const [grading, setGrading] = useState(false);
  const [error, setError] = useState('');

  // Mistake Notebook filter
  const [mistakeSubjectFilter, setMistakeSubjectFilter] = useState<string>('all');
  const [mistakeStatusFilter, setMistakeStatusFilter] = useState<'all' | 'active' | 'mastered'>('active');

  // Exam Prediction state
  const [pastExamText, setPastExamText] = useState('');
  const [pastExamFileName, setPastExamFileName] = useState('');
  const [predictionResult, setPredictionResult] = useState<{
    disclaimer: string;
    recurringTopics: { topic: string; importanceScore: number; rationale: string }[];
    predictedQuestions: ExamQuestion[];
  } | null>(null);

  useEffect(() => {
    if (initialMode) setSubMode(initialMode);
  }, [initialMode]);

  useEffect(() => {
    if (initialLectureId) {
      const lec = lectures.find((l) => l.id === initialLectureId);
      if (lec) {
        setSelectedSubjectId(lec.subjectId);
        setSelectedLectureIds([lec.id]);
      }
    } else if (!selectedSubjectId && subjects[0]?.id) {
      setSelectedSubjectId(subjects[0].id);
    }
  }, [initialLectureId, lectures, subjects, selectedSubjectId]);

  const activeExam = exams.find((e) => e.id === activeExamId) || null;

  useEffect(() => {
    if (!activeExam || activeExam.status !== 'in_progress') return;
    if (secondsLeft <= 0) return;
    const timer = setInterval(() => {
      setSecondsLeft((s) => (s > 0 ? s - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [activeExam, secondsLeft]);

  const subjectLectures = lectures.filter((l) => l.subjectId === selectedSubjectId);

  const toggleLectureId = (id: string) => {
    setSelectedLectureIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleType = (type: QuestionType) => {
    setSelectedTypes((prev) =>
      prev.includes(type) ? (prev.length > 1 ? prev.filter((x) => x !== type) : prev) : [...prev, type]
    );
  };

  const launchCustomExam = async (params: {
    subjectId: string;
    lectureIds: string[];
    title: string;
    difficultyLevel: 'easy' | 'medium' | 'hard';
    minutes: number;
    questions: ExamQuestion[];
  }) => {
    const examId = makeId('exam');
    const cleanQuestions = params.questions.slice(0, 40).map((q, idx) => ({
      ...q,
      id: q.id || `q_${idx + 1}`,
      userAnswer: '',
    }));
    await setDoc(doc(db, 'exams', examId), {
      ownerId: uid,
      subjectId: params.subjectId,
      lectureIds: params.lectureIds.slice(0, 20),
      title: params.title.slice(0, 200),
      difficulty: params.difficultyLevel,
      durationMinutes: params.minutes,
      status: 'in_progress',
      scorePercent: 0,
      totalQuestions: cleanQuestions.length,
      correctCount: 0,
      questions: cleanQuestions,
      weakTopics: [],
      strongTopics: [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    setSubMode('simulator');
    setActiveExamId(examId);
    setCurrentQIdx(0);
    setSecondsLeft(params.minutes * 60);
  };

  const handleStartExam = async () => {
    const targetLectures =
      selectedLectureIds.length > 0
        ? lectures.filter((l) => selectedLectureIds.includes(l.id))
        : subjectLectures;

    if (targetLectures.length === 0) {
      setError(
        isAr
          ? 'يرجى اختيار مادة تحتوي على محاضرة واحدة على الأقل.'
          : 'Select a subject with at least one uploaded lecture.'
      );
      return;
    }

    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم استنفاد رصيد الذكاء الاصطناعي لباقتك.' : 'AI request limit reached.');
      return;
    }

    setBusy(true);
    setError('');
    try {
      let sourceText = targetLectures
        .map((l) => `=== Lecture: ${l.title} ===\n${l.fullTextPreview}`)
        .join('\n\n');
      if (pageRangeNote.trim()) {
        sourceText = `Focus strictly on section/pages: ${pageRangeNote.trim()}\n\n${sourceText}`;
      }

      const res = await generateQuestions({
        sourceText,
        count,
        types: selectedTypes,
        difficulty,
        lang: profile?.explanationLang || lang,
      });

      const subj = subjects.find((s) => s.id === selectedSubjectId);
      await launchCustomExam({
        subjectId: selectedSubjectId,
        lectureIds: targetLectures.map((l) => l.id),
        title: `${subj?.name || 'Exam'} — ${targetLectures.length} ${isAr ? 'محاضرات' : 'lectures'}`,
        difficultyLevel: difficulty,
        minutes: durationMinutes,
        questions: res.questions || [],
      });

      await trackAiUsageAndNotify({
        uid,
        enableNotif: profile?.notifAiReady !== false,
        notifTitle: isAr ? 'تم تجهيز الامتحان' : 'Exam Ready',
        notifBody: isAr
          ? `امتحان من ${(res.questions || []).length} سؤال جاهز الآن.`
          : `${(res.questions || []).length}-question exam ready.`,
        notifCategory: 'exam',
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate exam.');
    } finally {
      setBusy(false);
    }
  };

  const handleAnswerChange = async (qId: string, value: string) => {
    if (!activeExam || activeExam.status === 'completed') return;
    const updated = activeExam.questions.map((q) =>
      q.id === qId ? { ...q, userAnswer: value } : q
    );
    try {
      await updateDoc(doc(db, 'exams', activeExam.id), {
        questions: updated,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `exams/${activeExam.id}`);
    }
  };

  const handleSubmitExam = async () => {
    if (!activeExam || activeExam.status === 'completed') return;
    setGrading(true);
    setError('');
    try {
      const gradedQuestions: ExamQuestion[] = [];
      let correctCount = 0;
      const weakSet = new Set<string>();
      const strongSet = new Set<string>();
      const subjObj = subjects.find((s) => s.id === activeExam.subjectId);

      for (const q of activeExam.questions) {
        const userAns = (q.userAnswer || '').trim();
        if (q.type === 'mcq' || q.type === 'true_false') {
          const isCorrect = userAns.toLowerCase() === q.correctAnswer.trim().toLowerCase();
          if (isCorrect) {
            correctCount++;
            strongSet.add(q.topic);
          } else {
            weakSet.add(q.topic);
          }
          gradedQuestions.push({ ...q, isCorrect, aiScore: isCorrect ? 10 : 0 });
        } else if (!userAns) {
          weakSet.add(q.topic);
          gradedQuestions.push({
            ...q,
            isCorrect: false,
            aiScore: 0,
            aiFeedback: isAr ? 'لم يتم إدخال إجابة.' : 'No answer provided.',
          });
        } else {
          const aiGrade = await gradeEssayAnswer({
            question: q.question,
            expectedAnswer: q.correctAnswer,
            studentAnswer: userAns,
            lang: profile?.explanationLang || lang,
          });
          if (aiGrade.isCorrect) {
            correctCount++;
            strongSet.add(q.topic);
          } else {
            weakSet.add(q.topic);
          }
          gradedQuestions.push({
            ...q,
            isCorrect: aiGrade.isCorrect,
            aiScore: aiGrade.scoreOutOf10,
            aiFeedback: aiGrade.feedback,
          });
        }
      }

      const scorePercent = Math.round(
        (correctCount / Math.max(gradedQuestions.length, 1)) * 100
      );

      await updateDoc(doc(db, 'exams', activeExam.id), {
        status: 'completed',
        scorePercent,
        correctCount,
        questions: gradedQuestions,
        weakTopics: Array.from(weakSet).slice(0, 20),
        strongTopics: Array.from(strongSet).slice(0, 20),
        updatedAt: serverTimestamp(),
      });

      // Automatically record wrong answers in Mistake Notebook
      if (subjObj) {
        for (const q of gradedQuestions.filter((item) => !item.isCorrect)) {
          const mId = makeId('err');
          await setDoc(doc(db, 'mistakes', mId), {
            ownerId: uid,
            subjectId: subjObj.id,
            subjectName: subjObj.name.slice(0, 120),
            examId: activeExam.id,
            topic: (q.topic || 'General').slice(0, 160),
            question: q.question.slice(0, 1500),
            wrongAnswer: (q.userAnswer || (isAr ? 'بدون إجابة' : 'No answer')).slice(0, 1000),
            correctAnswer: (q.correctAnswer || 'N/A').slice(0, 1000),
            explanation: (q.explanation || q.aiFeedback || '').slice(0, 3000),
            mastered: false,
            reviewCount: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      }

      await awardStudyXp(uid, profile, 30 + Math.round(scorePercent / 5));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Grading failed.');
    } finally {
      setGrading(false);
    }
  };

  const toggleMistakeMastered = async (entry: MistakeEntry) => {
    try {
      await updateDoc(doc(db, 'mistakes', entry.id), {
        mastered: !entry.mastered,
        reviewCount: increment(1),
        updatedAt: serverTimestamp(),
      });
      if (!entry.mastered) {
        await awardStudyXp(uid, profile, 10);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `mistakes/${entry.id}`);
    }
  };

  const handleQuizFromMistakes = async () => {
    const pool = filteredMistakes.filter((m) => !m.mastered);
    const chosen = (pool.length > 0 ? pool : filteredMistakes).slice(0, 15);
    if (chosen.length === 0) return;

    const targetSubjId = chosen[0].subjectId;
    const quizQuestions: ExamQuestion[] = chosen.map((m, idx) => ({
      id: `mq_${idx + 1}`,
      type: 'essay',
      topic: m.topic,
      question: m.question,
      correctAnswer: m.correctAnswer,
      explanation: m.explanation,
      sourceCitation: isAr ? 'دفتر الأخطاء' : 'Mistake Notebook',
      userAnswer: '',
    }));

    await launchCustomExam({
      subjectId: targetSubjId,
      lectureIds: [],
      title: isAr ? `مراجعة الأخطاء (${chosen.length} سؤال)` : `Mistake Review Quiz (${chosen.length})`,
      difficultyLevel: 'medium',
      minutes: Math.max(5, chosen.length * 2),
      questions: quizQuestions,
    });
  };

  const handlePastExamUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    setError('');
    try {
      const res = await extractLectureFile(file);
      setPastExamText(res.fullTextPreview.slice(0, 20000));
      setPastExamFileName(file.name);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to parse past exam.');
    } finally {
      setBusy(false);
      e.target.value = '';
    }
  };

  const handlePredictExam = async () => {
    const subj = subjects.find((s) => s.id === selectedSubjectId);
    const subjLectures = lectures.filter((l) => l.subjectId === selectedSubjectId);
    if (!subj || subjLectures.length === 0) {
      setError(
        isAr ? 'اختر مادة تحتوي على محاضرات أولًا.' : 'Select a subject with lectures first.'
      );
      return;
    }
    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم استنفاد رصيد الذكاء الاصطناعي لباقتك.' : 'AI request limit reached.');
      return;
    }

    setBusy(true);
    setError('');
    try {
      const lecturesText = subjLectures
        .map((l) => `=== ${l.title} ===\n${l.fullTextPreview.slice(0, 8000)}`)
        .join('\n\n');
      const res = await predictExamTopics({
        subjectName: subj.name,
        lecturesText,
        pastExamText,
        lang: profile?.explanationLang || lang,
      });
      setPredictionResult(res);
      await trackAiUsageAndNotify({ uid, xpDelta: 20 });
      await awardStudyXp(uid, profile, 20);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Prediction failed.');
    } finally {
      setBusy(false);
    }
  };

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const filteredMistakes = mistakes.filter((m) => {
    if (mistakeSubjectFilter !== 'all' && m.subjectId !== mistakeSubjectFilter) return false;
    if (mistakeStatusFilter === 'active' && m.mastered) return false;
    if (mistakeStatusFilter === 'mastered' && !m.mastered) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'الامتحانات، دفتر الأخطاء، والتوقعات' : 'Exams, Mistake Notebook & Predictor'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'محاكاة امتحانات بـ 8 أنماط، حفظ تلقائي للأخطاء للمراجعة، وتوقع الموضوعات المهمة.'
              : '8-format exam simulator, automatic Mistake Notebook tracking, and AI topic prediction.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl">
            <button
              onClick={() => setSubMode('simulator')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
                subMode === 'simulator'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>{isAr ? 'محاكي الامتحان' : 'Simulator'}</span>
            </button>
            <button
              onClick={() => {
                setSubMode('mistakes');
                setActiveExamId('');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
                subMode === 'mistakes'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <BookMarked className="w-3.5 h-3.5" />
              <span>
                {isAr ? 'دفتر الأخطاء' : 'Mistakes'} ({mistakes.filter((m) => !m.mastered).length})
              </span>
            </button>
            <button
              onClick={() => {
                setSubMode('predict');
                setActiveExamId('');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
                subMode === 'predict'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isAr ? 'توقع الامتحان' : 'Predictor'}</span>
            </button>
          </div>

          {activeExam && (
            <button
              onClick={() => setActiveExamId('')}
              className="px-3.5 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl"
            >
              {isAr ? 'امتحان جديد' : 'New Exam'}
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {subMode === 'mistakes' && (
        <div className="space-y-6">
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3">
              <select
                value={mistakeSubjectFilter}
                onChange={(e) => setMistakeSubjectFilter(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="all">{isAr ? 'كل المواد' : 'All Subjects'}</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>

              <select
                value={mistakeStatusFilter}
                onChange={(e) => setMistakeStatusFilter(e.target.value as 'all' | 'active' | 'mastered')}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="active">{isAr ? 'تحتاج مراجعة' : 'Needs Review'}</option>
                <option value="mastered">{isAr ? 'تم إتقانها' : 'Mastered'}</option>
                <option value="all">{isAr ? 'الكل' : 'All'}</option>
              </select>
            </div>

            <button
              disabled={filteredMistakes.length === 0}
              onClick={handleQuizFromMistakes}
              className="px-4 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl disabled:opacity-50 flex items-center gap-1.5"
            >
              <GraduationCap className="w-4 h-4" />
              <span>{isAr ? 'اختبار من دفتر الأخطاء' : 'Quiz from Mistakes'}</span>
            </button>
          </div>

          {filteredMistakes.length === 0 ? (
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center space-y-2 text-slate-500">
              <BookMarked className="w-8 h-8 mx-auto opacity-50" />
              <p className="text-sm">
                {isAr
                  ? 'لا توجد أخطاء مسجلة هنا. يتم حفظ أي إجابة خاطئة في الامتحانات تلقائيًا للمراجعة.'
                  : 'No mistakes recorded in this filter. Wrong exam answers are saved here automatically.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredMistakes.map((m) => (
                <div
                  key={m.id}
                  className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-xs font-semibold text-blue-600 dark:text-sky-400">
                      {m.subjectName} · {m.topic}
                    </p>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => toggleMistakeMastered(m)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold ${
                          m.mastered
                            ? 'bg-emerald-600 text-white'
                            : 'border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {m.mastered ? (isAr ? 'متقن' : 'Mastered') : isAr ? 'تعليم كمتقن' : 'Mark Mastered'}
                      </button>
                      <button
                        onClick={() => deleteDocSafe('mistakes', m.id)}
                        className="p-1 text-slate-400 hover:text-red-500"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">{m.question}</p>
                  <div className="text-xs space-y-1.5">
                    <p className="text-red-600 dark:text-red-400">
                      <span className="font-semibold">{isAr ? 'إجابتك: ' : 'Your answer: '}</span>
                      {m.wrongAnswer}
                    </p>
                    <p className="text-emerald-700 dark:text-emerald-400">
                      <span className="font-semibold">{isAr ? 'الإجابة الصحيحة: ' : 'Correct answer: '}</span>
                      {m.correctAnswer}
                    </p>
                    {m.explanation && (
                      <p className="text-slate-600 dark:text-slate-400 pt-1">{m.explanation}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {subMode === 'predict' && (
        <div className="space-y-6">
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-3 flex-1">
                <select
                  value={selectedSubjectId}
                  onChange={(e) => setSelectedSubjectId(e.target.value)}
                  className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg min-w-[220px]"
                >
                  <option value="">{isAr ? 'اختر المادة...' : 'Select subject...'}</option>
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>

                <label className="px-3.5 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer flex items-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-800">
                  <FileUp className="w-4 h-4 text-blue-600 dark:text-sky-400" />
                  <span>
                    {pastExamFileName || (isAr ? 'رفع امتحان سابق (اختياري)' : 'Upload Past Exam (Optional)')}
                  </span>
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
                    onChange={handlePastExamUpload}
                    className="hidden"
                  />
                </label>
              </div>

              <button
                disabled={busy || !selectedSubjectId}
                onClick={handlePredictExam}
                className="px-5 py-2.5 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2"
              >
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>{isAr ? 'تحليل وتوقع أسئلة الامتحان' : 'Predict Likely Exam Topics'}</span>
              </button>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isAr
                ? 'ملاحظة: يعتمد التحليل على تكرار الموضوعات وكثافتها في محاضراتك والامتحانات السابقة المرفوعة فقط للمساعدة في التمرين، وليس تنبؤًا رسميًا.'
                : 'Note: Estimates are computed strictly from concept weight & recurrence in your uploaded lectures and optional past exam for study prioritization.'}
            </p>
          </div>

          {predictionResult && (
            <div className="space-y-6">
              <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200">
                {predictionResult.disclaimer}
              </div>

              <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h2 className="text-base font-bold text-slate-900 dark:text-white">
                    {isAr ? 'أهم الموضوعات المرجح التركيز عليها' : 'Weighted High-Yield Topics'}
                  </h2>
                  {predictionResult.predictedQuestions?.length > 0 && (
                    <button
                      onClick={() => {
                        const subj = subjects.find((s) => s.id === selectedSubjectId);
                        launchCustomExam({
                          subjectId: selectedSubjectId,
                          lectureIds: subjectLectures.map((l) => l.id),
                          title: `${subj?.name || 'Subject'} — ${isAr ? 'امتحان متوقع' : 'Predicted Practice'}`,
                          difficultyLevel: 'hard',
                          minutes: 20,
                          questions: predictionResult.predictedQuestions,
                        });
                      }}
                      className="px-4 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl flex items-center gap-1.5"
                    >
                      <GraduationCap className="w-4 h-4" />
                      <span>{isAr ? 'ابدأ امتحان الأسئلة المتوقعة' : 'Start Predicted Practice Quiz'}</span>
                    </button>
                  )}
                </div>

                <div className="space-y-3">
                  {predictionResult.recurringTopics.map((t, i) => (
                    <div
                      key={i}
                      className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-sm font-bold text-slate-900 dark:text-white">{t.topic}</p>
                        <span className="text-xs font-mono font-bold text-blue-600 dark:text-sky-400 tabular-nums">
                          {t.importanceScore}%
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full accent-btn-gradient"
                          style={{ width: `${Math.min(100, Math.max(5, t.importanceScore))}%` }}
                        />
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">{t.rationale}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {subMode === 'simulator' &&
        (!activeExam ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'إعداد الامتحان أو التدريب' : 'Configure Exam / Quiz'}
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                    {isAr ? 'المادة الدراسية' : 'Subject'}
                  </label>
                  <select
                    value={selectedSubjectId}
                    onChange={(e) => {
                      setSelectedSubjectId(e.target.value);
                      setSelectedLectureIds([]);
                    }}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="">{isAr ? 'اختر مادة...' : 'Select subject...'}</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                    {isAr ? 'جزء محدد / صفحات (اختياري)' : 'Specific Pages / Topic (Optional)'}
                  </label>
                  <input
                    value={pageRangeNote}
                    onChange={(e) => setPageRangeNote(e.target.value)}
                    placeholder={isAr ? 'مثال: صفحة 1 إلى 4' : 'e.g. Pages 1-4'}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>
              </div>

              {subjectLectures.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                    {isAr
                      ? 'اختر محاضرة أو عدة محاضرات (اتركه فارغًا لامتحان شامل على المادة):'
                      : 'Select one or more lectures (leave unchecked for full-subject exam):'}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {subjectLectures.map((l) => {
                      const checked = selectedLectureIds.includes(l.id);
                      return (
                        <button
                          key={l.id}
                          type="button"
                          onClick={() => toggleLectureId(l.id)}
                          className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${
                            checked
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {l.title}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                  {isAr ? 'أنواع الأسئلة:' : 'Question Types:'}
                </p>
                <div className="flex flex-wrap gap-2">
                  {QUESTION_TYPES.map((qt) => {
                    const active = selectedTypes.includes(qt.id);
                    return (
                      <button
                        key={qt.id}
                        type="button"
                        onClick={() => toggleType(qt.id)}
                        className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${
                          active
                            ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900 dark:border-white font-semibold'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {isAr ? qt.ar : qt.en}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {isAr ? 'عدد الأسئلة' : 'Count'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    value={count}
                    onChange={(e) => setCount(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {isAr ? 'الصعوبة' : 'Difficulty'}
                  </label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as 'easy' | 'medium' | 'hard')}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="easy">{isAr ? 'سهل' : 'Easy'}</option>
                    <option value="medium">{isAr ? 'متوسط' : 'Medium'}</option>
                    <option value="hard">{isAr ? 'صعب' : 'Hard'}</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {isAr ? 'الوقت (دقيقة)' : 'Minutes'}
                  </label>
                  <input
                    type="number"
                    min={2}
                    max={180}
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {isAr ? 'عرض الأسئلة' : 'Layout'}
                  </label>
                  <select
                    value={displayMode}
                    onChange={(e) => setDisplayMode(e.target.value as 'single' | 'all')}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="single">{isAr ? 'سؤال واحد' : 'One by one'}</option>
                    <option value="all">{isAr ? 'كل الأسئلة' : 'All in page'}</option>
                  </select>
                </div>
              </div>

              <button
                disabled={busy || !selectedSubjectId}
                onClick={handleStartExam}
                className="w-full py-2.5 px-4 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2"
              >
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <GraduationCap className="w-4 h-4" />}
                <span>{isAr ? 'بدء الامتحان الآن' : 'Generate & Start Exam'}</span>
              </button>
            </div>

            {/* Exam History */}
            <div className="lg:col-span-5 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'سجل الامتحانات السابقة' : 'Past Exam History'}
              </h2>
              {exams.length === 0 ? (
                <p className="text-sm text-slate-500 py-8 text-center">
                  {isAr ? 'لم تقم بأي امتحانات بعد.' : 'No exams taken yet.'}
                </p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[420px] overflow-y-auto">
                  {exams.map((ex) => (
                    <div key={ex.id} className="py-3 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                          {ex.title}
                        </p>
                        <p className="text-xs text-slate-500 tabular-nums mt-0.5">
                          {ex.status === 'completed'
                            ? `${ex.scorePercent}% (${ex.correctCount}/${ex.totalQuestions})`
                            : isAr
                              ? 'قيد التنفيذ'
                              : 'In progress'}{' '}
                          · {ex.difficulty}
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setActiveExamId(ex.id);
                          setCurrentQIdx(0);
                        }}
                        className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg shrink-0"
                      >
                        {ex.status === 'completed' ? (isAr ? 'مراجعة' : 'Review') : isAr ? 'استكمال' : 'Resume'}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {activeExam.title}
                </h2>
                <p className="text-xs text-slate-500 tabular-nums mt-0.5">
                  {activeExam.totalQuestions} {isAr ? 'أسئلة' : 'questions'} · {activeExam.difficulty}
                </p>
              </div>

              {activeExam.status === 'in_progress' ? (
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-sm font-mono font-semibold text-blue-600 dark:text-sky-400 tabular-nums">
                    <Clock className="w-4 h-4" />
                    <span>{formatTime(secondsLeft)}</span>
                  </div>
                  <button
                    disabled={grading}
                    onClick={handleSubmitExam}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5"
                  >
                    {grading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    <span>{isAr ? 'تسليم وتصحيح الامتحان' : 'Submit & Grade'}</span>
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-4">
                  <span className="text-lg font-bold text-slate-900 dark:text-white tabular-nums">
                    {isAr ? 'النتيجة:' : 'Score:'} {activeExam.scorePercent}% ({activeExam.correctCount}/
                    {activeExam.totalQuestions})
                  </span>
                  <button
                    onClick={() => {
                      setActiveExamId('');
                      handleStartExam();
                    }}
                    className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{isAr ? 'اختبار جديد بأسئلة مختلفة' : 'New Quiz'}</span>
                  </button>
                </div>
              )}
            </div>

            {displayMode === 'single' && activeExam.status === 'in_progress' && (
              <div className="flex flex-wrap gap-1.5">
                {activeExam.questions.map((q, idx) => (
                  <button
                    key={q.id}
                    onClick={() => setCurrentQIdx(idx)}
                    className={`w-8 h-8 rounded-lg text-xs font-mono font-medium border ${
                      idx === currentQIdx
                        ? 'bg-blue-600 text-white border-blue-600'
                        : q.userAnswer
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white border-slate-300 dark:border-slate-700'
                          : 'border-slate-200 dark:border-slate-800 text-slate-500'
                    }`}
                  >
                    {idx + 1}
                  </button>
                ))}
              </div>
            )}

            <div className="space-y-6">
              {(displayMode === 'single' && activeExam.status === 'in_progress'
                ? [activeExam.questions[currentQIdx]].filter(Boolean)
                : activeExam.questions
              ).map((q, idx) => {
                const displayIdx =
                  displayMode === 'single' && activeExam.status === 'in_progress' ? currentQIdx : idx;
                return (
                  <div
                    key={q.id}
                    className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {q.topic} · {q.type} · {q.sourceCitation}
                        </p>
                        <p className="text-base font-medium text-slate-900 dark:text-white">
                          {displayIdx + 1}. {q.question}
                        </p>
                      </div>
                      {activeExam.status === 'completed' && (
                        <div className="flex items-center gap-1.5 shrink-0 text-xs font-semibold">
                          {q.isCorrect ? (
                            <span className="text-emerald-600 flex items-center gap-1">
                              <CheckCircle2 className="w-4 h-4" /> {isAr ? 'صحيح' : 'Correct'}
                            </span>
                          ) : (
                            <span className="text-red-500 flex items-center gap-1">
                              <XCircle className="w-4 h-4" /> {isAr ? 'خطأ (حُفظ بدفتر الأخطاء)' : 'Incorrect (Saved)'}
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {q.options && q.options.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {q.options.map((opt, oi) => {
                          const selected = q.userAnswer === opt;
                          return (
                            <button
                              key={oi}
                              disabled={activeExam.status === 'completed'}
                              onClick={() => handleAnswerChange(q.id, opt)}
                              className={`p-3 rounded-lg border text-start text-sm transition-colors ${
                                selected
                                  ? 'bg-blue-50 dark:bg-sky-950/50 border-blue-600 text-blue-900 dark:text-sky-200 font-medium'
                                  : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                              }`}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <textarea
                        rows={3}
                        disabled={activeExam.status === 'completed'}
                        value={q.userAnswer || ''}
                        onChange={(e) => handleAnswerChange(q.id, e.target.value)}
                        placeholder={isAr ? 'اكتب إجابتك هنا...' : 'Write your answer here...'}
                        className="w-full p-3 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                    )}

                    {activeExam.status === 'completed' && (
                      <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
                        <p>
                          <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                            {isAr ? 'الإجابة النموذجية: ' : 'Model Answer: '}
                          </span>
                          {q.correctAnswer}
                        </p>
                        <p className="text-slate-600 dark:text-slate-400">{q.explanation}</p>
                        {q.aiFeedback && (
                          <p className="text-blue-600 dark:text-sky-400 pt-1">
                            {isAr ? `تقييم AI (${q.aiScore}/10): ` : `AI Evaluation (${q.aiScore}/10): `}
                            {q.aiFeedback}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {displayMode === 'single' && activeExam.status === 'in_progress' && (
              <div className="flex items-center justify-between pt-2">
                <button
                  disabled={currentQIdx === 0}
                  onClick={() => setCurrentQIdx((i) => Math.max(0, i - 1))}
                  className="px-4 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-40"
                >
                  {isAr ? 'السابق' : 'Previous'}
                </button>
                <button
                  disabled={currentQIdx >= activeExam.questions.length - 1}
                  onClick={() => setCurrentQIdx((i) => Math.min(activeExam.questions.length - 1, i + 1))}
                  className="px-4 py-2 text-xs font-medium bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg disabled:opacity-40"
                >
                  {isAr ? 'التالي' : 'Next'}
                </button>
              </div>
            )}
          </div>
        ))}
    </div>
  );
};
