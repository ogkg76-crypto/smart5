import React, { useEffect, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
  serverTimestamp,
  increment,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  BattleParticipant,
  ChallengeScore,
  ExamAttempt,
  GroupDiscussionMessage,
  Language,
  Lecture,
  MistakeEntry,
  SharedResource,
  StudyBattle,
  StudyGroup,
  Subject,
  UserProfile,
} from '../types';
import { generateQuestions, generateWeeklyReport } from '../services/api';
import {
  awardStudyXp,
  deleteDocSafe,
  makeId,
  trackAiUsageAndNotify,
  updateUserPreferences,
} from '../services/firestoreHelpers';
import {
  BarChart3,
  Users,
  Trophy,
  Flag,
  Plus,
  Swords,
  Sparkles,
  Award,
  Flame,
  Send,
  Trash2,
  Loader2,
  MessageSquare,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  subjects: Subject[];
  lectures: Lecture[];
  exams: ExamAttempt[];
  mistakes: MistakeEntry[];
  studyGroups: StudyGroup[];
  sharedResources: SharedResource[];
  challengeScores: ChallengeScore[];
  studyBattles: StudyBattle[];
}

export const ProgressSocialView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  subjects,
  lectures,
  exams,
  mistakes,
  studyGroups,
  sharedResources,
  challengeScores,
  studyBattles,
}) => {
  const isAr = lang === 'ar';
  const [tab, setTab] = useState<'analytics' | 'battles' | 'social'>('analytics');

  // Weekly AI Report
  const [reportBusy, setReportBusy] = useState(false);
  const [weeklyReport, setWeeklyReport] = useState('');

  // Study Group & Discussion state
  const [groupName, setGroupName] = useState('');
  const [groupSubj, setGroupSubj] = useState('');
  const [groupDesc, setGroupDesc] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [activeGroupId, setActiveGroupId] = useState(studyGroups[0]?.id || '');
  const [discussions, setDiscussions] = useState<GroupDiscussionMessage[]>([]);
  const [chatMsg, setChatMsg] = useState('');

  // Study Battle state
  const [battleTitle, setBattleTitle] = useState('');
  const [battleSubjectId, setBattleSubjectId] = useState(subjects[0]?.id || '');
  const [battleDiff, setBattleDiff] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [battleBusy, setBattleBusy] = useState(false);
  const [playingBattleId, setPlayingBattleId] = useState<string>('');
  const [battleAnswers, setBattleAnswers] = useState<Record<string, string>>({});
  const [battleError, setBattleError] = useState('');

  // Report modal
  const [reportTarget, setReportTarget] = useState<{ type: 'group' | 'resource'; id: string } | null>(
    null
  );
  const [reportReason, setReportReason] = useState('');
  const [reportSent, setReportSent] = useState(false);

  useEffect(() => {
    if (!activeGroupId && studyGroups[0]?.id) {
      setActiveGroupId(studyGroups[0].id);
    }
  }, [studyGroups, activeGroupId]);

  useEffect(() => {
    if (!activeGroupId) {
      setDiscussions([]);
      return;
    }
    const q = query(collection(db, 'groupDiscussions'), where('groupId', '==', activeGroupId));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }) as GroupDiscussionMessage);
        setDiscussions(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'groupDiscussions')
    );
    return () => unsub();
  }, [activeGroupId]);

  // Real data-driven analytics
  const completedExams = exams.filter((e) => e.status === 'completed');
  const avgExamScore =
    completedExams.length > 0
      ? Math.round(completedExams.reduce((acc, e) => acc + e.scorePercent, 0) / completedExams.length)
      : 0;
  const studiedLecturesCount = lectures.filter((l) => l.progressPercent > 0).length;
  const avgSubjectCompletion =
    lectures.length > 0
      ? Math.round(lectures.reduce((acc, l) => acc + l.progressPercent, 0) / lectures.length)
      : 0;

  const xp = profile?.xpPoints ?? 0;
  const level = Math.floor(xp / 200) + 1;
  const streak = profile?.streakDays ?? 0;

  const earnedBadges = [
    {
      id: 'first_lec',
      unlocked: lectures.length >= 1,
      ar: 'المحاضرة الأولى',
      en: 'First Lecture',
    },
    {
      id: 'five_exams',
      unlocked: completedExams.length >= 5,
      ar: 'محترف الاختبارات (5+)',
      en: '5+ Exams Mastered',
    },
    {
      id: 'streak_7',
      unlocked: streak >= 7,
      ar: 'انضباط أسبوعي (7 أيام)',
      en: '7-Day Study Streak',
    },
    {
      id: 'mistake_crusher',
      unlocked: mistakes.filter((m) => m.mastered).length >= 3,
      ar: 'صائد الأخطاء',
      en: 'Mistake Crusher',
    },
  ];

  // Aggregate actual topic performance from graded exam questions
  const topicStats = new Map<string, { correct: number; total: number }>();
  for (const exam of completedExams) {
    for (const q of exam.questions) {
      const current = topicStats.get(q.topic) || { correct: 0, total: 0 };
      current.total += 1;
      if (q.isCorrect) current.correct += 1;
      topicStats.set(q.topic, current);
    }
  }

  const strongTopics: string[] = [];
  const weakTopics: string[] = [];
  topicStats.forEach((stat, topic) => {
    const pct = stat.correct / stat.total;
    if (pct >= 0.75) strongTopics.push(`${topic} (${Math.round(pct * 100)}%)`);
    else weakTopics.push(`${topic} (${Math.round(pct * 100)}%)`);
  });

  const handleGenerateWeeklyReport = async () => {
    setReportBusy(true);
    try {
      const res = await generateWeeklyReport({
        metrics: {
          xpPoints: xp,
          level,
          streakDays: streak,
          subjectsCount: subjects.length,
          lecturesCount: lectures.length,
          studiedLecturesCount,
          avgCompletionPercent: avgSubjectCompletion,
          completedExamsCount: completedExams.length,
          avgExamScorePercent: avgExamScore,
          strongTopics,
          weakTopics,
          unmasteredMistakesCount: mistakes.filter((m) => !m.mastered).length,
          studyHoursLogged: profile?.studyHoursLogged ?? 0,
        },
        lang,
      });
      setWeeklyReport(res.report);
      await trackAiUsageAndNotify({ uid });
    } catch (err) {
      setWeeklyReport(err instanceof Error ? err.message : 'Report generation failed.');
    } finally {
      setReportBusy(false);
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim() || !groupSubj.trim()) return;
    const id = makeId('grp');
    try {
      await setDoc(doc(db, 'studyGroups', id), {
        ownerId: uid,
        ownerName: profile?.displayName || 'Student',
        name: groupName.trim().slice(0, 120),
        subjectName: groupSubj.trim().slice(0, 120),
        description: groupDesc.trim().slice(0, 500),
        isPublic,
        memberCount: 1,
        createdAt: serverTimestamp(),
      });
      setGroupName('');
      setGroupSubj('');
      setGroupDesc('');
      setActiveGroupId(id);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `studyGroups/${id}`);
    }
  };

  const handleJoinGroup = async (groupId: string) => {
    try {
      await updateDoc(doc(db, 'studyGroups', groupId), {
        memberCount: increment(1),
      });
      setActiveGroupId(groupId);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `studyGroups/${groupId}`);
    }
  };

  const handleSendDiscussion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGroupId || !chatMsg.trim()) return;
    const id = makeId('msg');
    try {
      await setDoc(doc(db, 'groupDiscussions', id), {
        ownerId: uid,
        ownerName: (profile?.displayName || 'Student').slice(0, 120),
        groupId: activeGroupId,
        text: chatMsg.trim().slice(0, 2000),
        createdAt: serverTimestamp(),
      });
      setChatMsg('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `groupDiscussions/${id}`);
    }
  };

  const handleCreateBattle = async (e: React.FormEvent) => {
    e.preventDefault();
    const subj = subjects.find((s) => s.id === battleSubjectId);
    const subjLectures = lectures.filter((l) => l.subjectId === battleSubjectId);
    if (!subj || subjLectures.length === 0) {
      setBattleError(
        isAr
          ? 'اختر مادة تحتوي على محاضرة واحدة على الأقل لتوليد أسئلة التحدي.'
          : 'Select a subject with at least one lecture to generate battle questions.'
      );
      return;
    }
    setBattleBusy(true);
    setBattleError('');
    try {
      const sourceText = subjLectures
        .map((l) => `=== ${l.title} ===\n${l.fullTextPreview.slice(0, 6000)}`)
        .join('\n\n');
      const res = await generateQuestions({
        sourceText,
        count: 5,
        types: ['mcq', 'true_false'],
        difficulty: battleDiff,
        lang,
      });
      const qs = (res.questions || []).slice(0, 10);
      if (qs.length === 0) throw new Error('No questions generated.');

      const bId = makeId('bat');
      await setDoc(doc(db, 'studyBattles', bId), {
        ownerId: uid,
        ownerName: (profile?.displayName || 'Student').slice(0, 120),
        title: (battleTitle.trim() || `${subj.name} Battle`).slice(0, 160),
        subjectName: subj.name.slice(0, 120),
        difficulty: battleDiff,
        durationMinutes: 10,
        status: 'open',
        questions: qs,
        participants: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setBattleTitle('');
      setPlayingBattleId(bId);
      setBattleAnswers({});
      await trackAiUsageAndNotify({ uid, xpDelta: 15 });
    } catch (err) {
      setBattleError(err instanceof Error ? err.message : 'Failed to create battle.');
    } finally {
      setBattleBusy(false);
    }
  };

  const handleSubmitBattle = async (battle: StudyBattle) => {
    let correct = 0;
    for (const q of battle.questions) {
      const ans = (battleAnswers[q.id] || '').trim().toLowerCase();
      if (ans && ans === q.correctAnswer.trim().toLowerCase()) {
        correct++;
      }
    }
    const score = Math.round((correct / Math.max(battle.questions.length, 1)) * 100);
    const entry: BattleParticipant = {
      uid,
      name: profile?.displayName || 'Student',
      score,
      finishedAt: new Date().toISOString(),
    };
    const nextParticipants = [
      ...battle.participants.filter((p) => p.uid !== uid),
      entry,
    ].slice(0, 30);

    try {
      await updateDoc(doc(db, 'studyBattles', battle.id), {
        participants: nextParticipants,
        updatedAt: serverTimestamp(),
      });
      await awardStudyXp(uid, profile, 30 + Math.round(score / 4));
      setPlayingBattleId('');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `studyBattles/${battle.id}`);
    }
  };

  const handleLogChallengeScore = async (groupId: string, challengeTitle: string) => {
    const id = makeId('chg');
    const latestExamScore = completedExams[0]?.scorePercent ?? 85;
    try {
      await setDoc(doc(db, 'challengeScores', id), {
        ownerId: uid,
        studentName: profile?.displayName || 'Student',
        groupId,
        challengeTitle: challengeTitle.slice(0, 160),
        score: latestExamScore,
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `challengeScores/${id}`);
    }
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportTarget || !reportReason.trim()) return;
    const id = makeId('rep');
    try {
      await setDoc(doc(db, 'reports', id), {
        reporterId: uid,
        targetType: reportTarget.type,
        targetId: reportTarget.id,
        reason: reportReason.trim().slice(0, 500),
        status: 'open',
        createdAt: serverTimestamp(),
      });
      setReportTarget(null);
      setReportReason('');
      setReportSent(true);
      setTimeout(() => setReportSent(false), 3000);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `reports/${id}`);
    }
  };

  const sortedLeaderboard = [...challengeScores].sort((a, b) => b.score - a.score).slice(0, 10);
  const activeBattle = studyBattles.find((b) => b.id === playingBattleId) || null;
  const activeGroup = studyGroups.find((g) => g.id === activeGroupId) || null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'الإنجاز، التحديات، والمجتمع التعليمي' : 'Analytics, Study Battles & Groups'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'نقاط الخبرة والأوسمة، التقرير الأسبوعي بالذكاء الاصطناعي، تحديات الاختبار الحية، ومجموعات المذاكرة.'
              : 'XP & badges, AI Weekly Report, live Study Battles, and collaborative study groups.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl self-start">
          <button
            onClick={() => setTab('analytics')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
              tab === 'analytics'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>{isAr ? 'تحليل المستوى' : 'Analytics'}</span>
          </button>
          <button
            onClick={() => setTab('battles')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
              tab === 'battles'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Swords className="w-3.5 h-3.5" />
            <span>{isAr ? 'معارك التحدي' : 'Study Battles'}</span>
          </button>
          <button
            onClick={() => setTab('social')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
              tab === 'social'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>{isAr ? 'مجموعات المذاكرة' : 'Study Groups'}</span>
          </button>
        </div>
      </div>

      {/* Gamification XP & Badges Strip */}
      <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-5">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500" />
              <span className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
                {isAr ? `المستوى ${level}` : `Level ${level}`} · {xp} XP
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-500" />
              <span className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
                {streak} {isAr ? 'أيام متتالية' : 'day streak'}
              </span>
            </div>
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
            <input
              type="checkbox"
              checked={Boolean(profile?.showOnLeaderboard)}
              onChange={(e) =>
                updateUserPreferences(uid, { showOnLeaderboard: e.target.checked })
              }
            />
            <span>{isAr ? 'إظهار اسمي في لوحة المتصدرين' : 'Show my name on Challenge Leaderboard'}</span>
          </label>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {earnedBadges.map((b) => (
            <div
              key={b.id}
              className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                b.unlocked
                  ? 'border-amber-300/70 dark:border-amber-700/70 bg-amber-50/70 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200 font-semibold'
                  : 'border-slate-200 dark:border-slate-800 text-slate-400 opacity-60'
              }`}
            >
              <Trophy className="w-4 h-4 shrink-0" />
              <span>{isAr ? b.ar : b.en}</span>
            </div>
          ))}
        </div>
      </div>

      {tab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
              <p className="text-xs text-slate-500">{isAr ? 'متوسط درجات الامتحانات' : 'Exam Average'}</p>
              <p className="text-2xl font-bold mt-1 tabular-nums">{avgExamScore}%</p>
            </div>
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
              <p className="text-xs text-slate-500">{isAr ? 'نسبة إكمال المواد' : 'Course Completion'}</p>
              <p className="text-2xl font-bold mt-1 tabular-nums">{avgSubjectCompletion}%</p>
            </div>
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
              <p className="text-xs text-slate-500">{isAr ? 'المحاضرات المدروسة' : 'Lectures Studied'}</p>
              <p className="text-2xl font-bold mt-1 tabular-nums">
                {studiedLecturesCount} / {lectures.length}
              </p>
            </div>
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
              <p className="text-xs text-slate-500">{isAr ? 'ساعات المذاكرة المنجزة' : 'Study Hours Logged'}</p>
              <p className="text-2xl font-bold mt-1 tabular-nums">
                {(profile?.studyHoursLogged ?? 0).toFixed(1)}h
              </p>
            </div>
          </div>

          {/* Weekly AI Report */}
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-500" />
                  <span>{isAr ? 'تقرير الأداء الأسبوعي الذكي' : 'AI Weekly Performance Report'}</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isAr
                    ? 'يحلل أرقامك الفعلية ويقترح خطة تحسين مخصصة للأسبوع القادم.'
                    : 'Analyzes your verified metrics to generate an actionable study plan for next week.'}
                </p>
              </div>
              <button
                disabled={reportBusy}
                onClick={handleGenerateWeeklyReport}
                className="px-4 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl flex items-center gap-1.5 disabled:opacity-50"
              >
                {reportBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                <span>{isAr ? 'إصدار التقرير الأسبوعي' : 'Generate Weekly Report'}</span>
              </button>
            </div>
            {weeklyReport && (
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
                {weeklyReport}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'تطور الدرجات عبر الوقت' : 'Score Progression Over Time'}
              </h2>
              {completedExams.length === 0 ? (
                <p className="text-sm text-slate-500 py-8 text-center">
                  {isAr
                    ? 'أكمل امتحانًا واحدًا على الأقل لعرض منحنى التقدم.'
                    : 'Complete at least one exam to plot your score progression.'}
                </p>
              ) : (
                <div className="flex items-end gap-3 h-44 pt-4 border-b border-slate-200 dark:border-slate-800">
                  {completedExams
                    .slice(0, 10)
                    .reverse()
                    .map((ex, i) => (
                      <div key={ex.id} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                        <span className="text-[11px] font-mono text-slate-600 dark:text-slate-400 tabular-nums">
                          {ex.scorePercent}%
                        </span>
                        <div
                          className="w-full max-w-[36px] accent-btn-gradient rounded-t"
                          style={{ height: `${Math.max(8, ex.scorePercent)}%` }}
                        />
                        <span className="text-[10px] text-slate-400 tabular-nums">#{i + 1}</span>
                      </div>
                    ))}
                </div>
              )}
            </div>

            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
              <div>
                <h3 className="text-sm font-bold text-emerald-700 dark:text-emerald-400 mb-2">
                  {isAr ? 'الموضوعات المتقنة (≥ 75%)' : 'Mastered Topics (≥ 75%)'}
                </h3>
                {strongTopics.length === 0 ? (
                  <p className="text-xs text-slate-500">
                    {isAr ? 'لا توجد موضوعات مقاسة بعد.' : 'No topic mastery data yet.'}
                  </p>
                ) : (
                  <ul className="text-xs text-slate-700 dark:text-slate-300 space-y-1">
                    {strongTopics.map((t, i) => (
                      <li key={i}>• {t}</li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                <h3 className="text-sm font-bold text-amber-700 dark:text-amber-400 mb-2">
                  {isAr ? 'موضوعات تحتاج إلى مراجعة (< 75%)' : 'Topics Needing Review (< 75%)'}
                </h3>
                {weakTopics.length === 0 ? (
                  <p className="text-xs text-slate-500">
                    {isAr ? 'ممتاز! لا توجد نقاط ضعف مسجلة حاليًا.' : 'No weak topics flagged.'}
                  </p>
                ) : (
                  <ul className="text-xs text-slate-700 dark:text-slate-300 space-y-1">
                    {weakTopics.map((t, i) => (
                      <li key={i}>• {t}</li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'battles' && (
        <div className="space-y-6">
          {battleError && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
              {battleError}
            </div>
          )}

          {activeBattle ? (
            <div className="glass-surface border border-blue-300/60 dark:border-sky-800/60 rounded-2xl p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                    {activeBattle.title}
                  </h2>
                  <p className="text-xs text-slate-500">
                    {activeBattle.subjectName} · {activeBattle.difficulty} · {activeBattle.questions.length}{' '}
                    {isAr ? 'أسئلة' : 'questions'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleSubmitBattle(activeBattle)}
                    className="px-4 py-2 text-xs font-semibold bg-emerald-600 text-white rounded-xl"
                  >
                    {isAr ? 'تسليم نتيجة التحدي' : 'Submit Battle Score'}
                  </button>
                  <button
                    onClick={() => setPlayingBattleId('')}
                    className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    {isAr ? 'إغلاق' : 'Close'}
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                {activeBattle.questions.map((q, idx) => (
                  <div
                    key={q.id}
                    className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3"
                  >
                    <p className="text-sm font-semibold text-slate-900 dark:text-white">
                      {idx + 1}. {q.question}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {(q.options || ['True', 'False']).map((opt, oi) => (
                        <button
                          key={oi}
                          type="button"
                          onClick={() =>
                            setBattleAnswers((prev) => ({ ...prev, [q.id]: opt }))
                          }
                          className={`p-2.5 rounded-lg border text-xs text-start transition-colors ${
                            battleAnswers[q.id] === opt
                              ? 'bg-blue-600 text-white border-blue-600 font-semibold'
                              : 'border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <form
                onSubmit={handleCreateBattle}
                className="lg:col-span-4 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 h-fit"
              >
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Swords className="w-4 h-4 text-purple-500" />
                  <span>{isAr ? 'إنشاء تحدي معرفة حي' : 'Create Live Study Battle'}</span>
                </h2>
                <input
                  value={battleTitle}
                  onChange={(e) => setBattleTitle(e.target.value)}
                  placeholder={isAr ? 'اسم التحدي (مثال: تحدي الخوارزميات)' : 'Battle title...'}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
                <select
                  value={battleSubjectId}
                  onChange={(e) => setBattleSubjectId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  <option value="">{isAr ? 'اختر المادة...' : 'Select subject...'}</option>
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
                <select
                  value={battleDiff}
                  onChange={(e) => setBattleDiff(e.target.value as 'easy' | 'medium' | 'hard')}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  <option value="easy">{isAr ? 'سهل' : 'Easy'}</option>
                  <option value="medium">{isAr ? 'متوسط' : 'Medium'}</option>
                  <option value="hard">{isAr ? 'صعب' : 'Hard'}</option>
                </select>
                <button
                  disabled={battleBusy || !battleSubjectId}
                  type="submit"
                  className="w-full py-2.5 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2"
                >
                  {battleBusy && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>{isAr ? 'بدء معركة أسئلة AI' : 'Launch AI Battle'}</span>
                </button>
              </form>

              <div className="lg:col-span-8 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  {isAr ? 'غرف التحدي النشطة' : 'Active Study Battles'}
                </h2>
                {studyBattles.length === 0 ? (
                  <p className="text-xs text-slate-500 py-8 text-center">
                    {isAr ? 'لا توجد تحديات حالية. أنشئ أول معركة تحدي!' : 'No active battles yet.'}
                  </p>
                ) : (
                  <div className="space-y-3">
                    {studyBattles.map((b) => {
                      const sortedPlayers = [...b.participants].sort((x, y) => y.score - x.score);
                      return (
                        <div
                          key={b.id}
                          className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div>
                              <p className="text-sm font-bold text-slate-900 dark:text-white">
                                {b.title}
                              </p>
                              <p className="text-xs text-slate-500">
                                {b.subjectName} · {b.ownerName} · {b.status}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              {b.status !== 'finished' && (
                                <button
                                  onClick={() => {
                                    setPlayingBattleId(b.id);
                                    setBattleAnswers({});
                                  }}
                                  className="px-3.5 py-1.5 text-xs font-semibold accent-btn-gradient text-white rounded-lg"
                                >
                                  {isAr ? 'دخول التحدي' : 'Join Battle'}
                                </button>
                              )}
                              {b.ownerId === uid && (
                                <button
                                  onClick={() => deleteDocSafe('studyBattles', b.id)}
                                  className="p-1.5 text-slate-400 hover:text-red-500"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                          {sortedPlayers.length > 0 && (
                            <div className="text-xs space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                              {sortedPlayers.slice(0, 5).map((p, idx) => (
                                <div key={p.uid} className="flex justify-between">
                                  <span>
                                    {idx + 1}. {p.name}
                                  </span>
                                  <span className="font-mono font-bold tabular-nums">{p.score}%</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {tab === 'social' && (
        <div className="space-y-6">
          {reportSent && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 text-xs text-emerald-700 dark:text-emerald-300">
              {isAr ? 'تم إرسال البلاغ لمراجعة الإدارة.' : 'Report submitted for moderation review.'}
            </div>
          )}

          {reportTarget && (
            <form
              onSubmit={handleSubmitReport}
              className="glass-surface border border-red-200 dark:border-red-900 rounded-2xl p-4 space-y-3"
            >
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                {isAr ? 'الإبلاغ عن محتوى مخالف' : 'Report Inappropriate Content'}
              </p>
              <input
                required
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                placeholder={isAr ? 'اذكر سبب البلاغ...' : 'Describe the issue...'}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
              <div className="flex items-center gap-2">
                <button type="submit" className="px-4 py-1.5 text-xs bg-red-600 text-white rounded-lg">
                  {isAr ? 'إرسال البلاغ' : 'Submit Report'}
                </button>
                <button
                  type="button"
                  onClick={() => setReportTarget(null)}
                  className="px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <form
              onSubmit={handleCreateGroup}
              className="lg:col-span-4 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 h-fit"
            >
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'إنشاء مجموعة مذاكرة' : 'Create Study Group'}</span>
              </h2>
              <input
                required
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder={isAr ? 'اسم المجموعة' : 'Group Name'}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
              <input
                required
                value={groupSubj}
                onChange={(e) => setGroupSubj(e.target.value)}
                placeholder={isAr ? 'المادة الدراسية' : 'Subject Name'}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
              <textarea
                rows={2}
                value={groupDesc}
                onChange={(e) => setGroupDesc(e.target.value)}
                placeholder={isAr ? 'وصف قصير...' : 'Short description...'}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
              <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
                <input
                  type="checkbox"
                  checked={isPublic}
                  onChange={(e) => setIsPublic(e.target.checked)}
                />
                <span>{isAr ? 'مجموعة عامة متاحة للطلاب' : 'Public study group'}</span>
              </label>
              <button
                type="submit"
                className="w-full py-2 accent-btn-gradient text-white text-sm font-semibold rounded-xl"
              >
                {isAr ? 'إنشاء المجموعة' : 'Create Group'}
              </button>
            </form>

            <div className="lg:col-span-8 space-y-6">
              <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  {isAr ? 'مجموعات المذاكرة المتاحة' : 'Active Study Groups'}
                </h2>
                {studyGroups.length === 0 ? (
                  <p className="text-xs text-slate-500">
                    {isAr ? 'لا توجد مجموعات بعد.' : 'No study groups created yet.'}
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {studyGroups.map((g) => (
                      <div
                        key={g.id}
                        onClick={() => setActiveGroupId(g.id)}
                        className={`p-4 rounded-xl border cursor-pointer space-y-2 transition-colors ${
                          activeGroupId === g.id
                            ? 'border-blue-500 bg-blue-50/40 dark:bg-sky-950/20'
                            : 'border-slate-200 dark:border-slate-800'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-sm font-bold text-slate-900 dark:text-white">{g.name}</p>
                            <p className="text-xs text-slate-500 tabular-nums">
                              {g.subjectName} · {g.memberCount} {isAr ? 'عضو' : 'members'}
                            </p>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setReportTarget({ type: 'group', id: g.id });
                            }}
                            className="p-1 text-slate-400 hover:text-red-500"
                            title={isAr ? 'إبلاغ' : 'Report'}
                          >
                            <Flag className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleJoinGroup(g.id);
                            }}
                            className="px-3 py-1 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg"
                          >
                            {isAr ? 'انضمام' : 'Join'}
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleLogChallengeScore(g.id, `${g.subjectName} Challenge`);
                            }}
                            className="px-3 py-1 text-xs font-medium bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg"
                          >
                            {isAr ? 'تسجيل نتيجة' : 'Log Score'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Group Discussions */}
              {activeGroup && (
                <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-blue-500" />
                    <span>
                      {isAr ? `مناقشة المجموعة: ${activeGroup.name}` : `Group Discussion: ${activeGroup.name}`}
                    </span>
                  </h3>
                  <div className="max-h-56 overflow-y-auto space-y-2 pe-1">
                    {discussions.length === 0 ? (
                      <p className="text-xs text-slate-500 py-4">
                        {isAr ? 'لا توجد رسائل بعد. ابدأ النقاش العلمي مع زملائك!' : 'No messages yet. Start the discussion!'}
                      </p>
                    ) : (
                      discussions.map((msg) => (
                        <div
                          key={msg.id}
                          className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs flex items-start justify-between gap-2"
                        >
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white">
                              {msg.ownerName}:{' '}
                            </span>
                            <span className="text-slate-700 dark:text-slate-300">{msg.text}</span>
                          </div>
                          {(msg.ownerId === uid || activeGroup.ownerId === uid) && (
                            <button
                              onClick={() => deleteDocSafe('groupDiscussions', msg.id)}
                              className="text-slate-400 hover:text-red-500 shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                  <form onSubmit={handleSendDiscussion} className="flex items-center gap-2 pt-1">
                    <input
                      value={chatMsg}
                      onChange={(e) => setChatMsg(e.target.value)}
                      placeholder={isAr ? 'اكتب سؤالًا أو فكرة للمجموعة...' : 'Share a note or question with the group...'}
                      className="flex-1 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                    <button
                      type="submit"
                      disabled={!chatMsg.trim()}
                      className="px-3.5 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl flex items-center gap-1 disabled:opacity-40"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isAr ? 'إرسال' : 'Send'}</span>
                    </button>
                  </form>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    {isAr ? 'الملخصات المشاركة بموافقة أصحابها' : 'Consented Shared Resources'}
                  </h3>
                  {sharedResources.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      {isAr ? 'لا توجد مشاركات بعد.' : 'No shared resources yet.'}
                    </p>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto">
                      {sharedResources.map((r) => (
                        <div
                          key={r.id}
                          className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-slate-900 dark:text-white">{r.title}</span>
                            <button
                              onClick={() => setReportTarget({ type: 'resource', id: r.id })}
                              className="text-slate-400 hover:text-red-500"
                            >
                              <Flag className="w-3 h-3" />
                            </button>
                          </div>
                          <p className="text-slate-500">
                            {r.ownerName} · {r.subjectName}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Trophy className="w-4 h-4 text-amber-500" />
                    <span>{isAr ? 'ترتيب التحديات التعليمية' : 'Challenge Leaderboard'}</span>
                  </h3>
                  {sortedLeaderboard.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      {isAr ? 'لا توجد نتائج تحديات بعد.' : 'No challenge scores recorded yet.'}
                    </p>
                  ) : (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                      {sortedLeaderboard.map((entry, idx) => (
                        <div key={entry.id} className="py-2 flex items-center justify-between">
                          <span>
                            {idx + 1}. {entry.studentName} · {entry.challengeTitle}
                          </span>
                          <span className="font-mono font-semibold tabular-nums">{entry.score}%</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
