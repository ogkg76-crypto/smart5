import React, { useState } from 'react';
import { doc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Flashcard, Language, Lecture, Subject, SubscriptionPlan, UserProfile } from '../types';
import { generateFlashcards } from '../services/api';
import {
  awardStudyXp,
  deleteDocSafe,
  getEffectiveLimit,
  makeId,
  trackAiUsageAndNotify,
} from '../services/firestoreHelpers';
import {
  Layers,
  Plus,
  Trash2,
  RotateCw,
  Loader2,
  AlertCircle,
  Edit3,
  Save,
  ImagePlus,
  BellRing,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  lectures: Lecture[];
  flashcards: Flashcard[];
}

async function compressCardImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxW = 480;
        const scale = Math.min(1, maxW / img.width);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject(new Error('Canvas unavailable'));
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.72);
        if (dataUrl.length > 55000) {
          resolve(canvas.toDataURL('image/jpeg', 0.5).slice(0, 58000));
        } else {
          resolve(dataUrl);
        }
      };
      img.onerror = () => reject(new Error('Invalid image'));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Failed to read image'));
    reader.readAsDataURL(file);
  });
}

export const FlashcardsView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  subjects,
  lectures,
  flashcards,
}) => {
  const isAr = lang === 'ar';
  const [filterSubjectId, setFilterSubjectId] = useState('all');
  const [masteryFilter, setMasteryFilter] = useState<'all' | 'due' | 'new' | 'learning' | 'mastered'>('all');
  const [selectedLectureId, setSelectedLectureId] = useState(lectures[0]?.id || '');
  const [studyMode, setStudyMode] = useState(false);
  const [flipped, setFlipped] = useState(false);
  const [reviewIdx, setReviewIdx] = useState(0);

  // Manual create
  const [manualSubjectId, setManualSubjectId] = useState(subjects[0]?.id || '');
  const [front, setFront] = useState('');
  const [back, setBack] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  // Inline Edit Card
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFront, setEditFront] = useState('');
  const [editBack, setEditBack] = useState('');
  const [editImage, setEditImage] = useState('');

  const now = Date.now();

  const filteredCards = flashcards.filter((c) => {
    if (filterSubjectId !== 'all' && c.subjectId !== filterSubjectId) return false;
    if (masteryFilter === 'due') return c.nextReviewAt <= now;
    if (masteryFilter === 'new') return c.repetitions === 0;
    if (masteryFilter === 'learning') return c.repetitions >= 1 && c.intervalDays < 14;
    if (masteryFilter === 'mastered') return c.intervalDays >= 14;
    return true;
  });

  const dueCards = filteredCards.filter((c) => c.nextReviewAt <= now);
  const studyQueue = dueCards.length > 0 ? dueCards : filteredCards;

  const handleAutoGenerate = async () => {
    const lec = lectures.find((l) => l.id === selectedLectureId);
    if (!lec) return;
    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم استنفاد رصيد الذكاء الاصطناعي لباقتك.' : 'AI request limit reached.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const res = await generateFlashcards({
        lectureTitle: lec.title,
        fullText: lec.fullTextPreview || lec.extractedPages.map((p) => p.content).join('\n'),
        count: 10,
        lang: profile?.explanationLang || lang,
      });

      for (const card of res.cards || []) {
        const id = makeId('card');
        await setDoc(doc(db, 'flashcards', id), {
          ownerId: uid,
          subjectId: lec.subjectId,
          lectureId: lec.id,
          front: card.front.slice(0, 600),
          back: card.back.slice(0, 1500),
          imageUrl: '',
          easeFactor: 2.5,
          intervalDays: 0,
          repetitions: 0,
          nextReviewAt: Date.now(),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      await trackAiUsageAndNotify({ uid, xpDelta: 20 });
      await awardStudyXp(uid, profile, 20);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate flashcards.');
    } finally {
      setBusy(false);
    }
  };

  const handleManualCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const subjId = manualSubjectId || subjects[0]?.id;
    if (!subjId || !front.trim() || !back.trim()) return;
    const id = makeId('card');
    try {
      await setDoc(doc(db, 'flashcards', id), {
        ownerId: uid,
        subjectId: subjId,
        front: front.trim().slice(0, 600),
        back: back.trim().slice(0, 1500),
        imageUrl: imageUrl.trim().slice(0, 58000),
        easeFactor: 2.5,
        intervalDays: 0,
        repetitions: 0,
        nextReviewAt: Date.now(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setFront('');
      setBack('');
      setImageUrl('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `flashcards/${id}`);
    }
  };

  const handleSaveCardEdit = async (card: Flashcard) => {
    if (!editFront.trim() || !editBack.trim()) return;
    try {
      await updateDoc(doc(db, 'flashcards', card.id), {
        front: editFront.trim().slice(0, 600),
        back: editBack.trim().slice(0, 1500),
        imageUrl: editImage.trim().slice(0, 58000),
        updatedAt: serverTimestamp(),
      });
      setEditingId(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `flashcards/${card.id}`);
    }
  };

  const handleImagePick = async (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (url: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressCardImage(file);
      setter(compressed);
    } catch {
      setError(isAr ? 'تعذر ضغط الصورة المختارة.' : 'Could not process selected image.');
    } finally {
      e.target.value = '';
    }
  };

  const handleSm2Review = async (card: Flashcard, quality: 1 | 3 | 4 | 5) => {
    let reps = card.repetitions;
    let interval = card.intervalDays;
    let ef = card.easeFactor;

    if (quality < 3) {
      reps = 0;
      interval = 1;
    } else {
      if (reps === 0) interval = 1;
      else if (reps === 1) interval = 6;
      else interval = Math.round(interval * ef);
      reps += 1;
    }

    ef = Math.max(
      1.3,
      Number((ef + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))).toFixed(2))
    );
    const nextReviewAt = Date.now() + interval * 24 * 60 * 60 * 1000;

    try {
      await updateDoc(doc(db, 'flashcards', card.id), {
        easeFactor: ef,
        intervalDays: interval,
        repetitions: reps,
        nextReviewAt,
        updatedAt: serverTimestamp(),
      });
      await awardStudyXp(uid, profile, 5);
      setFlipped(false);
      if (reviewIdx >= studyQueue.length - 1) {
        setStudyMode(false);
        setReviewIdx(0);
      } else {
        setReviewIdx((i) => i + 1);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `flashcards/${card.id}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'البطاقات التعليمية والمراجعة المتباعدة' : 'Spaced Repetition Flashcards'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {isAr
              ? `${dueCards.length} بطاقة مستحقة للمراجعة اليوم من إجمالي ${filteredCards.length}`
              : `${dueCards.length} cards due today out of ${filteredCards.length}`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={selectedLectureId}
            onChange={(e) => setSelectedLectureId(e.target.value)}
            className="px-3 py-2 text-sm glass-surface border border-slate-200 dark:border-slate-700 rounded-lg"
          >
            <option value="">{isAr ? 'اختر محاضرة...' : 'Select lecture...'}</option>
            {lectures.map((l) => (
              <option key={l.id} value={l.id}>
                {l.title}
              </option>
            ))}
          </select>

          <button
            disabled={!selectedLectureId || busy}
            onClick={handleAutoGenerate}
            className="px-4 py-2 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Layers className="w-4 h-4" />}
            <span>{isAr ? 'توليد بطاقات AI' : 'Generate AI Cards'}</span>
          </button>

          {studyQueue.length > 0 && (
            <button
              onClick={() => {
                setStudyMode((v) => !v);
                setReviewIdx(0);
                setFlipped(false);
              }}
              className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-sm font-semibold rounded-xl whitespace-nowrap shrink-0"
            >
              {studyMode ? (isAr ? 'عرض كل البطاقات' : 'Exit Study') : isAr ? 'بدء المراجعة' : 'Start Review'}
            </button>
          )}
        </div>
      </div>

      {dueCards.length > 0 && !studyMode && (
        <div className="p-4 rounded-2xl bg-blue-50/80 dark:bg-sky-950/30 border border-blue-200 dark:border-sky-800/70 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-xs sm:text-sm text-blue-900 dark:text-sky-200">
            <BellRing className="w-4 h-4 shrink-0" />
            <span>
              {isAr
                ? `تذكير المراجعة المتباعدة: لديك ${dueCards.length} بطاقة جاهزة للمراجعة الآن لتثبيت الحفظ.`
                : `Spaced repetition reminder: ${dueCards.length} cards are ready for review right now.`}
            </span>
          </div>
          <button
            onClick={() => {
              setStudyMode(true);
              setReviewIdx(0);
              setFlipped(false);
            }}
            className="px-3.5 py-1.5 text-xs font-semibold accent-btn-gradient text-white rounded-lg"
          >
            {isAr ? 'ابدأ المراجعة السريعة' : 'Review Due Cards'}
          </button>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {studyMode && studyQueue[reviewIdx] ? (
        <div className="max-w-2xl mx-auto glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-8 space-y-6 text-center">
          <p className="text-xs text-slate-500 tabular-nums">
            {reviewIdx + 1} / {studyQueue.length}
          </p>
          <div
            onClick={() => setFlipped((f) => !f)}
            className="min-h-[220px] flex flex-col items-center justify-center p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 cursor-pointer space-y-4"
          >
            <p className="text-xs font-semibold text-blue-600 dark:text-sky-400">
              {flipped ? (isAr ? 'الإجابة / التعريف' : 'Answer') : isAr ? 'السؤال / المصطلح' : 'Prompt'}
            </p>
            {studyQueue[reviewIdx].imageUrl && (
              <img
                src={studyQueue[reviewIdx].imageUrl}
                alt="Card diagram"
                className="max-h-40 rounded-lg border border-slate-200 dark:border-slate-800 object-contain"
              />
            )}
            <p className="text-lg font-semibold text-slate-900 dark:text-white leading-relaxed">
              {flipped ? studyQueue[reviewIdx].back : studyQueue[reviewIdx].front}
            </p>
            <span className="text-xs text-slate-400 flex items-center gap-1 pt-2">
              <RotateCw className="w-3 h-3" />
              {isAr ? 'اضغط لقلب البطاقة' : 'Click to flip'}
            </span>
          </div>

          {flipped && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <button
                onClick={() => handleSm2Review(studyQueue[reviewIdx], 1)}
                className="py-2 px-3 rounded-xl border border-red-300 text-red-700 dark:text-red-400 text-xs font-semibold hover:bg-red-50 dark:hover:bg-red-950/30"
              >
                {isAr ? 'نسيتها (اليوم)' : 'Again (1d)'}
              </button>
              <button
                onClick={() => handleSm2Review(studyQueue[reviewIdx], 3)}
                className="py-2 px-3 rounded-xl border border-amber-300 text-amber-700 dark:text-amber-400 text-xs font-semibold hover:bg-amber-50 dark:hover:bg-amber-950/30"
              >
                {isAr ? 'صعبة' : 'Hard'}
              </button>
              <button
                onClick={() => handleSm2Review(studyQueue[reviewIdx], 4)}
                className="py-2 px-3 rounded-xl border border-blue-300 text-blue-700 dark:text-sky-400 text-xs font-semibold hover:bg-blue-50 dark:hover:bg-sky-950/30"
              >
                {isAr ? 'جيدة' : 'Good'}
              </button>
              <button
                onClick={() => handleSm2Review(studyQueue[reviewIdx], 5)}
                className="py-2 px-3 rounded-xl border border-emerald-300 text-emerald-700 dark:text-emerald-400 text-xs font-semibold hover:bg-emerald-50 dark:hover:bg-emerald-950/30"
              >
                {isAr ? 'سهلة جدًا' : 'Easy'}
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleManualCreate}
            className="lg:col-span-4 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 h-fit"
          >
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة بطاقة يدويًا' : 'Add Card Manually'}</span>
            </h2>
            <select
              value={manualSubjectId || subjects[0]?.id || ''}
              onChange={(e) => setManualSubjectId(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="">{isAr ? 'اختر مادة...' : 'Select subject...'}</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
            <input
              required
              value={front}
              onChange={(e) => setFront(e.target.value)}
              placeholder={isAr ? 'الأمام: سؤال أو مصطلح...' : 'Front: question or term...'}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <textarea
              required
              rows={3}
              value={back}
              onChange={(e) => setBack(e.target.value)}
              placeholder={isAr ? 'الخلف: الإجابة أو التعريف...' : 'Back: answer or definition...'}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <div className="space-y-2">
              <label className="w-full py-2 px-3 border border-dashed border-slate-300 dark:border-slate-700 rounded-lg flex items-center justify-center gap-2 text-xs cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50">
                <ImagePlus className="w-4 h-4 text-blue-600 dark:text-sky-400" />
                <span>{isAr ? 'إرفاق صورة / رسم توضيحي (اختياري)' : 'Attach Diagram Image (Optional)'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImagePick(e, setImageUrl)}
                  className="hidden"
                />
              </label>
              {imageUrl && (
                <div className="flex items-center justify-between gap-2 text-xs text-emerald-600">
                  <span>{isAr ? 'تم إرفاق الصورة' : 'Image attached'}</span>
                  <button type="button" onClick={() => setImageUrl('')} className="text-red-500">
                    {isAr ? 'إزالة' : 'Remove'}
                  </button>
                </div>
              )}
            </div>
            <button
              type="submit"
              disabled={subjects.length === 0}
              className="w-full py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-sm font-semibold rounded-xl disabled:opacity-50"
            >
              {isAr ? 'حفظ البطاقة' : 'Save Card'}
            </button>
          </form>

          <div className="lg:col-span-8 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <select
                value={filterSubjectId}
                onChange={(e) => setFilterSubjectId(e.target.value)}
                className="px-3 py-1.5 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="all">{isAr ? 'كل المواد' : 'All Subjects'}</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>

              <select
                value={masteryFilter}
                onChange={(e) => setMasteryFilter(e.target.value as typeof masteryFilter)}
                className="px-3 py-1.5 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="all">{isAr ? 'كل الحالات' : 'All Mastery'}</option>
                <option value="due">{isAr ? 'مستحقة للمراجعة' : 'Due Now'}</option>
                <option value="new">{isAr ? 'جديدة' : 'New'}</option>
                <option value="learning">{isAr ? 'قيد الحفظ' : 'Learning'}</option>
                <option value="mastered">{isAr ? 'متقنة (≥14 يوم)' : 'Mastered (≥14d)'}</option>
              </select>
            </div>

            {filteredCards.length === 0 ? (
              <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center text-sm text-slate-500">
                {isAr ? 'لا توجد بطاقات مطابقة لهذا الفلتر.' : 'No flashcards match this filter.'}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {filteredCards.map((c) => {
                  const isEditing = editingId === c.id;
                  return (
                    <div
                      key={c.id}
                      className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3 flex flex-col justify-between"
                    >
                      {isEditing ? (
                        <div className="space-y-2.5">
                          <input
                            value={editFront}
                            onChange={(e) => setEditFront(e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                          />
                          <textarea
                            rows={2}
                            value={editBack}
                            onChange={(e) => setEditBack(e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                          />
                          <label className="inline-flex items-center gap-1.5 text-[11px] text-blue-600 dark:text-sky-400 cursor-pointer">
                            <ImagePlus className="w-3.5 h-3.5" />
                            <span>{isAr ? 'تحديث الصورة' : 'Update Image'}</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleImagePick(e, setEditImage)}
                              className="hidden"
                            />
                          </label>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleSaveCardEdit(c)}
                              className="px-3 py-1 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center gap-1"
                            >
                              <Save className="w-3 h-3" />
                              <span>{isAr ? 'حفظ' : 'Save'}</span>
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="px-2.5 py-1 text-xs border border-slate-200 dark:border-slate-700 rounded-lg"
                            >
                              {isAr ? 'إلغاء' : 'Cancel'}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="space-y-2">
                            {c.imageUrl && (
                              <img
                                src={c.imageUrl}
                                alt={c.front}
                                className="w-full max-h-32 object-cover rounded-lg border border-slate-200 dark:border-slate-800"
                              />
                            )}
                            <p className="text-sm font-bold text-slate-900 dark:text-white">{c.front}</p>
                            <p className="text-xs text-slate-600 dark:text-slate-400">{c.back}</p>
                          </div>
                          <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-400 tabular-nums">
                            <span>
                              {isAr ? `الفاصل: ${c.intervalDays} يوم` : `Interval: ${c.intervalDays}d`}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => {
                                  setEditingId(c.id);
                                  setEditFront(c.front);
                                  setEditBack(c.back);
                                  setEditImage(c.imageUrl || '');
                                }}
                                className="text-slate-400 hover:text-blue-500"
                                aria-label="Edit card"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => deleteDocSafe('flashcards', c.id)}
                                className="text-slate-400 hover:text-red-500"
                                aria-label="Delete card"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
