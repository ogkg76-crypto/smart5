import React, { useState } from 'react';
import { doc, setDoc, updateDoc, serverTimestamp, increment } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Language,
  Lecture,
  StudyPlanTask,
  Subject,
  SubscriptionPlan,
  UserProfile,
} from '../types';
import { generateStudyPlan } from '../services/api';
import {
  awardStudyXp,
  deleteDocSafe,
  getEffectiveLimit,
  makeId,
  trackAiUsageAndNotify,
} from '../services/firestoreHelpers';
import {
  Calendar,
  CheckCircle2,
  Clock,
  RefreshCw,
  Trash2,
  Loader2,
  AlertCircle,
  Plus,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  lectures: Lecture[];
  tasks: StudyPlanTask[];
}

export const PlannerView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  subjects,
  lectures,
  tasks,
}) => {
  const isAr = lang === 'ar';
  const [dailyHours, setDailyHours] = useState(3);
  const [viewMode, setViewMode] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  // Manual Task Form
  const [manualTitle, setManualTitle] = useState('');
  const [manualSubjectId, setManualSubjectId] = useState(subjects[0]?.id || '');
  const [manualDate, setManualDate] = useState(new Date().toISOString().slice(0, 10));
  const [manualMinutes, setManualMinutes] = useState(45);
  const [manualType, setManualType] = useState<'lecture' | 'review' | 'practice'>('review');
  const [manualPriority, setManualPriority] = useState<'low' | 'medium' | 'high'>('medium');

  const todayStr = new Date().toISOString().slice(0, 10);
  const weekLimitStr = new Date(Date.now() + 7 * 86_400_000).toISOString().slice(0, 10);
  const monthLimitStr = new Date(Date.now() + 30 * 86_400_000).toISOString().slice(0, 10);

  const overdueTasks = tasks.filter(
    (t) => t.status !== 'completed' && t.scheduledDate < todayStr
  );
  const lowUnderstandingSubjects = subjects.filter((s) => s.understandingLevel === 'low');
  const examSubjects = subjects
    .filter((s) => s.examDate && s.examDate >= todayStr)
    .sort((a, b) => (a.examDate || '').localeCompare(b.examDate || ''));

  const visibleTasks = tasks
    .filter((t) => {
      if (viewMode === 'daily') return t.scheduledDate === todayStr || t.scheduledDate < todayStr;
      if (viewMode === 'weekly') return t.scheduledDate <= weekLimitStr;
      return t.scheduledDate <= monthLimitStr || true;
    })
    .sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate));

  const updateSubjectSetting = async (
    subj: Subject,
    field: 'understandingLevel' | 'priority' | 'examDate',
    value: string
  ) => {
    try {
      await updateDoc(doc(db, 'subjects', subj.id), {
        [field]: value,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `subjects/${subj.id}`);
    }
  };

  const handleGeneratePlan = async () => {
    if (subjects.length === 0) {
      setError(
        isAr
          ? 'أضف مادة دراسية واحدة على الأقل من مكتبتي أولًا.'
          : 'Add at least one subject in My Library first.'
      );
      return;
    }

    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم استنفاد رصيد الذكاء الاصطناعي.' : 'AI quota reached.');
      return;
    }

    setBusy(true);
    setError('');
    try {
      const payloadSubjects = subjects.map((s) => ({
        subjectId: s.id,
        subjectName: s.name,
        lectureCount: Math.max(1, lectures.filter((l) => l.subjectId === s.id).length),
        examDate: s.examDate || '',
        understandingLevel: s.understandingLevel,
        priority: s.priority,
      }));

      const res = await generateStudyPlan({
        subjects: payloadSubjects,
        dailyHours,
        startDate: todayStr,
        lang: profile?.explanationLang || lang,
      });

      for (const task of res.tasks || []) {
        const id = makeId('task');
        await setDoc(doc(db, 'studyPlans', id), {
          ownerId: uid,
          subjectId: task.subjectId || '',
          subjectName: task.subjectName.slice(0, 120),
          title: task.title.slice(0, 200),
          scheduledDate: task.scheduledDate.slice(0, 32),
          durationMinutes: Math.min(Math.max(Number(task.durationMinutes) || 45, 10), 480),
          taskType: ['lecture', 'review', 'practice'].includes(task.taskType)
            ? task.taskType
            : 'lecture',
          status: 'pending',
          priority: ['low', 'medium', 'high'].includes(task.priority) ? task.priority : 'medium',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      await trackAiUsageAndNotify({
        uid,
        enableNotif: profile?.notifStudyReminders !== false,
        notifTitle: isAr ? 'تم إنشاء خطة المذاكرة' : 'Study Plan Ready',
        notifBody: isAr
          ? `تمت جدولة ${(res.tasks || []).length} مهمة مذاكرة ذكية.`
          : `Scheduled ${(res.tasks || []).length} adaptive study tasks.`,
        notifCategory: 'study',
        xpDelta: 20,
      });
      await awardStudyXp(uid, profile, 20);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to build study plan.');
    } finally {
      setBusy(false);
    }
  };

  const handleAddManualTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualTitle.trim()) return;
    const subj = subjects.find((s) => s.id === manualSubjectId) || subjects[0];
    const id = makeId('task');
    try {
      await setDoc(doc(db, 'studyPlans', id), {
        ownerId: uid,
        subjectId: subj?.id || '',
        subjectName: (subj?.name || (isAr ? 'مذاكرة عامة' : 'General Study')).slice(0, 120),
        title: manualTitle.trim().slice(0, 200),
        scheduledDate: manualDate || todayStr,
        durationMinutes: Math.min(Math.max(Number(manualMinutes) || 45, 5), 600),
        taskType: manualType,
        status: 'pending',
        priority: manualPriority,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setManualTitle('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `studyPlans/${id}`);
    }
  };

  const handleToggleComplete = async (task: StudyPlanTask) => {
    const nextStatus = task.status === 'completed' ? 'pending' : 'completed';
    try {
      await updateDoc(doc(db, 'studyPlans', task.id), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
      if (nextStatus === 'completed') {
        await updateDoc(doc(db, 'users', uid), {
          studyHoursLogged: increment(Number((task.durationMinutes / 60).toFixed(2))),
          updatedAt: serverTimestamp(),
        });
        await awardStudyXp(uid, profile, 15);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `studyPlans/${task.id}`);
    }
  };

  const handleRescheduleOverdue = async () => {
    for (let i = 0; i < overdueTasks.length; i++) {
      const targetDate = new Date();
      targetDate.setDate(targetDate.getDate() + (i % 3));
      const dateStr = targetDate.toISOString().slice(0, 10);
      await updateDoc(doc(db, 'studyPlans', overdueTasks[i].id), {
        scheduledDate: dateStr,
        status: 'pending',
        updatedAt: serverTimestamp(),
      });
    }
  };

  const completedCount = tasks.filter((t) => t.status === 'completed').length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'خطة المذاكرة الذكية والعد التنازلي' : 'Adaptive Study Planner & Countdowns'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {isAr
              ? `تم إنجاز ${completedCount} من ${tasks.length} مهمة · الوقت المتاح يوميًا: ${dailyHours} ساعات`
              : `${completedCount} of ${tasks.length} tasks completed · Daily target: ${dailyHours} hrs`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl">
            {(
              [
                { id: 'daily', ar: 'يومي', en: 'Daily' },
                { id: 'weekly', ar: 'أسبوعي', en: 'Weekly' },
                { id: 'monthly', ar: 'شهري', en: 'Monthly' },
              ] as const
            ).map((m) => (
              <button
                key={m.id}
                onClick={() => setViewMode(m.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg ${
                  viewMode === m.id
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {isAr ? m.ar : m.en}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 glass-surface border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5">
            <span className="text-xs text-slate-500">{isAr ? 'ساعات يوميًا:' : 'Daily hrs:'}</span>
            <input
              type="number"
              min={1}
              max={14}
              value={dailyHours}
              onChange={(e) => setDailyHours(Number(e.target.value))}
              className="w-12 text-sm font-mono bg-transparent text-slate-900 dark:text-white focus:outline-none tabular-nums"
            />
          </div>

          <button
            disabled={busy || subjects.length === 0}
            onClick={handleGeneratePlan}
            className="px-4 py-2 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Calendar className="w-4 h-4" />}
            <span>{isAr ? 'إنشاء جدول AI' : 'Build AI Schedule'}</span>
          </button>
        </div>
      </div>

      {/* Exam Countdown Cards */}
      {examSubjects.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {examSubjects.map((s) => {
            const days = Math.max(
              0,
              Math.ceil((new Date(s.examDate!).getTime() - Date.now()) / 86_400_000)
            );
            return (
              <div
                key={s.id}
                className="glass-surface border border-blue-200/70 dark:border-sky-800/70 rounded-2xl p-4 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{s.name}</p>
                  <p className="text-[11px] text-slate-500 tabular-nums mt-0.5">{s.examDate}</p>
                </div>
                <div className="text-end shrink-0">
                  <p className="text-xl font-bold text-blue-600 dark:text-sky-400 tabular-nums">
                    {days}d
                  </p>
                  <p className="text-[10px] text-slate-500">{isAr ? 'متبقي' : 'left'}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {overdueTasks.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-amber-900 dark:text-amber-200">
            {isAr
              ? `لديك ${overdueTasks.length} مهام متأخرة عن موعدها.`
              : `You have ${overdueTasks.length} overdue study tasks.`}
          </p>
          <button
            onClick={handleRescheduleOverdue}
            className="px-3.5 py-1.5 text-xs font-semibold bg-amber-600 text-white rounded-xl flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{isAr ? 'إعادة تنظيم المتأخرة تلقائيًا' : 'Auto-Reschedule Overdue'}</span>
          </button>
        </div>
      )}

      {lowUnderstandingSubjects.length > 0 && (
        <div className="p-4 rounded-2xl bg-blue-50 dark:bg-sky-950/30 border border-blue-200 dark:border-sky-800 text-xs text-blue-900 dark:text-sky-200">
          {isAr
            ? `توصية مراجعة إضافية للمواد ذات الفهم المنخفض: ${lowUnderstandingSubjects.map((s) => s.name).join('، ')}`
            : `Extra review recommended for low-understanding subjects: ${lowUnderstandingSubjects.map((s) => s.name).join(', ')}`}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-6">
          {/* Manual Task Form */}
          <form
            onSubmit={handleAddManualTask}
            className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3"
          >
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة مهمة مذاكرة يدويًا' : 'Add Custom Study Task'}</span>
            </h2>
            <input
              required
              value={manualTitle}
              onChange={(e) => setManualTitle(e.target.value)}
              placeholder={isAr ? 'مثال: مراجعة الفصل الثالث...' : 'e.g., Review Chapter 3...'}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
            <div className="grid grid-cols-2 gap-2.5">
              <select
                value={manualSubjectId}
                onChange={(e) => setManualSubjectId(e.target.value)}
                className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="">{isAr ? 'مذاكرة عامة' : 'General'}</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
              <input
                type="date"
                value={manualDate}
                onChange={(e) => setManualDate(e.target.value)}
                className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
              <input
                type="number"
                min={5}
                max={480}
                value={manualMinutes}
                onChange={(e) => setManualMinutes(Number(e.target.value))}
                className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
              />
              <select
                value={manualType}
                onChange={(e) => setManualType(e.target.value as typeof manualType)}
                className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="lecture">{isAr ? 'محاضرة' : 'Lecture'}</option>
                <option value="review">{isAr ? 'مراجعة' : 'Review'}</option>
                <option value="practice">{isAr ? 'تدريب / حل' : 'Practice'}</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={manualPriority}
                onChange={(e) => setManualPriority(e.target.value as typeof manualPriority)}
                className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="high">{isAr ? 'أولوية عالية' : 'High Priority'}</option>
                <option value="medium">{isAr ? 'أولوية متوسطة' : 'Medium'}</option>
                <option value="low">{isAr ? 'أولوية منخفضة' : 'Low'}</option>
              </select>
              <button
                type="submit"
                className="flex-1 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold rounded-lg"
              >
                {isAr ? 'إضافة للجدول' : 'Add Task'}
              </button>
            </div>
          </form>

          {/* Subject Weights */}
          <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isAr ? 'أولويات ومواعيد امتحانات المواد' : 'Subject Priorities & Exam Dates'}
            </h2>
            {subjects.length === 0 ? (
              <p className="text-xs text-slate-500">
                {isAr ? 'أضف موادك الدراسية في مكتبتي أولًا.' : 'Add subjects in My Library first.'}
              </p>
            ) : (
              <div className="space-y-3">
                {subjects.map((s) => (
                  <div
                    key={s.id}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2.5"
                  >
                    <p className="text-sm font-semibold text-slate-900 dark:text-white">{s.name}</p>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-[11px] text-slate-500 block mb-1">
                          {isAr ? 'مستوى الفهم' : 'Understanding'}
                        </label>
                        <select
                          value={s.understandingLevel}
                          onChange={(e) => updateSubjectSetting(s, 'understandingLevel', e.target.value)}
                          className="w-full px-2 py-1 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded"
                        >
                          <option value="low">{isAr ? 'ضعيف' : 'Low'}</option>
                          <option value="medium">{isAr ? 'متوسط' : 'Medium'}</option>
                          <option value="high">{isAr ? 'ممتاز' : 'High'}</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] text-slate-500 block mb-1">
                          {isAr ? 'الأولوية' : 'Priority'}
                        </label>
                        <select
                          value={s.priority}
                          onChange={(e) => updateSubjectSetting(s, 'priority', e.target.value)}
                          className="w-full px-2 py-1 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded"
                        >
                          <option value="high">{isAr ? 'عالية' : 'High'}</option>
                          <option value="medium">{isAr ? 'متوسطة' : 'Medium'}</option>
                          <option value="low">{isAr ? 'منخفضة' : 'Low'}</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] text-slate-500 block mb-1">
                          {isAr ? 'الامتحان' : 'Exam Date'}
                        </label>
                        <input
                          type="date"
                          value={s.examDate || ''}
                          onChange={(e) => updateSubjectSetting(s, 'examDate', e.target.value)}
                          className="w-full px-1.5 py-1 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Scheduled Tasks */}
        <div className="lg:col-span-7 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {viewMode === 'daily'
                ? isAr
                  ? 'مهام اليوم'
                  : 'Daily Tasks'
                : viewMode === 'weekly'
                  ? isAr
                    ? 'خطة الأسبوع'
                    : 'Weekly Schedule'
                  : isAr
                    ? 'الخطة الشهرية الكاملة'
                    : 'Monthly Schedule'}
            </h2>
            <span className="text-xs text-slate-500 tabular-nums">
              {visibleTasks.length} {isAr ? 'مهمة' : 'tasks'}
            </span>
          </div>

          {visibleTasks.length === 0 ? (
            <p className="text-sm text-slate-500 py-10 text-center">
              {isAr
                ? 'اضغط "إنشاء جدول AI" أو أضف مهمة يدويًا لبدء التنظيم.'
                : 'Click "Build AI Schedule" or add a custom task to begin.'}
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[600px] overflow-y-auto">
              {visibleTasks.map((task) => {
                const done = task.status === 'completed';
                return (
                  <div key={task.id} className="py-3 flex items-center justify-between gap-3">
                    <button
                      onClick={() => handleToggleComplete(task)}
                      className="flex items-start gap-3 text-start flex-1 min-w-0"
                    >
                      <CheckCircle2
                        className={`w-5 h-5 shrink-0 mt-0.5 ${
                          done ? 'text-emerald-600' : 'text-slate-300 dark:text-slate-600'
                        }`}
                      />
                      <div className="min-w-0">
                        <p
                          className={`text-sm font-medium truncate ${
                            done
                              ? 'line-through text-slate-400'
                              : 'text-slate-900 dark:text-slate-100'
                          }`}
                        >
                          {task.title}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5 tabular-nums flex flex-wrap items-center gap-2">
                          <span>{task.subjectName}</span>
                          <span>·</span>
                          <span>{task.scheduledDate}</span>
                          <span>·</span>
                          <span className="inline-flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {task.durationMinutes} {isAr ? 'د' : 'min'}
                          </span>
                          <span>·</span>
                          <span>{task.taskType}</span>
                        </p>
                      </div>
                    </button>
                    <button
                      onClick={() => deleteDocSafe('studyPlans', task.id)}
                      className="p-1.5 text-slate-400 hover:text-red-500 shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
