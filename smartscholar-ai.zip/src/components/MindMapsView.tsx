import React, { useEffect, useRef, useState } from 'react';
import { doc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Language,
  Lecture,
  MindMapDoc,
  MindMapNode,
  SubscriptionPlan,
  UserProfile,
} from '../types';
import { generateMindMap } from '../services/api';
import {
  awardStudyXp,
  deleteDocSafe,
  getEffectiveLimit,
  makeId,
  trackAiUsageAndNotify,
} from '../services/firestoreHelpers';
import {
  GitBranch,
  ZoomIn,
  ZoomOut,
  Download,
  Printer,
  Trash2,
  Loader2,
  AlertCircle,
  Plus,
  Save,
  Edit3,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  lectures: Lecture[];
  mindMaps: MindMapDoc[];
  initialLectureId?: string;
}

interface PositionedNode {
  node: MindMapNode;
  x: number;
  y: number;
  parentX?: number;
  parentY?: number;
}

function layoutMindMap(
  root: MindMapNode,
  offsets: Record<string, { dx: number; dy: number }>
): { nodes: PositionedNode[]; width: number; height: number } {
  const nodes: PositionedNode[] = [];
  const level1 = root.children || [];
  let currentY = 60;
  const colX = [140, 440, 760];

  const getOff = (id: string) => offsets[id] || { dx: 0, dy: 0 };

  for (const child of level1) {
    const grandchildren = child.children || [];
    const blockHeight = Math.max(1, grandchildren.length) * 68;
    const childY = currentY + blockHeight / 2 - 20;
    const cOff = getOff(child.id);

    if (grandchildren.length > 0) {
      let gcY = currentY;
      for (const gc of grandchildren) {
        const gOff = getOff(gc.id);
        nodes.push({
          node: gc,
          x: colX[2] + gOff.dx,
          y: gcY + gOff.dy,
          parentX: colX[1] + cOff.dx,
          parentY: childY + cOff.dy,
        });
        gcY += 68;
      }
    }
    nodes.push({
      node: child,
      x: colX[1] + cOff.dx,
      y: childY + cOff.dy,
      parentX: colX[0],
      parentY: 0,
    });
    currentY += blockHeight + 28;
  }

  const totalHeight = Math.max(440, currentY + 40);
  const rOff = getOff(root.id);
  const rootX = colX[0] + rOff.dx;
  const rootY = totalHeight / 2 + rOff.dy;

  for (const item of nodes) {
    if (item.parentX === colX[0]) {
      item.parentX = rootX;
      item.parentY = rootY;
    }
  }

  nodes.unshift({ node: root, x: rootX, y: rootY });
  return { nodes, width: 1040, height: totalHeight };
}

function updateNodeTree(
  node: MindMapNode,
  targetId: string,
  updater: (n: MindMapNode) => MindMapNode
): MindMapNode {
  if (node.id === targetId) return updater(node);
  if (!node.children) return node;
  return {
    ...node,
    children: node.children.map((c) => updateNodeTree(c, targetId, updater)),
  };
}

function removeNodeFromTree(node: MindMapNode, targetId: string): MindMapNode {
  if (!node.children) return node;
  return {
    ...node,
    children: node.children
      .filter((c) => c.id !== targetId)
      .map((c) => removeNodeFromTree(c, targetId)),
  };
}

export const MindMapsView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  lectures,
  mindMaps,
  initialLectureId,
}) => {
  const isAr = lang === 'ar';
  const [selectedLectureId, setSelectedLectureId] = useState(initialLectureId || lectures[0]?.id || '');
  const [activeMapId, setActiveMapId] = useState(mindMaps[0]?.id || '');
  const [draftRoot, setDraftRoot] = useState<MindMapNode | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const [zoom, setZoom] = useState(1);
  const [selectedNodeId, setSelectedNodeId] = useState<string>('');
  const [editLabel, setEditLabel] = useState('');
  const [editDetail, setEditDetail] = useState('');
  const [newChildLabel, setNewChildLabel] = useState('');
  const [dragOffsets, setDragOffsets] = useState<Record<string, { dx: number; dy: number }>>({});
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const dragStartRef = useRef<{ x: number; y: number; origDx: number; origDy: number } | null>(null);

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [savedNotice, setSavedNotice] = useState('');
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (initialLectureId) setSelectedLectureId(initialLectureId);
  }, [initialLectureId]);

  useEffect(() => {
    if (!activeMapId && mindMaps[0]?.id) setActiveMapId(mindMaps[0].id);
  }, [mindMaps, activeMapId]);

  const activeMap = mindMaps.find((m) => m.id === activeMapId) || null;

  useEffect(() => {
    if (activeMap) {
      setDraftRoot(activeMap.rootNodeJson);
      setHasUnsavedChanges(false);
      setDragOffsets({});
      setSelectedNodeId(activeMap.rootNodeJson.id);
      setEditLabel(activeMap.rootNodeJson.label);
      setEditDetail(activeMap.rootNodeJson.detail || '');
    } else {
      setDraftRoot(null);
    }
  }, [activeMapId]);

  const findNode = (node: MindMapNode | null, id: string): MindMapNode | null => {
    if (!node) return null;
    if (node.id === id) return node;
    for (const c of node.children || []) {
      const f = findNode(c, id);
      if (f) return f;
    }
    return null;
  };

  const selectedNode = findNode(draftRoot, selectedNodeId) || draftRoot;

  const handleSelectNode = (node: MindMapNode) => {
    setSelectedNodeId(node.id);
    setEditLabel(node.label);
    setEditDetail(node.detail || '');
  };

  const handleApplyNodeEdit = () => {
    if (!draftRoot || !selectedNode) return;
    const next = updateNodeTree(draftRoot, selectedNode.id, (n) => ({
      ...n,
      label: editLabel.trim() || n.label,
      detail: editDetail.trim(),
    }));
    setDraftRoot(next);
    setHasUnsavedChanges(true);
  };

  const handleAddChildNode = () => {
    if (!draftRoot || !selectedNode || !newChildLabel.trim()) return;
    const child: MindMapNode = {
      id: makeId('node'),
      label: newChildLabel.trim().slice(0, 120),
      category: selectedNode.category === 'root' ? 'topic' : 'subtopic',
      detail: '',
      children: [],
    };
    const next = updateNodeTree(draftRoot, selectedNode.id, (n) => ({
      ...n,
      children: [...(n.children || []), child],
    }));
    setDraftRoot(next);
    setNewChildLabel('');
    setHasUnsavedChanges(true);
  };

  const handleDeleteNode = () => {
    if (!draftRoot || !selectedNode || selectedNode.id === draftRoot.id) return;
    const next = removeNodeFromTree(draftRoot, selectedNode.id);
    setDraftRoot(next);
    setSelectedNodeId(next.id);
    setEditLabel(next.label);
    setEditDetail(next.detail || '');
    setHasUnsavedChanges(true);
  };

  const handleSaveMapChanges = async () => {
    if (!activeMap || !draftRoot) return;
    try {
      await updateDoc(doc(db, 'mindmaps', activeMap.id), {
        title: draftRoot.label.slice(0, 200) || activeMap.title,
        rootNodeJson: draftRoot,
      });
      setHasUnsavedChanges(false);
      setSavedNotice(isAr ? 'تم حفظ تعديلات الخريطة الذهنية.' : 'Mind map changes saved.');
      setTimeout(() => setSavedNotice(''), 2500);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `mindmaps/${activeMap.id}`);
    }
  };

  const handleGenerate = async () => {
    const lec = lectures.find((l) => l.id === selectedLectureId);
    if (!lec) return;
    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم استنفاد رصيد الذكاء الاصطناعي لباقتك.' : 'AI request limit reached.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const res = await generateMindMap({
        lectureTitle: lec.title,
        fullText: lec.fullTextPreview || lec.extractedPages.map((p) => p.content).join('\n'),
        lang: profile?.explanationLang || lang,
      });

      const id = makeId('map');
      await setDoc(doc(db, 'mindmaps', id), {
        ownerId: uid,
        subjectId: lec.subjectId,
        lectureId: lec.id,
        title: lec.title.slice(0, 200),
        rootNodeJson: res.rootNode,
        createdAt: serverTimestamp(),
      });
      setActiveMapId(id);
      setDraftRoot(res.rootNode);
      setSelectedNodeId(res.rootNode.id);
      setEditLabel(res.rootNode.label);
      setEditDetail(res.rootNode.detail || '');
      await trackAiUsageAndNotify({ uid, xpDelta: 20 });
      await awardStudyXp(uid, profile, 20);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Mind map generation failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleExportPng = () => {
    if (!svgRef.current) return;
    const svgData = new XMLSerializer().serializeToString(svgRef.current);
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = svgRef.current?.viewBox.baseVal.width || 1040;
      canvas.height = svgRef.current?.viewBox.baseVal.height || 600;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
        const pngUrl = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.href = pngUrl;
        link.download = `${activeMap?.title || 'mindmap'}.png`;
        link.click();
      }
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  const layout = draftRoot ? layoutMindMap(draftRoot, dragOffsets) : null;

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'الخرائط الذهنية التفاعلية' : 'Interactive Lecture Mind Maps'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'خرائط مفاهيم قابلة للسحب، تعديل العقد، إضافة فروع جديدة، والتصدير PNG أو PDF.'
              : 'Draggable, editable concept trees—rename nodes, add sub-branches, and export PNG or PDF.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={selectedLectureId}
            onChange={(e) => setSelectedLectureId(e.target.value)}
            className="px-3 py-2 text-sm glass-surface border border-slate-200 dark:border-slate-700 rounded-lg"
          >
            <option value="">{isAr ? 'اختر محاضرة...' : 'Select lecture...'}</option>
            {lectures.map((l) => (
              <option key={l.id} value={l.id}>
                {l.title}
              </option>
            ))}
          </select>

          <button
            disabled={!selectedLectureId || busy}
            onClick={handleGenerate}
            className="px-4 py-2 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <GitBranch className="w-4 h-4" />}
            <span>{isAr ? 'إنشاء خريطة ذهنية' : 'Generate Mind Map'}</span>
          </button>
        </div>
      </div>

      {savedNotice && (
        <div className="no-print p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {savedNotice}
        </div>
      )}

      {error && (
        <div className="no-print p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="no-print lg:col-span-3 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2 max-h-[600px] overflow-y-auto">
          <p className="text-xs font-semibold text-slate-500 px-2 pb-1">
            {isAr ? `الخرائط المحفوظة (${mindMaps.length})` : `Saved Maps (${mindMaps.length})`}
          </p>
          {mindMaps.map((m) => (
            <div
              key={m.id}
              onClick={() => setActiveMapId(m.id)}
              className={`p-3 rounded-xl cursor-pointer border flex items-center justify-between gap-2 ${
                m.id === activeMapId
                  ? 'bg-blue-50 dark:bg-sky-950/40 border-blue-200 dark:border-sky-800'
                  : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <span className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate">
                {m.title}
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  deleteDocSafe('mindmaps', m.id);
                }}
                className="text-slate-400 hover:text-red-600"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        <div className="lg:col-span-9 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-4">
          {!layout ? (
            <div className="py-20 text-center text-sm text-slate-500">
              {isAr ? 'اختر محاضرة واضغط "إنشاء خريطة ذهنية" لعرضها هنا.' : 'Select a lecture and generate a mind map.'}
            </div>
          ) : (
            <>
              <div className="no-print flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setZoom((z) => Math.min(1.6, Number((z + 0.15).toFixed(2))))}
                    className="p-2 border border-slate-200 dark:border-slate-700 rounded-lg"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setZoom((z) => Math.max(0.55, Number((z - 0.15).toFixed(2))))}
                    className="p-2 border border-slate-200 dark:border-slate-700 rounded-lg"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <span className="text-xs font-mono text-slate-500 tabular-nums">
                    {Math.round(zoom * 100)}%
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {hasUnsavedChanges && (
                    <button
                      onClick={handleSaveMapChanges}
                      className="px-3.5 py-1.5 text-xs font-semibold accent-btn-gradient text-white rounded-lg flex items-center gap-1.5"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isAr ? 'حفظ التعديلات' : 'Save Map Changes'}</span>
                    </button>
                  )}
                  <button
                    onClick={handleExportPng}
                    className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isAr ? 'حفظ PNG' : 'Export PNG'}</span>
                  </button>
                  <button
                    onClick={() => window.print()}
                    className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>{isAr ? 'تصدير PDF' : 'Export PDF'}</span>
                  </button>
                </div>
              </div>

              <div className="overflow-auto border border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50 dark:bg-slate-950 max-h-[500px]">
                <svg
                  ref={svgRef}
                  viewBox={`0 0 ${layout.width} ${layout.height}`}
                  style={{ width: `${layout.width * zoom}px`, height: `${layout.height * zoom}px` }}
                  className="mx-auto select-none"
                  onPointerMove={(e) => {
                    if (!draggingId || !dragStartRef.current) return;
                    const dx = dragStartRef.current.origDx + (e.clientX - dragStartRef.current.x) / zoom;
                    const dy = dragStartRef.current.origDy + (e.clientY - dragStartRef.current.y) / zoom;
                    setDragOffsets((prev) => ({ ...prev, [draggingId]: { dx, dy } }));
                  }}
                  onPointerUp={() => {
                    setDraggingId(null);
                    dragStartRef.current = null;
                  }}
                >
                  {layout.nodes.map(
                    (item, idx) =>
                      item.parentX !== undefined &&
                      item.parentY !== undefined && (
                        <path
                          key={`edge-${idx}`}
                          d={`M ${item.parentX} ${item.parentY} C ${(item.parentX + item.x) / 2} ${item.parentY}, ${(item.parentX + item.x) / 2} ${item.y}, ${item.x} ${item.y}`}
                          fill="none"
                          stroke="#64748b"
                          strokeWidth="1.75"
                        />
                      )
                  )}
                  {layout.nodes.map((item, idx) => {
                    const isRoot = item.node.category === 'root' || idx === 0;
                    const isSelected = selectedNode?.id === item.node.id;
                    const fill = isRoot
                      ? '#2563eb'
                      : item.node.category === 'formula'
                        ? '#7c3aed'
                        : '#ffffff';
                    const textFill = isRoot || item.node.category === 'formula' ? '#ffffff' : '#0f172a';
                    return (
                      <g
                        key={`node-${item.node.id}`}
                        transform={`translate(${item.x - 110}, ${item.y - 22})`}
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          handleSelectNode(item.node);
                          setDraggingId(item.node.id);
                          const curr = dragOffsets[item.node.id] || { dx: 0, dy: 0 };
                          dragStartRef.current = {
                            x: e.clientX,
                            y: e.clientY,
                            origDx: curr.dx,
                            origDy: curr.dy,
                          };
                        }}
                        className="cursor-grab active:cursor-grabbing"
                      >
                        <rect
                          width="220"
                          height="44"
                          rx="12"
                          fill={fill}
                          stroke={isSelected ? '#38bdf8' : isRoot ? '#1d4ed8' : '#cbd5e1'}
                          strokeWidth={isSelected ? '3' : '1.5'}
                        />
                        <text
                          x="110"
                          y="26"
                          textAnchor="middle"
                          fill={textFill}
                          fontSize="12"
                          fontWeight="600"
                        >
                          {item.node.label.slice(0, 28)}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>

              {/* Interactive Node Editor */}
              {selectedNode && (
                <div className="no-print p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-blue-600 dark:text-sky-400 flex items-center gap-1.5">
                      <Edit3 className="w-3.5 h-3.5" />
                      {isAr ? 'تعديل العقدة المحددة' : 'Edit Selected Node'} ({selectedNode.category})
                    </span>
                    {draftRoot && selectedNode.id !== draftRoot.id && (
                      <button
                        type="button"
                        onClick={handleDeleteNode}
                        className="text-xs text-red-500 hover:underline flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>{isAr ? 'حذف العقدة' : 'Remove Node'}</span>
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input
                      value={editLabel}
                      onChange={(e) => setEditLabel(e.target.value)}
                      placeholder={isAr ? 'عنوان العقدة' : 'Node label'}
                      className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
                    />
                    <input
                      value={editDetail}
                      onChange={(e) => setEditDetail(e.target.value)}
                      placeholder={isAr ? 'التفاصيل أو الشرح المختصر' : 'Detail / description'}
                      className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={handleApplyNodeEdit}
                      className="px-3 py-1.5 text-xs font-semibold bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg"
                    >
                      {isAr ? 'تطبيق على العقدة' : 'Update Node'}
                    </button>

                    <div className="flex items-center gap-2 flex-1 max-w-sm">
                      <input
                        value={newChildLabel}
                        onChange={(e) => setNewChildLabel(e.target.value)}
                        placeholder={isAr ? 'إضافة فرع جديد تحت هذه العقدة...' : 'Add child branch...'}
                        className="flex-1 px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                      <button
                        type="button"
                        disabled={!newChildLabel.trim()}
                        onClick={handleAddChildNode}
                        className="px-3 py-1.5 text-xs font-semibold border border-blue-300 dark:border-sky-700 text-blue-700 dark:text-sky-300 rounded-lg flex items-center gap-1 disabled:opacity-40"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>{isAr ? 'إضافة' : 'Add'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
