import React, { useEffect, useRef, useState } from 'react';
import { doc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Language,
  Lecture,
  LectureSummary,
  MistakeEntry,
  StudyGroup,
  Subject,
  SubscriptionPlan,
  SummaryDetailLevel,
  UserProfile,
} from '../types';
import { generateRevisionPack, generateSummary, synthesizeSpeech } from '../services/api';
import {
  awardStudyXp,
  deleteDocSafe,
  getEffectiveLimit,
  makeId,
  trackAiUsageAndNotify,
} from '../services/firestoreHelpers';
import {
  FileText,
  Printer,
  Share2,
  Edit3,
  Save,
  Trash2,
  Volume2,
  Pause,
  Loader2,
  AlertCircle,
  Sparkles,
  ChevronDown,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  lectures: Lecture[];
  summaries: LectureSummary[];
  mistakes: MistakeEntry[];
  studyGroups: StudyGroup[];
  initialLectureId?: string;
  initialMode?: 'summary' | 'revision';
}

export const SummariesView: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  subjects,
  lectures,
  summaries,
  mistakes,
  studyGroups,
  initialLectureId,
  initialMode,
}) => {
  const isAr = lang === 'ar';
  const [mode, setMode] = useState<'summary' | 'revision'>(initialMode || 'summary');
  const [selectedLectureId, setSelectedLectureId] = useState(initialLectureId || lectures[0]?.id || '');
  const [detailLevel, setDetailLevel] = useState<SummaryDetailLevel>('medium');
  const [activeSummaryId, setActiveSummaryId] = useState<string>(summaries[0]?.id || '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [editing, setEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editMarkdown, setEditMarkdown] = useState('');

  // Share modal state
  const [showShare, setShowShare] = useState(false);
  const [shareGroupId, setShareGroupId] = useState(studyGroups[0]?.id || '');
  const [shareConsent, setShareConsent] = useState(false);

  // TTS
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [ttsBusy, setTtsBusy] = useState(false);

  // Revision / Cram Mode state
  const [revisionScope, setRevisionScope] = useState<'subject' | 'lecture'>('subject');
  const [revisionSubjectId, setRevisionSubjectId] = useState(subjects[0]?.id || '');
  const [revisionPack, setRevisionPack] = useState<{
    title: string;
    rapidBulletSummary: string[];
    mustKnowDefinitions: { term: string; definition: string }[];
    keyFormulasOrRules: string[];
    rapidQaCheck: { question: string; answer: string }[];
  } | null>(null);
  const [openQaIdx, setOpenQaIdx] = useState<number | null>(null);

  useEffect(() => {
    if (initialMode) setMode(initialMode);
  }, [initialMode]);

  useEffect(() => {
    if (initialLectureId) setSelectedLectureId(initialLectureId);
  }, [initialLectureId]);

  useEffect(() => {
    if (!activeSummaryId && summaries[0]?.id) {
      setActiveSummaryId(summaries[0].id);
    }
  }, [summaries, activeSummaryId]);

  useEffect(() => {
    if (!revisionSubjectId && subjects[0]?.id) {
      setRevisionSubjectId(subjects[0].id);
    }
  }, [subjects, revisionSubjectId]);

  const activeSummary = summaries.find((s) => s.id === activeSummaryId) || null;

  const handleGenerate = async () => {
    const lec = lectures.find((l) => l.id === selectedLectureId);
    if (!lec) return;
    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(
        isAr
          ? 'تم الوصول للحد الأقصى لاستخدام الذكاء الاصطناعي في باقتك الحالية.'
          : 'AI request quota reached for your current plan.'
      );
      return;
    }

    setBusy(true);
    setError('');
    try {
      const res = await generateSummary({
        lectureTitle: lec.title,
        fullText: lec.fullTextPreview || lec.extractedPages.map((p) => p.content).join('\n\n'),
        detailLevel,
        lang: profile?.explanationLang || lang,
      });

      const id = makeId('sum');
      await setDoc(doc(db, 'summaries', id), {
        ownerId: uid,
        lectureId: lec.id,
        subjectId: lec.subjectId,
        title: `${lec.title} (${detailLevel})`.slice(0, 200),
        detailLevel,
        contentMarkdown: res.contentMarkdown.slice(0, 40000),
        keyPoints: (res.keyPoints || []).slice(0, 40),
        definitions: (res.definitions || []).slice(0, 40),
        formulas: (res.formulas || []).slice(0, 30),
        comparisons: (res.comparisons || []).slice(0, 20),
        revisionAlerts: (res.revisionAlerts || []).slice(0, 20),
        isShared: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      setActiveSummaryId(id);
      await trackAiUsageAndNotify({
        uid,
        enableNotif: profile?.notifAiReady !== false,
        notifTitle: isAr ? 'اكتمل إنشاء الملخص' : 'Summary Ready',
        notifBody: isAr ? `تم تلخيص "${lec.title}" بنجاح.` : `Summary for "${lec.title}" created.`,
        notifCategory: 'ai',
        xpDelta: 20,
      });
      await awardStudyXp(uid, profile, 20);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Summary generation failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleGenerateRevision = async () => {
    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم الوصول للحد الشهري لطلبات AI.' : 'AI request limit reached.');
      return;
    }

    let sourceText = '';
    let title = '';
    let weakTopics: string[] = [];

    if (revisionScope === 'lecture') {
      const lec = lectures.find((l) => l.id === selectedLectureId);
      if (!lec) {
        setError(isAr ? 'اختر محاضرة أولًا.' : 'Select a lecture first.');
        return;
      }
      title = lec.title;
      sourceText = lec.fullTextPreview || lec.extractedPages.map((p) => p.content).join('\n\n');
      weakTopics = mistakes.filter((m) => m.subjectId === lec.subjectId && !m.mastered).map((m) => m.topic);
    } else {
      const subj = subjects.find((s) => s.id === revisionSubjectId);
      const subjLectures = lectures.filter((l) => l.subjectId === revisionSubjectId);
      if (!subj || subjLectures.length === 0) {
        setError(
          isAr ? 'اختر مادة تحتوي على محاضرة واحدة على الأقل.' : 'Select a subject with at least one lecture.'
        );
        return;
      }
      title = subj.name;
      sourceText = subjLectures
        .map((l) => `=== ${l.title} ===\n${l.fullTextPreview.slice(0, 7500)}`)
        .join('\n\n');
      weakTopics = mistakes.filter((m) => m.subjectId === subj.id && !m.mastered).map((m) => m.topic);
    }

    setBusy(true);
    setError('');
    try {
      const pack = await generateRevisionPack({
        title,
        sourceText,
        weakTopics: Array.from(new Set(weakTopics)).slice(0, 10),
        lang: profile?.explanationLang || lang,
      });
      setRevisionPack({ title, ...pack });
      setOpenQaIdx(null);
      await trackAiUsageAndNotify({ uid, xpDelta: 25 });
      await awardStudyXp(uid, profile, 25);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Revision pack generation failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleSaveEdit = async () => {
    if (!activeSummary) return;
    try {
      await updateDoc(doc(db, 'summaries', activeSummary.id), {
        title: editTitle.trim().slice(0, 200) || activeSummary.title,
        contentMarkdown: editMarkdown.slice(0, 40000),
        updatedAt: serverTimestamp(),
      });
      setEditing(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `summaries/${activeSummary.id}`);
    }
  };

  const handleShareSubmit = async () => {
    if (!activeSummary || !shareGroupId || !shareConsent) return;
    const subj = subjects.find((s) => s.id === activeSummary.subjectId);
    const id = makeId('res');
    try {
      await setDoc(doc(db, 'sharedResources', id), {
        ownerId: uid,
        ownerName: profile?.displayName || 'Student',
        groupId: shareGroupId,
        resourceType: 'summary',
        title: activeSummary.title,
        subjectName: subj?.name || 'University Course',
        contentPreview: activeSummary.contentMarkdown.slice(0, 14500),
        consentConfirmed: true,
        createdAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'summaries', activeSummary.id), {
        isShared: true,
        updatedAt: serverTimestamp(),
      });
      setShowShare(false);
      setShareConsent(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `sharedResources/${id}`);
    }
  };

  const handleTts = async () => {
    if (!activeSummary) return;
    if (isPlaying && audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
      return;
    }
    setTtsBusy(true);
    try {
      const res = await synthesizeSpeech(activeSummary.contentMarkdown);
      const audio = new Audio(`data:${res.mimeType};base64,${res.audioBase64}`);
      audio.onended = () => setIsPlaying(false);
      audioRef.current = audio;
      await audio.play();
      setIsPlaying(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'TTS failed.');
    } finally {
      setTtsBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'التلخيص الذكي ومراجعة ليلة الامتحان' : 'Smart Summaries & Revision Mode'}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'ملخصات تفصيلية قابلة للتعديل والتصدير PDF، بالإضافة إلى وضع المراجعة السريعة لمادة كاملة.'
              : 'Editable lecture summaries with PDF export, plus high-speed Pre-Exam Cram Mode.'}
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl self-start">
          <button
            onClick={() => setMode('summary')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
              mode === 'summary'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isAr ? 'ملخصات المحاضرات' : 'Lecture Summaries'}</span>
          </button>
          <button
            onClick={() => setMode('revision')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
              mode === 'revision'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isAr ? 'مراجعة ليلة الامتحان' : 'Revision / Cram Mode'}</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="no-print p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {mode === 'revision' ? (
        <div className="space-y-6">
          <div className="no-print glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 flex-1">
              <select
                value={revisionScope}
                onChange={(e) => setRevisionScope(e.target.value as 'subject' | 'lecture')}
                className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="subject">{isAr ? 'مادة دراسية كاملة' : 'Full Subject (All Lectures)'}</option>
                <option value="lecture">{isAr ? 'محاضرة واحدة' : 'Single Lecture'}</option>
              </select>

              {revisionScope === 'subject' ? (
                <select
                  value={revisionSubjectId}
                  onChange={(e) => setRevisionSubjectId(e.target.value)}
                  className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg min-w-[220px]"
                >
                  <option value="">{isAr ? 'اختر المادة...' : 'Select subject...'}</option>
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              ) : (
                <select
                  value={selectedLectureId}
                  onChange={(e) => setSelectedLectureId(e.target.value)}
                  className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg min-w-[220px]"
                >
                  <option value="">{isAr ? 'اختر محاضرة...' : 'Select lecture...'}</option>
                  {lectures.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.title}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <button
              disabled={busy}
              onClick={handleGenerateRevision}
              className="px-5 py-2.5 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap shrink-0"
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>{isAr ? 'توليد حزمة المراجعة السريعة' : 'Build Rapid Cram Pack'}</span>
            </button>
          </div>

          {!revisionPack ? (
            <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center space-y-2 text-slate-500">
              <Sparkles className="w-8 h-8 mx-auto opacity-50" />
              <p className="text-sm">
                {isAr
                  ? 'اختر مادة كاملة أو محاضرة لتوليد نقاط سريعة وأهم التعريفات والقوانين مع التركيز على نقاط ضعفك.'
                  : 'Select a full subject or lecture to generate high-speed cram bullets, definitions, formulas, and rapid Q&A checks.'}
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  {isAr ? `حزمة المراجعة السريعة: ${revisionPack.title}` : `Cram Pack: ${revisionPack.title}`}
                </h2>
                <button
                  onClick={() => window.print()}
                  className="no-print px-3.5 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isAr ? 'طباعة / PDF' : 'Print / PDF'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
                  <h3 className="text-sm font-bold text-blue-600 dark:text-sky-400">
                    {isAr ? 'النقاط المركزة (Rapid Bullets)' : 'Rapid Bullet Summary'}
                  </h3>
                  <ul className="list-disc list-inside space-y-2 text-sm text-slate-700 dark:text-slate-300">
                    {revisionPack.rapidBulletSummary.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>

                <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
                  <h3 className="text-sm font-bold text-purple-600 dark:text-purple-400">
                    {isAr ? 'القوانين والقواعد الأساسية' : 'Key Formulas & Rules'}
                  </h3>
                  <div className="space-y-2">
                    {revisionPack.keyFormulasOrRules.map((f, i) => (
                      <div
                        key={i}
                        className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-mono text-slate-800 dark:text-slate-200"
                      >
                        {f}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  {isAr ? 'تعريفات لا غنى عنها في الامتحان' : 'Must-Know Definitions'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {revisionPack.mustKnowDefinitions.map((d, i) => (
                    <div
                      key={i}
                      className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                    >
                      <p className="font-bold text-slate-900 dark:text-white">{d.term}</p>
                      <p className="text-slate-600 dark:text-slate-400 mt-1">{d.definition}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
                <h3 className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                  {isAr ? 'اختبار سريع للفهم (اضغط لكشف الإجابة)' : 'Rapid Q&A Check (Click to reveal)'}
                </h3>
                <div className="space-y-2">
                  {revisionPack.rapidQaCheck.map((qa, i) => {
                    const open = openQaIdx === i;
                    return (
                      <div
                        key={i}
                        className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden"
                      >
                        <button
                          onClick={() => setOpenQaIdx(open ? null : i)}
                          className="w-full p-3.5 text-start flex items-center justify-between gap-3 text-sm font-semibold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        >
                          <span>
                            {i + 1}. {qa.question}
                          </span>
                          <ChevronDown
                            className={`w-4 h-4 shrink-0 transition-transform ${open ? 'rotate-180' : ''}`}
                          />
                        </button>
                        {open && (
                          <div className="px-3.5 pb-3.5 pt-1 text-xs text-emerald-800 dark:text-emerald-300 bg-emerald-50/60 dark:bg-emerald-950/20">
                            {qa.answer}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <>
          <div className="no-print glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3">
              <select
                value={selectedLectureId}
                onChange={(e) => setSelectedLectureId(e.target.value)}
                className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="">{isAr ? 'اختر محاضرة...' : 'Select lecture...'}</option>
                {lectures.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.title}
                  </option>
                ))}
              </select>

              <select
                value={detailLevel}
                onChange={(e) => setDetailLevel(e.target.value as SummaryDetailLevel)}
                className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="short">{isAr ? 'تلخيص مختصر' : 'Short'}</option>
                <option value="medium">{isAr ? 'تلخيص متوسط' : 'Medium'}</option>
                <option value="detailed">{isAr ? 'تلخيص تفصيلي' : 'Detailed'}</option>
              </select>
            </div>

            <button
              disabled={!selectedLectureId || busy}
              onClick={handleGenerate}
              className="px-4 py-2 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap shrink-0"
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
              <span>{isAr ? 'تلخيص المحاضرة' : 'Generate Summary'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Saved Summaries List */}
            <div className="no-print lg:col-span-4 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2 max-h-[640px] overflow-y-auto">
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 px-2 pb-1">
                {isAr ? `الملخصات المحفوظة (${summaries.length})` : `Saved Summaries (${summaries.length})`}
              </p>
              {summaries.length === 0 ? (
                <p className="text-xs text-slate-500 p-4 text-center">
                  {isAr ? 'لا توجد ملخصات محفوظة بعد.' : 'No summaries created yet.'}
                </p>
              ) : (
                summaries.map((sum) => (
                  <div
                    key={sum.id}
                    onClick={() => {
                      setActiveSummaryId(sum.id);
                      setEditing(false);
                    }}
                    className={`p-3 rounded-xl cursor-pointer border transition-colors flex items-start justify-between gap-2 ${
                      sum.id === activeSummaryId
                        ? 'bg-blue-50 dark:bg-sky-950/40 border-blue-200 dark:border-sky-800'
                        : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                        {sum.title}
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {sum.detailLevel} {sum.isShared ? `· ${isAr ? 'مشترك' : 'Shared'}` : ''}
                      </p>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteDocSafe('summaries', sum.id);
                      }}
                      className="p-1 text-slate-400 hover:text-red-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Summary Content Sheet */}
            <div className="lg:col-span-8 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-6">
              {!activeSummary ? (
                <div className="py-16 text-center text-sm text-slate-500">
                  {isAr
                    ? 'اختر محاضرة واضغط "تلخيص المحاضرة" أو اختر ملخصًا محفوظًا.'
                    : 'Select a lecture and generate a summary, or pick a saved one.'}
                </div>
              ) : (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                    {editing ? (
                      <input
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="flex-1 px-3 py-1.5 text-base font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg"
                      />
                    ) : (
                      <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                        {activeSummary.title}
                      </h2>
                    )}

                    <div className="no-print flex flex-wrap items-center gap-2">
                      <button
                        disabled={ttsBusy}
                        onClick={handleTts}
                        className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5"
                      >
                        {ttsBusy ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : isPlaying ? (
                          <Pause className="w-3.5 h-3.5" />
                        ) : (
                          <Volume2 className="w-3.5 h-3.5" />
                        )}
                        <span>{isPlaying ? (isAr ? 'إيقاف' : 'Pause') : isAr ? 'استماع' : 'Listen'}</span>
                      </button>
                      {editing ? (
                        <button
                          onClick={handleSaveEdit}
                          className="px-3 py-1.5 text-xs font-medium bg-blue-700 text-white rounded-lg flex items-center gap-1.5"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>{isAr ? 'حفظ' : 'Save'}</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            setEditTitle(activeSummary.title);
                            setEditMarkdown(activeSummary.contentMarkdown);
                            setEditing(true);
                          }}
                          className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>{isAr ? 'تعديل' : 'Edit'}</span>
                        </button>
                      )}
                      <button
                        onClick={() => window.print()}
                        className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>{isAr ? 'تصدير PDF' : 'Export PDF'}</span>
                      </button>
                      <button
                        onClick={() => setShowShare((v) => !v)}
                        className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>{isAr ? 'مشاركة' : 'Share'}</span>
                      </button>
                    </div>
                  </div>

                  {showShare && (
                    <div className="no-print p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
                      <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                        {isAr ? 'مشاركة الملخص مع مجموعة مذاكرة' : 'Share Summary to Study Group'}
                      </p>
                      {studyGroups.length === 0 ? (
                        <p className="text-xs text-slate-500">
                          {isAr
                            ? 'أنشئ مجموعة مذاكرة أولًا من قسم إنجازاتي والمجتمع.'
                            : 'Create a study group first in Progress & Social.'}
                        </p>
                      ) : (
                        <>
                          <select
                            value={shareGroupId}
                            onChange={(e) => setShareGroupId(e.target.value)}
                            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
                          >
                            <option value="">{isAr ? 'اختر المجموعة...' : 'Select group...'}</option>
                            {studyGroups.map((g) => (
                              <option key={g.id} value={g.id}>
                                {g.name} ({g.subjectName})
                              </option>
                            ))}
                          </select>
                          <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
                            <input
                              type="checkbox"
                              checked={shareConsent}
                              onChange={(e) => setShareConsent(e.target.checked)}
                            />
                            <span>
                              {isAr
                                ? 'أوافق على مشاركة هذا الملخص مع أعضاء المجموعة التعليمية.'
                                : 'I confirm consent to share this summary with study group members.'}
                            </span>
                          </label>
                          <button
                            disabled={!shareGroupId || !shareConsent}
                            onClick={handleShareSubmit}
                            className="px-4 py-1.5 text-xs font-medium bg-blue-700 text-white rounded-lg disabled:opacity-50"
                          >
                            {isAr ? 'تأكيد المشاركة' : 'Confirm Share'}
                          </button>
                        </>
                      )}
                    </div>
                  )}

                  {editing ? (
                    <textarea
                      rows={14}
                      value={editMarkdown}
                      onChange={(e) => setEditMarkdown(e.target.value)}
                      className="w-full p-4 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg leading-relaxed"
                    />
                  ) : (
                    <div className="space-y-6">
                      <div className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
                        {activeSummary.contentMarkdown}
                      </div>

                      {activeSummary.keyPoints && activeSummary.keyPoints.length > 0 && (
                        <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2">
                          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                            {isAr ? 'أهم النقاط الأساسية' : 'Key Takeaways'}
                          </h3>
                          <ul className="list-disc list-inside space-y-1.5 text-sm text-slate-700 dark:text-slate-300">
                            {activeSummary.keyPoints.map((kp, i) => (
                              <li key={i}>{kp}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {activeSummary.definitions && activeSummary.definitions.length > 0 && (
                        <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2">
                          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                            {isAr ? 'التعريفات والمصطلحات' : 'Core Definitions'}
                          </h3>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {activeSummary.definitions.map((d, i) => (
                              <div
                                key={i}
                                className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                              >
                                <p className="font-semibold text-slate-900 dark:text-white">{d.term}</p>
                                <p className="text-slate-600 dark:text-slate-400 mt-1">{d.definition}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {activeSummary.formulas && activeSummary.formulas.length > 0 && (
                        <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2">
                          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                            {isAr ? 'القوانين والمعادلات' : 'Formulas & Laws'}
                          </h3>
                          <div className="space-y-2">
                            {activeSummary.formulas.map((f, i) => (
                              <div
                                key={i}
                                className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                              >
                                <p className="font-semibold text-slate-900 dark:text-white">{f.name}</p>
                                <p dir="ltr" className="font-mono text-blue-700 dark:text-sky-400 mt-1">
                                  {f.expression}
                                </p>
                                {f.note && <p className="text-slate-500 mt-1">{f.note}</p>}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {activeSummary.comparisons && activeSummary.comparisons.length > 0 && (
                        <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2">
                          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                            {isAr ? 'المقارنات المهمة' : 'Key Comparisons'}
                          </h3>
                          <div className="space-y-2">
                            {activeSummary.comparisons.map((c, i) => (
                              <div
                                key={i}
                                className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1"
                              >
                                <p className="font-semibold text-slate-900 dark:text-white">
                                  {c.topicA} vs. {c.topicB}
                                </p>
                                <p className="text-slate-600 dark:text-slate-400">{c.difference}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {activeSummary.revisionAlerts && activeSummary.revisionAlerts.length > 0 && (
                        <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2">
                          <h3 className="text-sm font-semibold text-amber-700 dark:text-amber-400">
                            {isAr ? 'نقاط للمراجعة السريعة قبل الامتحان' : 'Pre-Exam Cram Alerts'}
                          </h3>
                          <ul className="list-disc list-inside space-y-1 text-xs text-slate-700 dark:text-slate-300">
                            {activeSummary.revisionAlerts.map((r, i) => (
                              <li key={i}>{r}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
