import React, { useEffect, useState } from 'react';
import {
  AcademicContentNode,
  ContentKind,
  Language,
  SupportTicket,
  TargetedNotificationRecord,
} from '../../types';
import {
  DevAnalyticsResponse,
  DevMonitoringResponse,
  createDevContent,
  deleteDevContent,
  dispatchDevNotification,
  fetchDevAnalytics,
  fetchDevContent,
  fetchDevMonitoring,
  fetchDevNotifications,
  fetchDevSupport,
  patchDevContent,
  patchDevTicket,
} from '../../services/devApi';
import { FeatureUsageBarChart } from './DevCharts';
import {
  Activity,
  BarChart3,
  Bell,
  CheckCircle2,
  Download,
  Eye,
  EyeOff,
  FileSpreadsheet,
  FolderTree,
  LifeBuoy,
  Plus,
  Printer,
  RefreshCw,
  Send,
  Trash2,
} from 'lucide-react';

// =========================================================================
// 6. CONTENT MANAGEMENT SECTION
// =========================================================================
export const DevContentSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [nodes, setNodes] = useState<AcademicContentNode[]>([]);
  const [kindFilter, setKindFilter] = useState<string>('all');
  const [newKind, setNewKind] = useState<ContentKind>('university');
  const [newTitle, setNewTitle] = useState('');
  const [newParent, setNewParent] = useState('');
  const [newCategory, setNewCategory] = useState('');

  useEffect(() => {
    fetchDevContent(token).then((r) => setNodes(r.contentNodes)).catch(() => {});
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const res = await createDevContent(token, {
      kind: newKind,
      title: newTitle.trim(),
      parentName: newParent.trim(),
      category: newCategory.trim(),
      status: 'published',
    });
    setNodes(res.contentNodes);
    setNewTitle('');
    setNewParent('');
    setNewCategory('');
  };

  const filtered = nodes.filter((n) => kindFilter === 'all' || n.kind === kindFilter);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <FolderTree className="w-5 h-5 text-blue-500" />
          <span>{isAr ? 'إدارة المحتوى والهيكل الأكاديمي' : 'Content & Academic Hierarchy'}</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {isAr
            ? 'إدارة الجامعات، الكليات، الأقسام، الفرق، المواد، ومراجعة المحاضرات والملفات الفاشلة.'
            : 'Manage universities, colleges, departments, subjects, and moderate lectures or failed extractions.'}
        </p>
      </div>

      {/* Add Hierarchy / Content Form */}
      <form
        onSubmit={handleCreate}
        className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-5 gap-2.5 items-end"
      >
        <div>
          <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'النوع' : 'Type'}</label>
          <select
            value={newKind}
            onChange={(e) => setNewKind(e.target.value as ContentKind)}
            className="w-full px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
          >
            <option value="university">{isAr ? 'جامعة' : 'University'}</option>
            <option value="college">{isAr ? 'كلية' : 'College'}</option>
            <option value="department">{isAr ? 'قسم' : 'Department'}</option>
            <option value="year">{isAr ? 'فرقة دراسية' : 'Academic Year'}</option>
            <option value="subject">{isAr ? 'مادة دراسية' : 'Subject'}</option>
            <option value="lecture">{isAr ? 'محاضرة' : 'Lecture'}</option>
            <option value="exam">{isAr ? 'امتحان' : 'Exam'}</option>
          </select>
        </div>
        <div>
          <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'الاسم / العنوان' : 'Title'}</label>
          <input
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            required
            placeholder={isAr ? 'مثال: كلية الهندسة' : 'e.g. Computer Science'}
            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>
        <div>
          <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'يتبع لـ' : 'Parent'}</label>
          <input
            value={newParent}
            onChange={(e) => setNewParent(e.target.value)}
            placeholder={isAr ? 'الجامعة أو الكلية' : 'University / Faculty'}
            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>
        <div>
          <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'التصنيف' : 'Category'}</label>
          <input
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            placeholder="CS / Engineering / PDF"
            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>
        <button
          type="submit"
          className="px-4 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl flex items-center justify-center gap-1.5"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isAr ? 'إضافة' : 'Add Node'}</span>
        </button>
      </form>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-1.5">
        {(['all', 'university', 'college', 'department', 'subject', 'lecture', 'exam'] as const).map(
          (k) => (
            <button
              key={k}
              onClick={() => setKindFilter(k)}
              className={`px-3 py-1.5 text-xs rounded-lg border ${
                kindFilter === k
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {k}
            </button>
          )
        )}
      </div>

      {/* Content Table */}
      <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <p className="p-8 text-center text-xs text-slate-500">
            {isAr
              ? 'لا توجد عناصر محتوى مسجلة بعد. ستتم مزامنة مواد ومحاضرات الطلاب تلقائياً هنا.'
              : 'No content nodes recorded yet. Student subjects & lectures sync here automatically.'}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 text-slate-500">
                <tr>
                  <th className="p-3 text-start">{isAr ? 'النوع' : 'Kind'}</th>
                  <th className="p-3 text-start">{isAr ? 'العنوان' : 'Title'}</th>
                  <th className="p-3 text-start">{isAr ? 'النطاق' : 'Parent / Category'}</th>
                  <th className="p-3 text-start">{isAr ? 'الحالة' : 'Status'}</th>
                  <th className="p-3 text-end">{isAr ? 'إدارة' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((node) => (
                  <tr key={node.id}>
                    <td className="p-3 font-mono uppercase text-[11px]">{node.kind}</td>
                    <td className="p-3 font-semibold text-slate-800 dark:text-slate-100">
                      {node.title}
                    </td>
                    <td className="p-3 text-slate-500">
                      {node.parentName || node.category || '—'}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                          node.status === 'published'
                            ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                            : node.status === 'failed'
                              ? 'bg-red-500/15 text-red-600 dark:text-red-400'
                              : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                        }`}
                      >
                        {node.status}
                      </span>
                    </td>
                    <td className="p-3 text-end">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          onClick={async () => {
                            const next = node.status === 'hidden' ? 'published' : 'hidden';
                            const res = await patchDevContent(token, node.id, { status: next });
                            setNodes(res.contentNodes);
                          }}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                          title={node.status === 'hidden' ? 'Publish' : 'Hide'}
                        >
                          {node.status === 'hidden' ? (
                            <Eye className="w-3.5 h-3.5" />
                          ) : (
                            <EyeOff className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          onClick={async () => {
                            const res = await deleteDevContent(token, node.id);
                            setNodes(res.contentNodes);
                          }}
                          className="p-1.5 rounded-lg text-red-500 border border-slate-200 dark:border-slate-700 hover:bg-red-50 dark:hover:bg-red-950/30"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

// =========================================================================
// 7. NOTIFICATIONS CENTER
// =========================================================================
export const DevNotificationsSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [items, setItems] = useState<TargetedNotificationRecord[]>([]);
  const [target, setTarget] = useState<'all' | 'free' | 'pro' | 'elite' | 'user'>('all');
  const [targetValue, setTargetValue] = useState('');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [scheduledFor, setScheduledFor] = useState('');
  const [sentMsg, setSentMsg] = useState('');

  useEffect(() => {
    fetchDevNotifications(token).then((r) => setItems(r.notifications)).catch(() => {});
  }, []);

  const handleDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;
    const res = await dispatchDevNotification(token, {
      target,
      targetValue: targetValue.trim() || undefined,
      title: title.trim(),
      body: body.trim(),
      scheduledFor: scheduledFor || undefined,
    });
    setItems(res.notifications);
    setTitle('');
    setBody('');
    setScheduledFor('');
    setSentMsg(isAr ? 'تم إرسال / جدولة الإشعار بنجاح.' : 'Notification dispatched successfully.');
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Bell className="w-5 h-5 text-blue-500" />
          <span>{isAr ? 'مركز الإشعارات المستهدفة' : 'Notifications Center'}</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {isAr
            ? 'إرسال إشعارات فورية أو مجدولة لجميع الطلاب، أو باقة محددة، أو طالب بعينه.'
            : 'Dispatch immediate or scheduled announcements to all users, specific plans, or individual students.'}
        </p>
      </div>

      {sentMsg && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {sentMsg}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <form
          onSubmit={handleDispatch}
          className="lg:col-span-5 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3"
        >
          <h3 className="text-sm font-bold">{isAr ? 'إنشاء إشعار جديد' : 'Compose Notification'}</h3>
          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div>
              <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'الجمهور المستهدف' : 'Target Audience'}</label>
              <select
                value={target}
                onChange={(e) => setTarget(e.target.value as typeof target)}
                className="w-full px-2.5 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
              >
                <option value="all">{isAr ? 'جميع الطلاب' : 'All Students'}</option>
                <option value="free">{isAr ? 'الباقة المجانية Free' : 'Free Plan'}</option>
                <option value="pro">{isAr ? 'مشتركو Pro' : 'Pro Plan'}</option>
                <option value="elite">{isAr ? 'مشتركو Elite' : 'Elite Plan'}</option>
                <option value="user">{isAr ? 'طالب محدد (UID/Email)' : 'Specific Student'}</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] text-slate-500 block mb-1">
                {isAr ? 'جدولة (اختياري)' : 'Schedule (optional)'}
              </label>
              <input
                type="datetime-local"
                value={scheduledFor}
                onChange={(e) => setScheduledFor(e.target.value)}
                className="w-full px-2.5 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          {target === 'user' && (
            <input
              value={targetValue}
              onChange={(e) => setTargetValue(e.target.value)}
              required
              placeholder={isAr ? 'البريد الإلكتروني أو UID للطالب' : 'Student Email or UID'}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          )}

          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            placeholder={isAr ? 'عنوان الإشعار' : 'Notification Headline'}
            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
          <textarea
            rows={4}
            value={body}
            onChange={(e) => setBody(e.target.value)}
            required
            placeholder={isAr ? 'محتوى الرسالة أو التحديث...' : 'Announcement content...'}
            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
          <button
            type="submit"
            className="w-full py-2.5 text-xs font-semibold accent-btn-gradient text-white rounded-xl flex items-center justify-center gap-2"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isAr ? 'إرسال الإشعار الآن' : 'Dispatch Notification'}</span>
          </button>
        </form>

        <div className="lg:col-span-7 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-bold">{isAr ? 'سجل الإشعارات المرسلة' : 'Dispatch History'}</h3>
          {items.length === 0 ? (
            <p className="text-xs text-slate-500 py-10 text-center">
              {isAr ? 'لم يتم إرسال أي إشعارات جماعية بعد.' : 'No notifications dispatched yet.'}
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-96 overflow-y-auto">
              {items.map((n) => (
                <div key={n.id} className="py-3 space-y-1 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-slate-900 dark:text-white">{n.title}</span>
                    <span className="px-2 py-0.5 rounded bg-blue-500/15 text-blue-600 dark:text-sky-400 font-mono text-[11px]">
                      {n.target} · {n.recipientCount}
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400">{n.body}</p>
                  <p className="text-[10px] text-slate-400 font-mono">
                    {n.status} · {new Date(n.createdAt).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 8. SUPPORT CENTER
// =========================================================================
export const DevSupportSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selected, setSelected] = useState<SupportTicket | null>(null);
  const [reply, setReply] = useState('');
  const [internalNote, setInternalNote] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    fetchDevSupport(token).then((r) => setTickets(r.tickets)).catch(() => {});
  }, []);

  const filtered = tickets.filter((t) => statusFilter === 'all' || t.status === statusFilter);

  const handleSaveTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    const res = await patchDevTicket(token, selected.id, {
      status: selected.status,
      priority: selected.priority,
      reply: reply.trim() || undefined,
      internalNote,
    });
    setTickets(res.tickets);
    const updated = res.tickets.find((x) => x.id === selected.id) || null;
    setSelected(updated);
    setReply('');
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <LifeBuoy className="w-5 h-5 text-blue-500" />
            <span>{isAr ? 'مركز الدعم الفني والشكاوى' : 'Support & Tickets Center'}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'استقبال تذاكر الطلاب، تصنيف الأولوية، وإرسال الردود الفورية.'
              : 'Review student bug reports & billing tickets, triage priority, and reply directly.'}
          </p>
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-1.5 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-xl"
        >
          <option value="all">{isAr ? 'كل الحالات' : 'All Statuses'}</option>
          <option value="open">Open</option>
          <option value="in_progress">In Progress</option>
          <option value="resolved">Resolved</option>
          <option value="closed">Closed</option>
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-6 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 space-y-2 max-h-[520px] overflow-y-auto">
          {filtered.length === 0 ? (
            <p className="text-xs text-slate-500 py-10 text-center">
              {isAr ? 'لا توجد تذاكر دعم فني حالياً.' : 'No support tickets in queue.'}
            </p>
          ) : (
            filtered.map((tkt) => (
              <button
                key={tkt.id}
                onClick={() => {
                  setSelected(tkt);
                  setInternalNote(tkt.internalNote || '');
                  setReply(tkt.reply || '');
                }}
                className={`w-full text-start p-3.5 rounded-xl border transition-colors space-y-1 ${
                  selected?.id === tkt.id
                    ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/30'
                    : 'border-slate-200/70 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-bold text-slate-900 dark:text-white truncate">
                    {tkt.subject}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-mono uppercase">
                    {tkt.priority} · {tkt.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 truncate">
                  {tkt.ownerName} ({tkt.ownerEmail}) · {tkt.category}
                </p>
              </button>
            ))
          )}
        </div>

        <div className="lg:col-span-6 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5">
          {!selected ? (
            <p className="text-xs text-slate-500 py-16 text-center">
              {isAr ? 'اختر تذكرة لعرض التفاصيل والرد عليها.' : 'Select a ticket to inspect and reply.'}
            </p>
          ) : (
            <form onSubmit={handleSaveTicket} className="space-y-3 text-xs">
              <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  {selected.subject}
                </h3>
                <p className="text-slate-500 mt-1">{selected.message}</p>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] text-slate-500 block mb-1">Status</label>
                  <select
                    value={selected.status}
                    onChange={(e) =>
                      setSelected({ ...selected, status: e.target.value as SupportTicket['status'] })
                    }
                    className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="open">Open</option>
                    <option value="in_progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                    <option value="closed">Closed</option>
                  </select>
                </div>
                <div>
                  <label className="text-[11px] text-slate-500 block mb-1">Priority</label>
                  <select
                    value={selected.priority}
                    onChange={(e) =>
                      setSelected({
                        ...selected,
                        priority: e.target.value as SupportTicket['priority'],
                      })
                    }
                    className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">
                  {isAr ? 'الرد المرسل للطالب (يصل كإشعار فوري)' : 'Reply to Student'}
                </label>
                <textarea
                  rows={3}
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">
                  {isAr ? 'ملاحظات داخلية لفريق الدعم' : 'Internal Team Notes'}
                </label>
                <input
                  value={internalNote}
                  onChange={(e) => setInternalNote(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 font-semibold accent-btn-gradient text-white rounded-xl"
              >
                {isAr ? 'حفظ التحديث وإرسال الرد' : 'Update Ticket & Send Reply'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 9. ANALYTICS & REPORTS (CSV / EXCEL CSV / PDF PRINT EXPORT)
// =========================================================================
export const DevAnalyticsSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [data, setData] = useState<DevAnalyticsResponse | null>(null);

  useEffect(() => {
    fetchDevAnalytics(token).then(setData).catch(() => {});
  }, []);

  const exportCsv = (excelBom: boolean) => {
    if (!data) return;
    const rows = [
      ['Metric', 'Value'],
      ['Total Users', String(data.summary.totalUsers)],
      ['Active Users', String(data.summary.activeUsers)],
      ['Retention %', `${data.summary.retentionRatePercent}%`],
      ['Paid Subscriptions', String(data.summary.newSubscriptions)],
      ['Total Revenue USD', String(data.summary.totalRevenue)],
      ['Total AI Cost USD', String(data.summary.totalAiCost)],
      ['Avg Cost Per User USD', String(data.summary.avgCostPerUser)],
      ['Processed Files', String(data.summary.processedFiles)],
      ['Processing Failure Rate %', `${data.summary.processingFailureRate}%`],
      ['', ''],
      ['AI Service', 'Calls', 'Failures', 'Avg Latency (ms)', 'Cost USD'],
      ...data.aiBreakdown.map((s) => [
        s.name,
        String(s.calls),
        String(s.failed),
        String(s.avgLatencyMs),
        String(s.costUsd),
      ]),
    ];
    const csvBody = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n');
    const content = excelBom ? `\uFEFF${csvBody}` : csvBody;
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `smart-student-analytics-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!data) {
    return (
      <div className="p-8 text-center text-xs text-slate-500">
        {isAr ? 'جارٍ تحميل التحليلات...' : 'Loading analytics...'}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-500" />
            <span>{isAr ? 'التحليلات والتقارير والتصدير' : 'Analytics & Exportable Reports'}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'الاحتفاظ بالطلاب، أرباح الاشتراكات، تكلفة الذكاء الاصطناعي، وتصدير CSV / Excel / PDF.'
              : 'Retention, conversion, AI unit economics, and one-click CSV / Excel / PDF reports.'}
          </p>
        </div>

        <div className="no-print flex flex-wrap gap-2">
          <button
            onClick={() => exportCsv(false)}
            className="px-3 py-1.5 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CSV</span>
          </button>
          <button
            onClick={() => exportCsv(true)}
            className="px-3 py-1.5 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" />
            <span>Excel (.csv)</span>
          </button>
          <button
            onClick={() => window.print()}
            className="px-3 py-1.5 text-xs font-semibold accent-btn-gradient text-white rounded-xl flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{isAr ? 'تصدير PDF' : 'Print / PDF'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{isAr ? 'معدل الاحتفاظ' : 'Retention Rate'}</p>
          <p className="text-2xl font-bold tabular-nums">{data.summary.retentionRatePercent}%</p>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{isAr ? 'متوسط التكلفة / طالب' : 'Avg AI Cost / User'}</p>
          <p className="text-2xl font-bold tabular-nums">${data.summary.avgCostPerUser}</p>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{isAr ? 'الملفات المعالجة' : 'Files Processed'}</p>
          <p className="text-2xl font-bold tabular-nums">{data.summary.processedFiles}</p>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{isAr ? 'معدل فشل المعالجة' : 'AI Failure Rate'}</p>
          <p className="text-2xl font-bold tabular-nums">{data.summary.processingFailureRate}%</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-5 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-bold">{isAr ? 'استخدام الميزات' : 'Feature Usage Breakdown'}</h3>
          <FeatureUsageBarChart
            lang={lang}
            items={data.featureBreakdown.slice(0, 10).map((f) => ({
              id: f.id,
              label: isAr ? f.nameAr : f.name,
              count: f.count,
            }))}
          />
        </div>

        <div className="lg:col-span-7 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3 overflow-x-auto">
          <h3 className="text-sm font-bold">{isAr ? 'أداء وتكلفة خدمات الذكاء الاصطناعي' : 'AI Service Economics'}</h3>
          <table className="w-full text-xs">
            <thead className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
              <tr>
                <th className="py-2 text-start">{isAr ? 'الخدمة' : 'Service'}</th>
                <th className="py-2 text-start">{isAr ? 'النموذج' : 'Model'}</th>
                <th className="py-2 text-start">{isAr ? 'الطلبات' : 'Calls'}</th>
                <th className="py-2 text-start">{isAr ? 'الزمن' : 'Latency'}</th>
                <th className="py-2 text-end">{isAr ? 'التكلفة' : 'Cost'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {data.aiBreakdown.map((s) => (
                <tr key={s.id}>
                  <td className="py-2 font-medium">{s.name}</td>
                  <td className="py-2 font-mono text-[11px]">{s.model}</td>
                  <td className="py-2 tabular-nums">
                    {s.calls} ({s.failed} err)
                  </td>
                  <td className="py-2 font-mono tabular-nums">{s.avgLatencyMs}ms</td>
                  <td className="py-2 text-end font-mono tabular-nums">${s.costUsd.toFixed(4)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 10. SYSTEM MONITORING
// =========================================================================
export const DevMonitoringSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [data, setData] = useState<DevMonitoringResponse | null>(null);

  const load = () => {
    fetchDevMonitoring(token).then(setData).catch(() => {});
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 15000);
    return () => clearInterval(id);
  }, []);

  if (!data) {
    return (
      <div className="p-8 text-center text-xs text-slate-500">
        {isAr ? 'جارٍ فحص حالة الخادم...' : 'Probing system telemetry...'}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-500" />
            <span>{isAr ? 'مراقبة النظام والخوادم' : 'System Monitoring'}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'حالة الخوادم، الذاكرة، قواعد البيانات، وأحدث الأخطاء الحقيقية.'
              : 'Live runtime health, memory footprint, storage, and real error stream.'}
          </p>
        </div>
        <button
          onClick={load}
          className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>{isAr ? 'فحص الآن' : 'Probe Now'}</span>
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-slate-500">RSS / Heap</p>
          <p className="text-lg font-bold font-mono tabular-nums">
            {data.system.rssMb} / {data.system.heapUsedMb} MB
          </p>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-slate-500">{isAr ? 'مدة التشغيل' : 'Uptime'}</p>
          <p className="text-lg font-bold font-mono tabular-nums">{data.system.uptimeSeconds}s</p>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-slate-500">{isAr ? 'مساحة التخزين' : 'Store + Backups'}</p>
          <p className="text-lg font-bold font-mono tabular-nums">
            {(data.system.storageUsedBytes / 1024).toFixed(1)} KB
          </p>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-slate-500">{isAr ? 'أخطاء AI المسجلة' : 'AI Errors'}</p>
          <p className="text-lg font-bold font-mono tabular-nums">{data.system.totalAiErrors}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-bold">{isAr ? 'حالة الخدمات' : 'Service Probes'}</h3>
          <div className="space-y-2.5 text-xs">
            {data.services.map((s) => (
              <div
                key={s.name}
                className="p-3 rounded-xl bg-slate-50/70 dark:bg-slate-900/60 flex items-center justify-between gap-3"
              >
                <div>
                  <p className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <CheckCircle2
                      className={`w-3.5 h-3.5 ${
                        s.status === 'healthy' ? 'text-emerald-500' : 'text-amber-500'
                      }`}
                    />
                    <span>{s.name}</span>
                  </p>
                  <p className="text-[11px] text-slate-500">{s.detail}</p>
                </div>
                <span className="font-mono text-[11px] text-slate-500 tabular-nums">
                  {s.latencyMs}ms
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-bold">{isAr ? 'أحدث الأخطاء' : 'Recent Runtime Errors'}</h3>
          {data.recentErrors.length === 0 ? (
            <p className="text-xs text-slate-500 py-10 text-center">
              {isAr ? 'لا توجد أخطاء مسجلة. جميع الخدمات تعمل باستقرار.' : 'No recent errors recorded.'}
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs max-h-64 overflow-y-auto">
              {data.recentErrors.map((err) => (
                <div key={err.id} className="py-2">
                  <p className="font-semibold text-red-600 dark:text-red-400">{err.label}</p>
                  <p className="text-slate-500">{err.detail}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
