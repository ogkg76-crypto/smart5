import React, { useEffect, useState } from 'react';
import {
  AdminAccountPublic,
  AdminRoleType,
  AppSettingsConfig,
  AuditLogEntry,
  BackupSnapshotInfo,
  DevSessionUser,
  Language,
} from '../../types';
import {
  changeDevPassword,
  createDevBackup,
  createDevRoleAccount,
  deleteDevRoleAccount,
  disableDev2fa,
  downloadDevBackupJson,
  fetchDevAuditLogs,
  fetchDevBackups,
  fetchDevRoles,
  fetchDevSettings,
  logoutAllDevDevices,
  restoreDevBackup,
  setupDev2fa,
  simulateAiCost,
  updateDevSettings,
  verifyEnableDev2fa,
} from '../../services/devApi';
import {
  AlertTriangle,
  Calculator,
  DatabaseBackup,
  Download,
  FileClock,
  KeyRound,
  LogOut,
  Plus,
  RotateCcw,
  Settings,
  ShieldCheck,
  Trash2,
  UserCheck,
} from 'lucide-react';

// =========================================================================
// 11. IMMUTABLE AUDIT LOGS
// =========================================================================
export const DevAuditLogsSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    fetchDevAuditLogs(token).then((r) => setLogs(r.auditLogs)).catch(() => {});
  }, []);

  const filtered = logs.filter((l) => {
    const q = filter.trim().toLowerCase();
    return (
      !q ||
      l.actorEmail.toLowerCase().includes(q) ||
      l.action.toLowerCase().includes(q) ||
      l.target.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FileClock className="w-5 h-5 text-blue-500" />
            <span>{isAr ? 'سجل الأمان والعمليات (Audit Logs)' : 'Immutable Audit Logs'}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'سجل زمني غير قابل للتعديل أو الحذف لجميع عمليات الإدارة وتسجيلات الدخول.'
              : 'Append-only immutable trail of logins, plan changes, AI budget updates, and backups.'}
          </p>
        </div>
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder={isAr ? 'تصفية السجل...' : 'Filter audit events...'}
          className="px-3 py-1.5 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-xl"
        />
      </div>

      <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <p className="p-8 text-center text-xs text-slate-500">
            {isAr ? 'لا توجد أحداث مسجلة بعد.' : 'No audit events recorded yet.'}
          </p>
        ) : (
          <div className="overflow-x-auto max-h-[540px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 text-slate-500">
                <tr>
                  <th className="p-3 text-start">{isAr ? 'المسؤول' : 'Actor'}</th>
                  <th className="p-3 text-start">{isAr ? 'العملية' : 'Action'}</th>
                  <th className="p-3 text-start">{isAr ? 'الهدف' : 'Target'}</th>
                  <th className="p-3 text-start">{isAr ? 'التفاصيل' : 'Details'}</th>
                  <th className="p-3 text-end">{isAr ? 'الوقت' : 'Timestamp'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((l) => (
                  <tr key={l.id}>
                    <td className="p-3 font-medium">
                      {l.actorEmail}{' '}
                      <span className="text-[10px] font-mono uppercase text-slate-400">
                        ({l.actorRole})
                      </span>
                    </td>
                    <td className="p-3 font-mono text-blue-600 dark:text-sky-400">{l.action}</td>
                    <td className="p-3 font-mono">{l.target}</td>
                    <td className="p-3 text-slate-500">{l.details}</td>
                    <td className="p-3 text-end font-mono text-[11px] text-slate-400">
                      {new Date(l.createdAt).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

// =========================================================================
// 12. BACKUP & RECOVERY
// =========================================================================
export const DevBackupsSection: React.FC<{
  token: string | null;
  lang: Language;
  isOwner: boolean;
}> = ({ token, lang, isOwner }) => {
  const isAr = lang === 'ar';
  const [backups, setBackups] = useState<BackupSnapshotInfo[]>([]);
  const [confirmRestoreId, setConfirmRestoreId] = useState<string | null>(null);
  const [msg, setMsg] = useState('');

  const load = async () => {
    const res = await fetchDevBackups(token);
    setBackups(res.backups);
  };

  useEffect(() => {
    load().catch(() => {});
  }, []);

  const handleCreate = async () => {
    const res = await createDevBackup(token);
    setMsg(isAr ? `تم إنشاء النسخة الاحتياطية: ${res.id}` : `Created snapshot: ${res.id}`);
    await load();
  };

  const handleRestore = async (id: string) => {
    await restoreDevBackup(token, id);
    setConfirmRestoreId(null);
    setMsg(isAr ? `تم استعادة النظام من النسخة ${id}` : `Restored platform state from ${id}`);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <DatabaseBackup className="w-5 h-5 text-blue-500" />
            <span>{isAr ? 'النسخ الاحتياطي والاستعادة' : 'Backup & Recovery'}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'إنشاء لقطات فورية لقاعدة البيانات والإعدادات، تنزيلها، أو استعادتها بعد تأكيد المالك.'
              : 'Create point-in-time snapshots, export JSON backups, or restore with Owner confirmation.'}
          </p>
        </div>
        <button
          onClick={handleCreate}
          className="px-4 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl flex items-center gap-1.5"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isAr ? 'إنشاء نسخة احتياطية الآن' : 'Create Snapshot Now'}</span>
        </button>
      </div>

      {msg && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {msg}
        </div>
      )}

      <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3">
        {backups.length === 0 ? (
          <p className="text-xs text-slate-500 py-8 text-center">
            {isAr ? 'لا توجد نسخ احتياطية محفوظة حتى الآن.' : 'No snapshots created yet.'}
          </p>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {backups.map((b) => (
              <div key={b.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-mono font-bold text-slate-900 dark:text-white">{b.id}</p>
                  <p className="text-[11px] text-slate-500">
                    {(b.sizeBytes / 1024).toFixed(1)} KB · {new Date(b.createdAt).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => downloadDevBackupJson(token, b.id)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isAr ? 'تنزيل' : 'Download'}</span>
                  </button>
                  {isOwner &&
                    (confirmRestoreId === b.id ? (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleRestore(b.id)}
                          className="px-3 py-1.5 rounded-lg bg-red-600 text-white font-semibold"
                        >
                          {isAr ? 'تأكيد الاستعادة' : 'Confirm Restore'}
                        </button>
                        <button
                          onClick={() => setConfirmRestoreId(null)}
                          className="px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700"
                        >
                          {isAr ? 'إلغاء' : 'Cancel'}
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmRestoreId(b.id)}
                        className="px-3 py-1.5 rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 flex items-center gap-1"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>{isAr ? 'استعادة' : 'Restore'}</span>
                      </button>
                    ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// =========================================================================
// 13. AI COST SIMULATOR
// =========================================================================
export const DevCostSimulatorSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [expectedUsers, setExpectedUsers] = useState(2500);
  const [requestsPerUserPerDay, setRequestsPerUserPerDay] = useState(5);
  const [model, setModel] = useState('gemini-4-hydrogen');
  const [serviceType, setServiceType] = useState('lectureExplanation');
  const [avgFileSizeMb, setAvgFileSizeMb] = useState(4);
  const [result, setResult] = useState<{
    dailyRequests: number;
    monthlyRequests: number;
    costPerRequestUsd: number;
    dailyCostUsd: number;
    monthlyCostUsd: number;
    costPerUserMonthlyUsd: number;
  } | null>(null);

  const runSim = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const res = await simulateAiCost(token, {
      expectedUsers,
      requestsPerUserPerDay,
      model,
      serviceType,
      avgFileSizeMb,
    });
    setResult(res);
  };

  useEffect(() => {
    runSim().catch(() => {});
  }, []);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Calculator className="w-5 h-5 text-violet-500" />
          <span>{isAr ? 'محاكي تكاليف الذكاء الاصطناعي' : 'AI Cost Simulator'}</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {isAr
            ? 'احسب التكلفة اليومية والشهرية المتوقعة قبل طرح أي باقة أو تحديث نموذج.'
            : 'Forecast daily & monthly AI expenditure across user scale, models, and file sizes.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <form
          onSubmit={runSim}
          className="lg:col-span-5 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3 text-xs"
        >
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">
              {isAr ? 'عدد المستخدمين المتوقع' : 'Expected Active Students'}
            </label>
            <input
              type="number"
              min={1}
              value={expectedUsers}
              onChange={(e) => setExpectedUsers(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
            />
          </div>
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">
              {isAr ? 'عدد الطلبات لكل طالب يومياً' : 'Requests / Student / Day'}
            </label>
            <input
              type="number"
              step="0.5"
              min={0.5}
              value={requestsPerUserPerDay}
              onChange={(e) => setRequestsPerUserPerDay(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
            />
          </div>
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'النموذج' : 'AI Model'}</label>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
            >
              <option value="gemini-4-hydrogen">gemini-4-hydrogen</option>
              <option value="gemini-3.5-transcribe">gemini-3.5-transcribe</option>
              <option value="gemini-3.8-flash-lite-tts">gemini-3.8-flash-lite-tts</option>
              <option value="gemini-3.8-flash-tts">gemini-3.8-flash-tts</option>
            </select>
          </div>
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'نوع الخدمة' : 'Service Type'}</label>
            <select
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            >
              <option value="lectureExplanation">Lecture Explanation</option>
              <option value="summarization">Summarization</option>
              <option value="exams">Exams & Prediction</option>
              <option value="chat">AI Tutor Chat</option>
              <option value="voiceTutor">Voice & Podcast TTS</option>
              <option value="imageSolver">Camera / Whiteboard Solver</option>
              <option value="videoGeneration">Video Analysis</option>
            </select>
          </div>
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">
              {isAr ? 'متوسط حجم الملف (MB)' : 'Average Lecture Size (MB)'}
            </label>
            <input
              type="number"
              step="0.5"
              min={0.5}
              value={avgFileSizeMb}
              onChange={(e) => setAvgFileSizeMb(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
            />
          </div>
          <button
            type="submit"
            className="w-full py-2.5 font-semibold accent-btn-gradient text-white rounded-xl"
          >
            {isAr ? 'احسب التكلفة المتوقعة' : 'Simulate Cost'}
          </button>
        </form>

        <div className="lg:col-span-7 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 grid grid-cols-1 sm:grid-cols-2 gap-4 content-start">
          {result && (
            <>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                <p className="text-xs text-slate-500">{isAr ? 'التكلفة اليومية المتوقعة' : 'Estimated Daily Cost'}</p>
                <p className="text-2xl font-bold text-blue-600 dark:text-sky-400 font-mono tabular-nums mt-1">
                  ${result.dailyCostUsd.toFixed(2)}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                <p className="text-xs text-slate-500">{isAr ? 'التكلفة الشهرية المتوقعة' : 'Estimated Monthly Cost'}</p>
                <p className="text-2xl font-bold text-violet-600 dark:text-violet-400 font-mono tabular-nums mt-1">
                  ${result.monthlyCostUsd.toFixed(2)}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                <p className="text-xs text-slate-500">{isAr ? 'التكلفة الشهرية لكل طالب' : 'Cost / Student / Month'}</p>
                <p className="text-xl font-bold font-mono tabular-nums mt-1">
                  ${result.costPerUserMonthlyUsd.toFixed(2)}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                <p className="text-xs text-slate-500">{isAr ? 'الطلبات الشهرية' : 'Monthly Requests'}</p>
                <p className="text-xl font-bold font-mono tabular-nums mt-1">
                  {result.monthlyRequests.toLocaleString()}
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 14. APP SETTINGS
// =========================================================================
export const DevAppSettingsSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [settings, setSettings] = useState<AppSettingsConfig | null>(null);
  const [saved, setSaved] = useState('');

  useEffect(() => {
    fetchDevSettings(token).then((r) => setSettings(r.appSettings)).catch(() => {});
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    const res = await updateDevSettings(token, settings);
    setSettings(res.appSettings);
    setSaved(isAr ? 'تم حفظ إعدادات التطبيق العامة وتطبيقها فوراً.' : 'Global app settings saved & synced.');
  };

  if (!settings) {
    return (
      <div className="p-8 text-center text-xs text-slate-500">
        {isAr ? 'جارٍ تحميل الإعدادات...' : 'Loading settings...'}
      </div>
    );
  }

  return (
    <form onSubmit={handleSave} className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-500" />
            <span>{isAr ? 'إعدادات التطبيق العامة' : 'Global App Settings'}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'اسم التطبيق، وضع الصيانة العام، الحد الأقصى للملفات، التحديث الإجباري، والخصوصية.'
              : 'Branding, global maintenance mode, upload cap, min version policy, and legal policies.'}
          </p>
        </div>
        <button
          type="submit"
          className="px-5 py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl"
        >
          {isAr ? 'حفظ الإعدادات' : 'Save Settings'}
        </button>
      </div>

      {saved && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {saved}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 text-xs">
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between p-3 rounded-xl bg-amber-500/10 border border-amber-500/30">
            <div>
              <p className="font-bold text-amber-700 dark:text-amber-300">
                {isAr ? 'وضع الصيانة الشامل (Maintenance Mode)' : 'Global Maintenance Mode'}
              </p>
              <p className="text-[11px] text-slate-500">
                {isAr
                  ? 'يوقف وصول الطلاب للتطبيق مؤقتاً ويعرض رسالة الصيانة.'
                  : 'Pauses student access globally while Owner dashboard stays live.'}
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.maintenanceMode}
              onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked })}
              className="w-4 h-4"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'اسم التطبيق' : 'App Name'}</label>
              <input
                value={settings.appName}
                onChange={(e) => setSettings({ ...settings, appName: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'البريد الرسمي' : 'Support Email'}</label>
              <input
                value={settings.officialEmail}
                onChange={(e) => setSettings({ ...settings, officialEmail: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'أقصى حجم ملف (MB)' : 'Max Upload (MB)'}</label>
              <input
                type="number"
                value={settings.maxFileSizeMb}
                onChange={(e) => setSettings({ ...settings, maxFileSizeMb: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'أقل إصدار مطلوب' : 'Min App Version'}</label>
              <input
                value={settings.minVersion}
                onChange={(e) => setSettings({ ...settings, minVersion: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'رسالة التحديث الإجباري' : 'Force Update Notice'}</label>
            <input
              value={settings.forceUpdateMessage}
              onChange={(e) => setSettings({ ...settings, forceUpdateMessage: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>
        </div>

        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3">
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'سياسة الخصوصية' : 'Privacy Policy'}</label>
            <textarea
              rows={4}
              value={settings.privacyPolicyText}
              onChange={(e) => setSettings({ ...settings, privacyPolicyText: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">{isAr ? 'شروط الاستخدام' : 'Terms of Service'}</label>
            <textarea
              rows={4}
              value={settings.termsOfServiceText}
              onChange={(e) => setSettings({ ...settings, termsOfServiceText: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>
        </div>
      </div>
    </form>
  );
};

// =========================================================================
// 15. DEVELOPER PROFILE, 2FA SECURITY, LOGOUT ALL DEVICES & ADMIN ROLES RBAC
// =========================================================================
export const DevProfileSecuritySection: React.FC<{
  token: string | null;
  devUser: DevSessionUser;
  lang: Language;
  onSessionUpdated: (token: string, user: DevSessionUser) => void;
  onForceRelogin: () => void;
}> = ({ token, devUser, lang, onSessionUpdated, onForceRelogin }) => {
  const isAr = lang === 'ar';
  const isOwner = devUser.role === 'owner';

  const [currPass, setCurrPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const [passErr, setPassErr] = useState('');

  // 2FA state
  const [totpSetupSecret, setTotpSetupSecret] = useState('');
  const [totpSetupUri, setTotpSetupUri] = useState('');
  const [totpCodeInput, setTotpCodeInput] = useState('');
  const [twoFaMsg, setTwoFaMsg] = useState('');

  // Admin roles RBAC state
  const [roles, setRoles] = useState<AdminAccountPublic[]>([]);
  const [newRoleEmail, setNewRoleEmail] = useState('');
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleType, setNewRoleType] = useState<Exclude<AdminRoleType, 'owner'>>('support');
  const [newRolePassword, setNewRolePassword] = useState('');

  useEffect(() => {
    fetchDevRoles(token).then((r) => setRoles(r.accounts)).catch(() => {});
  }, []);

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassErr('');
    setPassMsg('');
    try {
      const res = await changeDevPassword(token, currPass, newPass);
      onSessionUpdated(res.token, res.user);
      setCurrPass('');
      setNewPass('');
      setPassMsg(
        isAr
          ? 'تم تغيير كلمة المرور وتجديد جميع الجلسات بنجاح.'
          : 'Password updated and all other active sessions rotated.'
      );
    } catch (err) {
      setPassErr(err instanceof Error ? err.message : 'Password update failed');
    }
  };

  const handleStart2fa = async () => {
    const res = await setupDev2fa(token);
    setTotpSetupSecret(res.secret);
    setTotpSetupUri(res.otpauthUri);
    setTwoFaMsg('');
  };

  const handleEnable2fa = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await verifyEnableDev2fa(token, totpCodeInput);
    onSessionUpdated(token || '', res.user);
    setTotpSetupSecret('');
    setTotpSetupUri('');
    setTotpCodeInput('');
    setTwoFaMsg(isAr ? 'تم تفعيل التحقق بخطوتين (2FA) لحسابك.' : 'Two-Factor Authentication enabled.');
  };

  const handleDisable2fa = async () => {
    const res = await disableDev2fa(token);
    onSessionUpdated(token || '', res.user);
    setTwoFaMsg(isAr ? 'تم إيقاف التحقق بخطوتين.' : '2FA disabled.');
  };

  const handleLogoutAll = async () => {
    await logoutAllDevDevices(token);
    onForceRelogin();
  };

  const handleCreateRole = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoleEmail.trim() || !newRolePassword) return;
    const res = await createDevRoleAccount(token, {
      email: newRoleEmail.trim(),
      displayName: newRoleName.trim() || newRoleEmail.trim(),
      role: newRoleType,
      password: newRolePassword,
    });
    setRoles(res.accounts);
    setNewRoleEmail('');
    setNewRoleName('');
    setNewRolePassword('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <UserCheck className="w-5 h-5 text-blue-500" />
          <span>{isAr ? 'حساب المطور والأمان والصلاحيات (RBAC)' : 'Developer Profile, Security & Roles'}</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {devUser.email} · {isAr ? 'الدور:' : 'Role:'}{' '}
          <span className="uppercase font-mono font-bold text-blue-600 dark:text-sky-400">
            {devUser.role}
          </span>
        </p>
      </div>

      {devUser.mustChangePassword && (
        <div className="p-4 rounded-2xl bg-amber-500/15 border border-amber-500/40 flex items-center gap-3 text-xs text-amber-700 dark:text-amber-300">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <span>
            {isAr
              ? 'متطلب أمان إلزامي: يرجى تغيير كلمة المرور الأولية الآن لتأمين لوحة تحكم المطور.'
              : 'Mandatory first-login security action: please update your initial password below.'}
          </span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Password Change */}
        <form
          onSubmit={handlePasswordChange}
          className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3 text-xs"
        >
          <h3 className="text-sm font-bold flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-blue-500" />
            <span>{isAr ? 'تغيير كلمة المرور' : 'Change Password'}</span>
          </h3>
          {passErr && (
            <p className="p-2.5 rounded-lg bg-red-500/15 text-red-600 dark:text-red-300">{passErr}</p>
          )}
          {passMsg && (
            <p className="p-2.5 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-300">
              {passMsg}
            </p>
          )}
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">
              {isAr ? 'كلمة المرور الحالية' : 'Current Password'}
            </label>
            <input
              type="password"
              required
              value={currPass}
              onChange={(e) => setCurrPass(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>
          <div>
            <label className="text-[11px] text-slate-500 block mb-1">
              {isAr ? 'كلمة المرور الجديدة (8 أحرف فأكثر)' : 'New Password (8+ chars)'}
            </label>
            <input
              type="password"
              required
              minLength={8}
              value={newPass}
              onChange={(e) => setNewPass(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>
          <button
            type="submit"
            className="w-full py-2.5 font-semibold accent-btn-gradient text-white rounded-xl"
          >
            {isAr ? 'تحديث كلمة المرور' : 'Update Password'}
          </button>
        </form>

        {/* 2FA & Logout All Devices */}
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>{isAr ? 'التحقق بخطوتين (2FA TOTP)' : 'Two-Factor Authentication (2FA)'}</span>
            </h3>
            <span
              className={`px-2 py-0.5 rounded font-mono text-[11px] ${
                devUser.twoFactorEnabled
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
              }`}
            >
              {devUser.twoFactorEnabled ? (isAr ? 'مفعّل' : 'Enabled') : isAr ? 'غير مفعّل' : 'Off'}
            </span>
          </div>

          {twoFaMsg && (
            <p className="p-2.5 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-300">
              {twoFaMsg}
            </p>
          )}

          {!devUser.twoFactorEnabled && !totpSetupSecret && (
            <button
              onClick={handleStart2fa}
              className="px-4 py-2 rounded-xl bg-blue-600 text-white font-semibold"
            >
              {isAr ? 'إعداد تطبيق المصادقة (Google Authenticator)' : 'Enable TOTP 2FA'}
            </button>
          )}

          {totpSetupSecret && (
            <form onSubmit={handleEnable2fa} className="space-y-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60">
              <p className="text-[11px] text-slate-500">
                {isAr
                  ? 'أضف هذا المفتاح السري داخل تطبيق Google Authenticator ثم أدخل الرمز المكون من 6 أرقام:'
                  : 'Add this Secret Key in Google Authenticator / Authy, then enter the 6-digit code:'}
              </p>
              <p className="p-2 rounded bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 font-mono select-all text-center">
                {totpSetupSecret}
              </p>
              <p className="text-[10px] font-mono break-all text-slate-400">{totpSetupUri}</p>
              <div className="flex gap-2">
                <input
                  value={totpCodeInput}
                  onChange={(e) => setTotpCodeInput(e.target.value)}
                  placeholder="123456"
                  maxLength={6}
                  className="flex-1 px-3 py-1.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono text-center"
                />
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold"
                >
                  {isAr ? 'تأكيد وتفعيل' : 'Verify & Enable'}
                </button>
              </div>
            </form>
          )}

          {devUser.twoFactorEnabled && (
            <button
              onClick={handleDisable2fa}
              className="px-4 py-2 rounded-xl border border-red-300 text-red-600 dark:text-red-400"
            >
              {isAr ? 'تعطيل 2FA' : 'Disable 2FA'}
            </button>
          )}

          <div className="border-t border-slate-200 dark:border-slate-800 pt-3 flex items-center justify-between">
            <span className="text-slate-500">
              {isAr ? 'إنهاء جميع الجلسات المفتوحة على كل الأجهزة' : 'Revoke all active sessions'}
            </span>
            <button
              onClick={handleLogoutAll}
              className="px-3.5 py-2 rounded-xl bg-red-600 text-white font-semibold flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{isAr ? 'تسجيل الخروج من كل الأجهزة' : 'Logout All Devices'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Admin Team Roles RBAC */}
      {isOwner && (
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
          <h3 className="text-sm font-bold">
            {isAr ? 'إدارة أدوار الفريق (Owner · Admin · Support · Content Manager)' : 'Team Roles & RBAC'}
          </h3>

          <form onSubmit={handleCreateRole} className="grid grid-cols-1 sm:grid-cols-5 gap-2">
            <input
              type="email"
              required
              value={newRoleEmail}
              onChange={(e) => setNewRoleEmail(e.target.value)}
              placeholder={isAr ? 'بريد المشرف' : 'Team member email'}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
            <input
              value={newRoleName}
              onChange={(e) => setNewRoleName(e.target.value)}
              placeholder={isAr ? 'الاسم' : 'Display name'}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
            <select
              value={newRoleType}
              onChange={(e) =>
                setNewRoleType(e.target.value as Exclude<AdminRoleType, 'owner'>)
              }
              className="px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            >
              <option value="admin">Admin</option>
              <option value="support">Support</option>
              <option value="content_manager">Content Manager</option>
            </select>
            <input
              type="password"
              required
              minLength={8}
              value={newRolePassword}
              onChange={(e) => setNewRolePassword(e.target.value)}
              placeholder={isAr ? 'كلمة مرور مبدئية' : 'Initial password'}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
            <button
              type="submit"
              className="px-4 py-2 font-semibold accent-btn-gradient text-white rounded-xl"
            >
              {isAr ? 'إضافة مشرف' : 'Add Admin'}
            </button>
          </form>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {roles.map((acc) => (
              <div key={acc.id} className="py-2.5 flex items-center justify-between gap-2">
                <div>
                  <p className="font-semibold text-slate-900 dark:text-white">
                    {acc.displayName} ({acc.email})
                  </p>
                  <p className="text-[11px] font-mono text-slate-500 uppercase">
                    {acc.role} · 2FA: {acc.twoFactorEnabled ? 'ON' : 'OFF'}
                  </p>
                </div>
                {acc.role !== 'owner' && (
                  <button
                    onClick={async () => {
                      const res = await deleteDevRoleAccount(token, acc.id);
                      setRoles(res.accounts);
                    }}
                    className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
