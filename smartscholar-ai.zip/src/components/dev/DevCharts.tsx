import React, { useState } from 'react';
import { Language } from '../../types';

interface SeriesPoint {
  date: string;
  users: number;
  revenue: number;
  aiCost: number;
  aiCalls: number;
}

export const GrowthAreaChart: React.FC<{
  data: SeriesPoint[];
  lang: Language;
  metric: 'users' | 'aiCalls' | 'revenue' | 'aiCost';
  color?: string;
  label: string;
}> = ({ data, lang, metric, color = '#3b82f6', label }) => {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const isAr = lang === 'ar';

  if (!data.length) {
    return (
      <div className="h-52 flex items-center justify-center text-xs text-slate-500">
        {isAr ? 'لا توجد بيانات زمنية مسجلة بعد' : 'No time-series events recorded yet'}
      </div>
    );
  }

  const w = 520;
  const h = 180;
  const padX = 28;
  const padY = 20;
  const values = data.map((d) => Number(d[metric] || 0));
  const maxVal = Math.max(1, ...values);

  const points = data.map((d, idx) => {
    const x =
      data.length === 1
        ? w / 2
        : padX + (idx / (data.length - 1)) * (w - padX * 2);
    const y = h - padY - ((Number(d[metric] || 0) / maxVal) * (h - padY * 2));
    return { x, y, raw: d, val: Number(d[metric] || 0) };
  });

  const linePath = points
    .map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
    .join(' ');
  const areaPath = `${linePath} L ${points[points.length - 1].x.toFixed(1)} ${h - padY} L ${points[0].x.toFixed(1)} ${h - padY} Z`;

  const gradId = `grad_${metric}_${color.replace('#', '')}`;
  const activePoint = hoverIdx !== null ? points[hoverIdx] : points[points.length - 1];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2 text-xs">
        <span className="font-semibold text-slate-700 dark:text-slate-200">{label}</span>
        {activePoint && (
          <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 font-mono tabular-nums">
            {activePoint.raw.date}:{' '}
            {metric === 'revenue' || metric === 'aiCost'
              ? `$${activePoint.val.toFixed(metric === 'aiCost' ? 3 : 2)}`
              : activePoint.val}
          </span>
        )}
      </div>
      <svg
        viewBox={`0 0 ${w} ${h}`}
        className="w-full h-44 overflow-visible"
        onMouseLeave={() => setHoverIdx(null)}
      >
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.32" />
            <stop offset="100%" stopColor={color} stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75, 1].map((frac) => {
          const y = h - padY - frac * (h - padY * 2);
          return (
            <line
              key={frac}
              x1={padX}
              x2={w - padX}
              y1={y}
              y2={y}
              stroke="currentColor"
              className="text-slate-200 dark:text-slate-800"
              strokeDasharray="3 3"
            />
          );
        })}
        <path d={areaPath} fill={`url(#${gradId})`} />
        <path d={linePath} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p, idx) => (
          <g key={p.raw.date} onMouseEnter={() => setHoverIdx(idx)} className="cursor-pointer">
            <circle cx={p.x} cy={p.y} r="10" fill="transparent" />
            <circle
              cx={p.x}
              cy={p.y}
              r={hoverIdx === idx ? 5 : 3}
              fill={color}
              stroke="#fff"
              strokeWidth="1.5"
            />
            {(idx === 0 || idx === points.length - 1 || idx % 3 === 0) && (
              <text
                x={p.x}
                y={h - 4}
                textAnchor="middle"
                className="fill-slate-400 text-[9px] font-mono"
              >
                {p.raw.date}
              </text>
            )}
          </g>
        ))}
      </svg>
    </div>
  );
};

export const RevenueCostComparisonChart: React.FC<{
  data: SeriesPoint[];
  lang: Language;
}> = ({ data, lang }) => {
  const isAr = lang === 'ar';
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const maxVal = Math.max(
    1,
    ...data.map((d) => Math.max(Number(d.revenue || 0), Number(d.aiCost || 0)))
  );

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="font-semibold text-slate-700 dark:text-slate-200">
          {isAr ? 'مقارنة الإيرادات وتكلفة الذكاء الاصطناعي' : 'Revenue vs AI Cost Comparison'}
        </span>
        <div className="flex items-center gap-3 text-[11px]">
          <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
            <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500" />
            {isAr ? 'الإيرادات ($)' : 'Revenue ($)'}
          </span>
          <span className="inline-flex items-center gap-1.5 text-violet-600 dark:text-violet-400">
            <span className="w-2.5 h-2.5 rounded-xs bg-violet-500" />
            {isAr ? 'تكلفة AI ($)' : 'AI Cost ($)'}
          </span>
        </div>
      </div>

      <div className="h-44 flex items-end gap-1.5 pt-4 border-b border-slate-200 dark:border-slate-800 pb-1">
        {data.map((d, idx) => {
          const revH = Math.max(4, Math.round((d.revenue / maxVal) * 128));
          const costH = Math.max(4, Math.round((d.aiCost / maxVal) * 128));
          return (
            <div
              key={d.date}
              onMouseEnter={() => setHoverIdx(idx)}
              onMouseLeave={() => setHoverIdx(null)}
              className="flex-1 flex flex-col items-center justify-end gap-1 group relative"
            >
              {hoverIdx === idx && (
                <div className="absolute -top-9 z-10 px-2 py-1 rounded-lg bg-slate-900 text-white text-[10px] font-mono whitespace-nowrap shadow-lg">
                  +${d.revenue.toFixed(2)} / -${d.aiCost.toFixed(3)}
                </div>
              )}
              <div className="w-full flex items-end justify-center gap-0.5">
                <div
                  style={{ height: `${revH}px` }}
                  className="w-2 sm:w-3 rounded-t bg-emerald-500/85 group-hover:bg-emerald-400 transition-all"
                />
                <div
                  style={{ height: `${costH}px` }}
                  className="w-2 sm:w-3 rounded-t bg-violet-500/85 group-hover:bg-violet-400 transition-all"
                />
              </div>
              <span className="text-[9px] text-slate-400 font-mono truncate max-w-full">
                {d.date}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const FeatureUsageBarChart: React.FC<{
  items: { id: string; label: string; count: number }[];
  lang: Language;
}> = ({ items, lang }) => {
  const isAr = lang === 'ar';
  const max = Math.max(1, ...items.map((i) => i.count));
  if (!items.length) {
    return (
      <p className="text-xs text-slate-500 py-8 text-center">
        {isAr ? 'لا توجد إحصائيات استخدام بعد.' : 'No feature telemetry recorded yet.'}
      </p>
    );
  }
  return (
    <div className="space-y-2.5">
      {items.map((item) => {
        const pct = Math.max(4, Math.round((item.count / max) * 100));
        return (
          <div key={item.id} className="space-y-1">
            <div className="flex items-center justify-between text-xs gap-2">
              <span className="font-medium text-slate-700 dark:text-slate-300 truncate">
                {item.label}
              </span>
              <span className="font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                {item.count}
              </span>
            </div>
            <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800/80 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-600 to-violet-600 transition-all duration-300"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};
