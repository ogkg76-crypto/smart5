import React, { useEffect, useState } from 'react';
import {
  AiServiceConfig,
  ControlPaymentRecord,
  ControlPlanConfig,
  ControlPromoConfig,
  ControlUserRecord,
  FeatureFlagConfig,
  Language,
} from '../../types';
import {
  DevOverviewResponse,
  deleteDevPromo,
  fetchDevAiServices,
  fetchDevFeatures,
  fetchDevOverview,
  fetchDevSubscriptions,
  fetchDevUsers,
  notifyDevUser,
  patchDevPayment,
  patchDevUser,
  saveDevPlan,
  saveDevPromo,
  updateDevAiService,
  updateDevFeature,
} from '../../services/devApi';
import {
  FeatureUsageBarChart,
  GrowthAreaChart,
  RevenueCostComparisonChart,
} from './DevCharts';
import {
  Activity,
  Ban,
  CheckCircle2,
  Cpu,
  CreditCard,
  DollarSign,
  Eye,
  Gift,
  Plus,
  RefreshCw,
  Search,
  Send,
  Server,
  Sliders,
  Ticket,
  Trash2,
  Users,
  Zap,
} from 'lucide-react';

// =========================================================================
// 1. OVERVIEW DASHBOARD SECTION
// =========================================================================
export const DevOverviewSection: React.FC<{
  token: string | null;
  lang: Language;
  onJumpSection: (sec: 'users' | 'ai_control' | 'support' | 'monitoring') => void;
}> = ({ token, lang, onJumpSection }) => {
  const isAr = lang === 'ar';
  const [range, setRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');
  const [data, setData] = useState<DevOverviewResponse | null>(null);
  const [metricTab, setMetricTab] = useState<'aiCalls' | 'users' | 'revenue' | 'aiCost'>('aiCalls');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = async (r = range) => {
    setLoading(true);
    setError('');
    try {
      const res = await fetchDevOverview(token, r);
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load overview');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(range);
  }, [range]);

  if (loading && !data) {
    return (
      <div className="p-8 text-center text-sm text-slate-500">
        {isAr ? 'جارٍ تحميل نظرة النظام...' : 'Loading system overview...'}
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-xs text-red-600 dark:text-red-300">
        {error}
      </div>
    );
  }

  const kpis = data!.kpis;
  const kpiCards = [
    {
      label: isAr ? 'إجمالي الطلاب' : 'Total Students',
      value: kpis.totalUsers,
      sub: isAr ? `${kpis.activeUsers} نشط` : `${kpis.activeUsers} active`,
    },
    {
      label: isAr ? 'مستخدمون جدد اليوم' : 'New Today',
      value: kpis.newUsersToday,
      sub: isAr ? 'مسجلون جدد' : 'Signups today',
    },
    {
      label: isAr ? 'الاشتراكات المدفوعة' : 'Paid Subscriptions',
      value: kpis.totalSubscriptions,
      sub: `Pro: ${kpis.proCount} · Elite: ${kpis.eliteCount}`,
    },
    {
      label: isAr ? 'إجمالي الإيرادات' : 'Total Revenue',
      value: `$${kpis.totalRevenue.toFixed(2)}`,
      sub: isAr ? `تذاكر مفتوحة: ${kpis.openTickets}` : `Open tickets: ${kpis.openTickets}`,
    },
    {
      label: isAr ? 'تكلفة الذكاء الاصطناعي' : 'AI Cost (Est.)',
      value: `$${kpis.totalAiCost.toFixed(3)}`,
      sub: isAr ? `${kpis.aiRequestsCount} طلب` : `${kpis.aiRequestsCount} requests`,
    },
    {
      label: isAr ? 'المحاضرات والملخصات' : 'Lectures & Summaries',
      value: kpis.lecturesUploaded,
      sub: isAr ? `${kpis.summariesCount} ملخص ذكي` : `${kpis.summariesCount} summaries`,
    },
    {
      label: isAr ? 'الامتحانات والأسئلة' : 'Exams Generated',
      value: kpis.examsCreated,
      sub: isAr ? `~${kpis.questionsGenerated} سؤال` : `~${kpis.questionsGenerated} Qs`,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            {isAr ? 'نظرة عامة على النظام' : 'Platform Overview'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'مؤشرات الأداء الحية، استخدام الذكاء الاصطناعي، وحالة الخادم.'
              : 'Live operational KPIs, AI telemetry, and infrastructure status.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {(['7d', '30d', '90d', 'all'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                range === r
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {r === 'all' ? (isAr ? 'الكل' : 'All') : r}
            </button>
          ))}
          <button
            onClick={() => load(range)}
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
            title={isAr ? 'تحديث' : 'Refresh'}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Live Server Health Ribbon */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Server className="w-4 h-4 text-emerald-500" />
            <span className="text-xs font-medium">{isAr ? 'حالة الخادم' : 'Backend API'}</span>
          </div>
          <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
            {data!.serverHealth.api} · {data!.serverHealth.uptimeSeconds}s
          </span>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Cpu className="w-4 h-4 text-blue-500" />
            <span className="text-xs font-medium">Gemini Gateway</span>
          </div>
          <span
            className={`text-xs font-semibold ${
              data!.serverHealth.geminiConfigured ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-500'
            }`}
          >
            {data!.serverHealth.geminiConfigured ? (isAr ? 'متصل' : 'Connected') : 'Missing Key'}
          </span>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Activity className="w-4 h-4 text-violet-500" />
            <span className="text-xs font-medium">{isAr ? 'وضع الصيانة' : 'Maintenance'}</span>
          </div>
          <span
            className={`text-xs font-semibold ${
              data!.serverHealth.maintenanceMode ? 'text-amber-500' : 'text-emerald-600 dark:text-emerald-400'
            }`}
          >
            {data!.serverHealth.maintenanceMode ? (isAr ? 'مفعّل' : 'Active') : isAr ? 'متاح للطلاب' : 'Live'}
          </span>
        </div>
        <div className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
          <button
            onClick={() => onJumpSection('monitoring')}
            className="text-xs font-semibold text-blue-600 dark:text-sky-400 hover:underline"
          >
            {isAr ? 'فحص المراقبة التفصيلية ←' : 'Open System Monitor ->'}
          </button>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3">
        {kpiCards.map((card) => (
          <div
            key={card.label}
            className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 space-y-1.5"
          >
            <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate">
              {card.label}
            </p>
            <p className="text-xl font-bold text-slate-900 dark:text-white tabular-nums">
              {card.value}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">{card.sub}</p>
          </div>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-6 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                { id: 'aiCalls', ar: 'طلبات AI', en: 'AI Calls' },
                { id: 'users', ar: 'نمو الطلاب', en: 'Signups' },
                { id: 'revenue', ar: 'الإيرادات', en: 'Revenue' },
                { id: 'aiCost', ar: 'تكلفة AI', en: 'AI Cost' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setMetricTab(tab.id)}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  metricTab === tab.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {isAr ? tab.ar : tab.en}
              </button>
            ))}
          </div>
          <GrowthAreaChart
            data={data!.charts.series}
            lang={lang}
            metric={metricTab}
            color={metricTab === 'revenue' ? '#10b981' : metricTab === 'aiCost' ? '#8b5cf6' : '#3b82f6'}
            label={
              metricTab === 'aiCalls'
                ? isAr
                  ? 'نشاط الذكاء الاصطناعي اليومي'
                  : 'Daily AI Requests'
                : metricTab === 'users'
                  ? isAr
                    ? 'تسجيلات الطلاب'
                    : 'Student Growth'
                  : metricTab === 'revenue'
                    ? isAr
                      ? 'تدفق الإيرادات'
                      : 'Revenue Trend'
                    : isAr
                      ? 'استهلاك الميزانية'
                      : 'AI Cost Trend'
            }
          />
        </div>

        <div className="lg:col-span-6 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5">
          <RevenueCostComparisonChart data={data!.charts.series} lang={lang} />
        </div>
      </div>

      {/* Top Features & Live Activity Center */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-5 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {isAr ? 'أكثر الميزات استخداماً' : 'Most Used Features'}
            </h3>
            <button
              onClick={() => onJumpSection('ai_control')}
              className="text-xs text-blue-600 dark:text-sky-400 hover:underline"
            >
              {isAr ? 'تحكم AI' : 'AI Control'}
            </button>
          </div>
          <FeatureUsageBarChart
            lang={lang}
            items={data!.charts.topFeatures.map((f) => ({
              id: f.id,
              label: isAr ? f.nameAr : f.nameEn,
              count: f.count,
            }))}
          />
        </div>

        <div className="lg:col-span-7 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {isAr ? 'مركز النشاط الحي (Activity Center)' : 'Live Activity Center'}
            </h3>
            <div className="flex gap-2">
              <button
                onClick={() => onJumpSection('users')}
                className="text-xs text-blue-600 dark:text-sky-400 hover:underline"
              >
                {isAr ? 'المستخدمون' : 'Users'}
              </button>
              <button
                onClick={() => onJumpSection('support')}
                className="text-xs text-blue-600 dark:text-sky-400 hover:underline"
              >
                {isAr ? 'الدعم' : 'Support'}
              </button>
            </div>
          </div>

          {data!.activityFeed.length === 0 ? (
            <p className="text-xs text-slate-500 py-8 text-center">
              {isAr
                ? 'لا توجد أحداث حية بعد. ستظهر هنا فور تسجيل دخول الطلاب أو تنفيذ طلبات AI.'
                : 'No live telemetry yet. Events stream here as students sign in and run AI tasks.'}
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-72 overflow-y-auto">
              {data!.activityFeed.map((ev) => (
                <div key={ev.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div className="min-w-0">
                    <p className="font-semibold text-slate-800 dark:text-slate-100 truncate">
                      {ev.label}
                    </p>
                    <p className="text-slate-500 truncate">{ev.detail}</p>
                  </div>
                  <div className="text-end shrink-0 font-mono text-[11px] text-slate-400 tabular-nums">
                    {ev.latencyMs ? `${ev.latencyMs}ms · ` : ''}
                    {new Date(ev.createdAt).toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 2. USERS MANAGEMENT SECTION
// =========================================================================
export const DevUsersSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [users, setUsers] = useState<ControlUserRecord[]>([]);
  const [query, setQuery] = useState('');
  const [planFilter, setPlanFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selected, setSelected] = useState<ControlUserRecord | null>(null);
  const [notifTitle, setNotifTitle] = useState('');
  const [notifBody, setNotifBody] = useState('');
  const [busyUid, setBusyUid] = useState('');
  const [msg, setMsg] = useState('');

  const load = async () => {
    const res = await fetchDevUsers(token);
    setUsers(res.users);
    if (selected) {
      const updated = res.users.find((u) => u.uid === selected.uid) || null;
      setSelected(updated);
    }
  };

  useEffect(() => {
    load().catch(() => {});
  }, []);

  const filtered = users.filter((u) => {
    const q = query.trim().toLowerCase();
    const matchQ =
      !q ||
      u.displayName.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.uid.toLowerCase().includes(q);
    const matchPlan = planFilter === 'all' || u.planId === planFilter;
    const matchStatus = statusFilter === 'all' || u.status === statusFilter;
    return matchQ && matchPlan && matchStatus;
  });

  const handlePatch = async (
    uid: string,
    payload: Parameters<typeof patchDevUser>[2]
  ) => {
    setBusyUid(uid);
    try {
      const res = await patchDevUser(token, uid, payload);
      setUsers((prev) => prev.map((u) => (u.uid === uid ? res.user : u)));
      if (selected?.uid === uid) setSelected(res.user);
      setMsg(isAr ? 'تم تحديث بيانات الطالب.' : 'Student account updated.');
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Update failed');
    } finally {
      setBusyUid('');
    }
  };

  const handleNotify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected || !notifTitle.trim() || !notifBody.trim()) return;
    await notifyDevUser(token, selected.uid, notifTitle.trim(), notifBody.trim());
    setNotifTitle('');
    setNotifBody('');
    setMsg(isAr ? 'تم إرسال الإشعار المباشر إلى حساب الطالب.' : 'Direct notification queued for student.');
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-500" />
            <span>{isAr ? 'إدارة المستخدمين والطلاب' : 'Users Management'}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'بحث متقدم، تعديل الباقات، إيقاف أو تفعيل الحسابات، ومنح اشتراكات مجانية.'
              : 'Search students, manage subscription plans, suspend/restore accounts, and gift Premium.'}
          </p>
        </div>
        <button
          onClick={() => load()}
          className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>{isAr ? 'تحديث القائمة' : 'Refresh'}</span>
        </button>
      </div>

      {msg && (
        <div className="p-3 rounded-xl bg-blue-50 dark:bg-sky-950/40 border border-blue-200 dark:border-sky-800 text-xs text-blue-800 dark:text-sky-200">
          {msg}
        </div>
      )}

      {/* Search & Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute top-2.5 start-3" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={isAr ? 'ابحث بالاسم أو البريد أو UID...' : 'Search by name, email, or UID...'}
            className="w-full ps-9 pe-3 py-2 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>
        <select
          value={planFilter}
          onChange={(e) => setPlanFilter(e.target.value)}
          className="px-3 py-2 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-xl"
        >
          <option value="all">{isAr ? 'كل الباقات' : 'All Plans'}</option>
          <option value="free">Free</option>
          <option value="pro">Pro</option>
          <option value="elite">Elite</option>
        </select>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-xl"
        >
          <option value="all">{isAr ? 'كل الحالات' : 'All Statuses'}</option>
          <option value="active">{isAr ? 'نشط' : 'Active'}</option>
          <option value="suspended">{isAr ? 'موقوف' : 'Suspended'}</option>
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-7 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-hidden">
          {filtered.length === 0 ? (
            <p className="p-8 text-center text-xs text-slate-500">
              {isAr
                ? 'لا يوجد طلاب مطابقون. يظهر كل طالب هنا تلقائياً فور تسجيل دخوله.'
                : 'No matching student accounts yet. Students sync here automatically upon sign-in.'}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-start">
                <thead className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 text-slate-500">
                  <tr>
                    <th className="p-3 text-start">{isAr ? 'الطالب' : 'Student'}</th>
                    <th className="p-3 text-start">{isAr ? 'الباقة' : 'Plan'}</th>
                    <th className="p-3 text-start">{isAr ? 'النشاط' : 'Usage'}</th>
                    <th className="p-3 text-start">{isAr ? 'الحالة' : 'Status'}</th>
                    <th className="p-3 text-end">{isAr ? 'إجراء' : 'Inspect'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filtered.map((u) => (
                    <tr
                      key={u.uid}
                      className={`hover:bg-slate-50/60 dark:hover:bg-slate-800/30 ${
                        selected?.uid === u.uid ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''
                      }`}
                    >
                      <td className="p-3">
                        <p className="font-semibold text-slate-800 dark:text-slate-100">
                          {u.displayName}
                        </p>
                        <p className="text-[11px] text-slate-500">{u.email}</p>
                      </td>
                      <td className="p-3 uppercase font-mono">{u.planId}</td>
                      <td className="p-3 tabular-nums text-[11px] text-slate-500">
                        {u.lecturesCount} lec · {u.aiRequestsUsed} AI
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[11px] font-medium ${
                            u.status === 'active'
                              ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                              : 'bg-red-500/15 text-red-600 dark:text-red-400'
                          }`}
                        >
                          {u.status}
                        </span>
                      </td>
                      <td className="p-3 text-end">
                        <button
                          onClick={() => setSelected(u)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{isAr ? 'تفاصيل' : 'View'}</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* User Details & Direct Controls */}
        <div className="lg:col-span-5 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          {!selected ? (
            <p className="text-xs text-slate-500 py-12 text-center">
              {isAr
                ? 'اختر حساب طالب من الجدول لعرض تفاصيله والتحكم في صلاحياته واشتراكه.'
                : 'Select a student from the list to inspect usage and manage their subscription.'}
            </p>
          ) : (
            <>
              <div className="flex items-start justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white">
                    {selected.displayName}
                  </h3>
                  <p className="text-xs text-slate-500">{selected.email}</p>
                  <p className="text-[11px] font-mono text-slate-400 mt-0.5">{selected.uid}</p>
                </div>
                <button
                  disabled={busyUid === selected.uid}
                  onClick={() =>
                    handlePatch(selected.uid, {
                      status: selected.status === 'active' ? 'suspended' : 'active',
                    })
                  }
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1 ${
                    selected.status === 'active'
                      ? 'bg-red-500/15 text-red-600 dark:text-red-400'
                      : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  }`}
                >
                  {selected.status === 'active' ? (
                    <>
                      <Ban className="w-3.5 h-3.5" />
                      <span>{isAr ? 'إيقاف الحساب' : 'Suspend'}</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{isAr ? 'تفعيل الحساب' : 'Activate'}</span>
                    </>
                  )}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                  <p className="text-slate-500">{isAr ? 'المحاضرات' : 'Lectures'}</p>
                  <p className="font-bold text-base tabular-nums">{selected.lecturesCount}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                  <p className="text-slate-500">{isAr ? 'الامتحانات' : 'Exams'}</p>
                  <p className="font-bold text-base tabular-nums">{selected.examsCount}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                  <p className="text-slate-500">{isAr ? 'طلبات AI' : 'AI Calls'}</p>
                  <p className="font-bold text-base tabular-nums">{selected.aiRequestsUsed}</p>
                </div>
              </div>

              {/* Plan Switch & Gift Premium */}
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                  {isAr ? 'تعديل الباقة ومنح أيام مجانية' : 'Plan Control & Gift Premium'}
                </p>
                <div className="flex flex-wrap gap-2">
                  {(['free', 'pro', 'elite'] as const).map((pid) => (
                    <button
                      key={pid}
                      disabled={busyUid === selected.uid}
                      onClick={() => handlePatch(selected.uid, { planId: pid })}
                      className={`px-3 py-1.5 text-xs rounded-lg border uppercase font-mono ${
                        selected.planId === pid
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {pid}
                    </button>
                  ))}
                  <button
                    disabled={busyUid === selected.uid}
                    onClick={() => handlePatch(selected.uid, { grantPremiumDays: 30 })}
                    className="px-3 py-1.5 text-xs rounded-lg bg-violet-600 text-white flex items-center gap-1"
                  >
                    <Gift className="w-3.5 h-3.5" />
                    <span>{isAr ? 'منح 30 يوم Premium' : 'Gift 30d Pro'}</span>
                  </button>
                </div>
                {selected.premiumGiftUntil && (
                  <p className="text-[11px] text-violet-500">
                    {isAr ? 'صالح حتى:' : 'Premium until:'}{' '}
                    {new Date(selected.premiumGiftUntil).toLocaleDateString()}
                  </p>
                )}
              </div>

              {/* Direct Notification */}
              <form onSubmit={handleNotify} className="space-y-2 border-t border-slate-200 dark:border-slate-800 pt-3">
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                  {isAr ? 'إرسال إشعار مباشر للطالب' : 'Send Direct Notification'}
                </p>
                <input
                  value={notifTitle}
                  onChange={(e) => setNotifTitle(e.target.value)}
                  placeholder={isAr ? 'عنوان الإشعار' : 'Notification title'}
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
                <textarea
                  rows={2}
                  value={notifBody}
                  onChange={(e) => setNotifBody(e.target.value)}
                  placeholder={isAr ? 'نص الرسالة...' : 'Message content...'}
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 text-xs font-medium accent-btn-gradient text-white rounded-lg flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إرسال' : 'Send Notification'}</span>
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 3. SUBSCRIPTIONS & GOOGLE PLAY BILLING SECTION
// =========================================================================
export const DevSubscriptionsSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [plans, setPlans] = useState<ControlPlanConfig[]>([]);
  const [promos, setPromos] = useState<ControlPromoConfig[]>([]);
  const [payments, setPayments] = useState<ControlPaymentRecord[]>([]);
  const [promoCode, setPromoCode] = useState('');
  const [promoPct, setPromoPct] = useState(25);
  const [promoMax, setPromoMax] = useState(100);
  const [msg, setMsg] = useState('');

  const load = async () => {
    const res = await fetchDevSubscriptions(token);
    setPlans(res.plans);
    setPromos(res.promoCodes);
    setPayments(res.payments);
  };

  useEffect(() => {
    load().catch(() => {});
  }, []);

  const handleSavePlan = async (plan: ControlPlanConfig) => {
    const res = await saveDevPlan(token, plan);
    setPlans(res.plans);
    setMsg(isAr ? `تم حفظ إعدادات باقة ${plan.nameAr}` : `Saved ${plan.nameEn} plan`);
  };

  const handleAddPromo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoCode.trim()) return;
    const res = await saveDevPromo(token, {
      code: promoCode.trim().toUpperCase(),
      discountPercent: promoPct,
      maxUses: promoMax,
    });
    setPromos(res.promoCodes);
    setPromoCode('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-blue-500" />
          <span>{isAr ? 'الاشتراكات والخطط والمدفوعات' : 'Subscriptions & Billing'}</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {isAr
            ? 'تخصيص الأسعار، حدود AI والتخزين، معرفات Google Play Billing، وأكواد الخصم.'
            : 'Configure plan pricing, AI & storage quotas, Google Play product IDs, promos, and invoices.'}
        </p>
      </div>

      {msg && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {msg}
        </div>
      )}

      {/* Plans Editor Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {plans.map((p, idx) => (
          <div
            key={p.id}
            className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                {isAr ? p.nameAr : p.nameEn} ({p.id})
              </h3>
              <label className="flex items-center gap-1.5 text-xs">
                <input
                  type="checkbox"
                  checked={p.isActive}
                  onChange={(e) =>
                    setPlans((prev) =>
                      prev.map((item, i) => (i === idx ? { ...item, isActive: e.target.checked } : item))
                    )
                  }
                />
                <span>{isAr ? 'فعالة' : 'Active'}</span>
              </label>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="text-[11px] text-slate-500 block">{isAr ? 'السعر ($)' : 'Price ($)'}</label>
                <input
                  type="number"
                  step="0.01"
                  value={p.priceMonthly}
                  onChange={(e) =>
                    setPlans((prev) =>
                      prev.map((item, i) =>
                        i === idx ? { ...item, priceMonthly: Number(e.target.value) } : item
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block">{isAr ? 'المدة (يوم)' : 'Days'}</label>
                <input
                  type="number"
                  value={p.durationDays}
                  onChange={(e) =>
                    setPlans((prev) =>
                      prev.map((item, i) =>
                        i === idx ? { ...item, durationDays: Number(e.target.value) } : item
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block">{isAr ? 'حد طلبات AI' : 'AI Limit'}</label>
                <input
                  type="number"
                  value={p.aiRequestLimit}
                  onChange={(e) =>
                    setPlans((prev) =>
                      prev.map((item, i) =>
                        i === idx ? { ...item, aiRequestLimit: Number(e.target.value) } : item
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block">{isAr ? 'التخزين (MB)' : 'Storage MB'}</label>
                <input
                  type="number"
                  value={p.storageLimitMb}
                  onChange={(e) =>
                    setPlans((prev) =>
                      prev.map((item, i) =>
                        i === idx ? { ...item, storageLimitMb: Number(e.target.value) } : item
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block">{isAr ? 'حد الملفات' : 'Max Files'}</label>
                <input
                  type="number"
                  value={p.maxFilesCount}
                  onChange={(e) =>
                    setPlans((prev) =>
                      prev.map((item, i) =>
                        i === idx ? { ...item, maxFilesCount: Number(e.target.value) } : item
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block">{isAr ? 'نسبة خصم %' : 'Discount %'}</label>
                <input
                  type="number"
                  value={p.discountPercent || 0}
                  onChange={(e) =>
                    setPlans((prev) =>
                      prev.map((item, i) =>
                        i === idx ? { ...item, discountPercent: Number(e.target.value) } : item
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                />
              </div>
            </div>

            <div className="text-xs">
              <label className="text-[11px] text-slate-500 block">Google Play Product ID</label>
              <input
                value={p.googlePlayProductId || ''}
                onChange={(e) =>
                  setPlans((prev) =>
                    prev.map((item, i) =>
                      i === idx ? { ...item, googlePlayProductId: e.target.value } : item
                    )
                  )
                }
                placeholder="smart_student_pro_monthly"
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
              />
            </div>

            <button
              onClick={() => handleSavePlan(p)}
              className="w-full py-2 text-xs font-semibold accent-btn-gradient text-white rounded-xl"
            >
              {isAr ? 'حفظ الباقة' : 'Save Plan'}
            </button>
          </div>
        ))}
      </div>

      {/* Promo Codes & Payment Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-5 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold flex items-center gap-2">
            <Ticket className="w-4 h-4 text-violet-500" />
            <span>{isAr ? 'أكواد الخصم والكوبونات' : 'Promo Codes'}</span>
          </h3>
          <form onSubmit={handleAddPromo} className="grid grid-cols-3 gap-2">
            <input
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              placeholder="STUDENT25"
              className="col-span-1 px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg uppercase font-mono"
            />
            <input
              type="number"
              min={1}
              max={100}
              value={promoPct}
              onChange={(e) => setPromoPct(Number(e.target.value))}
              className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
              title="Discount %"
            />
            <button
              type="submit"
              className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAr ? 'إضافة' : 'Add'}</span>
            </button>
          </form>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {promos.length === 0 ? (
              <p className="text-slate-500 py-4 text-center">
                {isAr ? 'لا توجد أكواد خصم نشطة.' : 'No active promo codes.'}
              </p>
            ) : (
              promos.map((pr) => (
                <div key={pr.code} className="py-2 flex items-center justify-between">
                  <div>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">
                      {pr.code}
                    </span>{' '}
                    <span className="text-emerald-600 dark:text-emerald-400">
                      ({pr.discountPercent}% OFF)
                    </span>
                  </div>
                  <button
                    onClick={async () => {
                      const res = await deleteDevPromo(token, pr.code);
                      setPromos(res.promoCodes);
                    }}
                    className="text-red-500 hover:opacity-80 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="lg:col-span-7 glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-bold flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-500" />
            <span>{isAr ? 'سجل المدفوعات والتحقق من Google Play' : 'Payments & Google Play Ledger'}</span>
          </h3>
          {payments.length === 0 ? (
            <p className="text-xs text-slate-500 py-8 text-center">
              {isAr ? 'لا توجد مدفوعات مسجلة حتى الآن.' : 'No billing transactions recorded yet.'}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <tr>
                    <th className="py-2 text-start">{isAr ? 'البريد' : 'Email'}</th>
                    <th className="py-2 text-start">{isAr ? 'الباقة' : 'Plan'}</th>
                    <th className="py-2 text-start">{isAr ? 'المبلغ' : 'Amount'}</th>
                    <th className="py-2 text-start">{isAr ? 'المزود' : 'Provider'}</th>
                    <th className="py-2 text-end">{isAr ? 'الحالة' : 'Status'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {payments.map((pay) => (
                    <tr key={pay.id}>
                      <td className="py-2">{pay.userEmail || pay.uid}</td>
                      <td className="py-2">{pay.planName}</td>
                      <td className="py-2 font-mono tabular-nums">
                        ${pay.amount} {pay.currency}
                      </td>
                      <td className="py-2 font-mono text-[11px]">{pay.provider}</td>
                      <td className="py-2 text-end">
                        <select
                          value={pay.status}
                          onChange={async (e) => {
                            const res = await patchDevPayment(
                              token,
                              pay.id,
                              e.target.value as 'paid' | 'refunded' | 'pending'
                            );
                            setPayments(res.payments);
                          }}
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[11px]"
                        >
                          <option value="paid">paid</option>
                          <option value="pending">pending</option>
                          <option value="refunded">refunded</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 4. AI CONTROL CENTER (12 SERVICES + MODELS + BUDGETS + AUTO-STOP)
// =========================================================================
export const DevAiControlSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [services, setServices] = useState<AiServiceConfig[]>([]);
  const [savingId, setSavingId] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    fetchDevAiServices(token).then((r) => setServices(r.aiServices)).catch(() => {});
  }, []);

  const handleSave = async (svc: AiServiceConfig) => {
    setSavingId(svc.id);
    try {
      const res = await updateDevAiService(token, svc.id, svc);
      setServices(res.aiServices);
      setMsg(isAr ? `تم تحديث خدمة ${svc.name}` : `Updated ${svc.name}`);
    } finally {
      setSavingId('');
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Cpu className="w-5 h-5 text-violet-500" />
          <span>{isAr ? 'مركز التحكم في الذكاء الاصطناعي' : 'AI Control Center'}</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {isAr
            ? 'تشغيل أو إيقاف 12 خدمة AI، تبديل النماذج، تحديد الميزانية والإيقاف التلقائي.'
            : 'Enable/pause 12 AI services, switch providers/models, cap budgets, and auto-stop on limit.'}
        </p>
      </div>

      {msg && (
        <div className="p-3 rounded-xl bg-blue-50 dark:bg-sky-950/40 border border-blue-200 dark:border-sky-800 text-xs text-blue-700 dark:text-sky-200">
          {msg}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {services.map((svc, idx) => (
          <div
            key={svc.id}
            className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 space-y-3"
          >
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">{svc.name}</h3>
                <p className="text-[11px] font-mono text-slate-400">
                  OK: {svc.successCount} · Err: {svc.failedCount} · Est: ${svc.estimatedCostUsd.toFixed(3)}
                </p>
              </div>
              <button
                onClick={() => handleSave({ ...svc, enabled: !svc.enabled })}
                className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                  svc.enabled
                    ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                    : 'bg-red-500/15 text-red-600 dark:text-red-400'
                }`}
              >
                {svc.enabled ? (isAr ? 'يعمل' : 'Enabled') : isAr ? 'متوقف' : 'Paused'}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div>
                <label className="text-[11px] text-slate-500 block">{isAr ? 'المزود' : 'Provider'}</label>
                <select
                  value={svc.provider}
                  onChange={(e) =>
                    setServices((prev) =>
                      prev.map((s, i) =>
                        i === idx ? { ...s, provider: e.target.value as AiServiceConfig['provider'] } : s
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  <option value="gemini">Google Gemini</option>
                  <option value="openai">OpenAI Compatible</option>
                  <option value="anthropic">Anthropic Claude</option>
                </select>
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block">{isAr ? 'النموذج' : 'Model'}</label>
                <select
                  value={svc.model}
                  onChange={(e) =>
                    setServices((prev) =>
                      prev.map((s, i) => (i === idx ? { ...s, model: e.target.value } : s))
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono text-[11px]"
                >
                  <option value="gemini-4-hydrogen">gemini-4-hydrogen</option>
                  <option value="gemini-3.5-transcribe">gemini-3.5-transcribe</option>
                  <option value="gemini-3.8-flash-lite-tts">gemini-3.8-flash-lite-tts</option>
                  <option value="gemini-3.8-flash-tts">gemini-3.8-flash-tts</option>
                </select>
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block">
                  {isAr ? 'ميزانية شهرية ($)' : 'Monthly Cap ($)'}
                </label>
                <input
                  type="number"
                  value={svc.monthlyBudgetUsd}
                  onChange={(e) =>
                    setServices((prev) =>
                      prev.map((s, i) =>
                        i === idx ? { ...s, monthlyBudgetUsd: Number(e.target.value) } : s
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block">
                  {isAr ? 'أقصى حجم ملف (MB)' : 'Max File MB'}
                </label>
                <input
                  type="number"
                  value={svc.maxFileSizeMb}
                  onChange={(e) =>
                    setServices((prev) =>
                      prev.map((s, i) =>
                        i === idx ? { ...s, maxFileSizeMb: Number(e.target.value) } : s
                      )
                    )
                  }
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
              <label className="flex items-center gap-1.5">
                <input
                  type="checkbox"
                  checked={svc.autoStopOnBudget}
                  onChange={(e) =>
                    setServices((prev) =>
                      prev.map((s, i) =>
                        i === idx ? { ...s, autoStopOnBudget: e.target.checked } : s
                      )
                    )
                  }
                />
                <span>{isAr ? 'إيقاف تلقائي عند الميزانية' : 'Auto-stop at budget'}</span>
              </label>
              <button
                disabled={savingId === svc.id}
                onClick={() => handleSave(svc)}
                className="px-3.5 py-1.5 rounded-lg bg-blue-600 text-white font-semibold"
              >
                {savingId === svc.id ? '...' : isAr ? 'تطبيق' : 'Apply'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// =========================================================================
// 5. FEATURES MANAGEMENT SECTION (20 FEATURE FLAGS)
// =========================================================================
export const DevFeaturesSection: React.FC<{ token: string | null; lang: Language }> = ({
  token,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [flags, setFlags] = useState<FeatureFlagConfig[]>([]);
  const [search, setSearch] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    fetchDevFeatures(token).then((r) => setFlags(r.featureFlags)).catch(() => {});
  }, []);

  const handleSave = async (flag: FeatureFlagConfig) => {
    const res = await updateDevFeature(token, flag.id, flag);
    setFlags(res.featureFlags);
    setMsg(isAr ? `تم حفظ حالة ميزة "${flag.nameAr}" فوراً` : `Saved "${flag.nameEn}" flag live`);
  };

  const filtered = flags.filter((f) => {
    const q = search.trim().toLowerCase();
    return (
      !q ||
      f.nameAr.toLowerCase().includes(q) ||
      f.nameEn.toLowerCase().includes(q) ||
      f.id.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-blue-500" />
            <span>{isAr ? 'إدارة الميزات الحية (Feature Flags)' : 'Live Features Management'}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'تشغيل، إيقاف، صيانة، أو تخصيص 20 ميزة دون الحاجة لتحديث التطبيق.'
              : 'Enable, pause, set maintenance messages, or restrict 20 app features without redeploying.'}
          </p>
        </div>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isAr ? 'بحث في الميزات...' : 'Filter features...'}
          className="px-3 py-1.5 text-xs glass-surface border border-slate-200 dark:border-slate-700 rounded-xl"
        />
      </div>

      {msg && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {msg}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((f) => {
          const origIdx = flags.findIndex((x) => x.id === f.id);
          return (
            <div
              key={f.id}
              className="glass-surface border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 space-y-3"
            >
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-blue-500" />
                    <span>{isAr ? f.nameAr : f.nameEn}</span>
                  </h3>
                  <p className="text-[11px] font-mono text-slate-400">
                    {f.id} · {f.usageCount} {isAr ? 'استخدام' : 'calls'}
                  </p>
                </div>

                <select
                  value={f.status}
                  onChange={(e) => {
                    const nextStatus = e.target.value as FeatureFlagConfig['status'];
                    const updated = { ...f, status: nextStatus };
                    setFlags((prev) => prev.map((x, i) => (i === origIdx ? updated : x)));
                    handleSave(updated);
                  }}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 font-medium"
                >
                  <option value="all">{isAr ? 'متاح للجميع' : 'All Users'}</option>
                  <option value="plans">{isAr ? 'باقات محددة' : 'Paid Plans'}</option>
                  <option value="beta">{isAr ? 'تجريبي Beta' : 'Beta Only'}</option>
                  <option value="maintenance">{isAr ? 'وضع الصيانة' : 'Maintenance'}</option>
                  <option value="disabled">{isAr ? 'معطّل' : 'Disabled'}</option>
                </select>
              </div>

              {f.status === 'plans' && (
                <div className="flex items-center gap-3 text-xs">
                  {(['free', 'pro', 'elite'] as const).map((pid) => (
                    <label key={pid} className="flex items-center gap-1 uppercase font-mono">
                      <input
                        type="checkbox"
                        checked={f.allowedPlans.includes(pid)}
                        onChange={(e) => {
                          const allowedPlans = e.target.checked
                            ? Array.from(new Set([...f.allowedPlans, pid]))
                            : f.allowedPlans.filter((x) => x !== pid);
                          const updated = { ...f, allowedPlans };
                          setFlags((prev) => prev.map((x, i) => (i === origIdx ? updated : x)));
                        }}
                      />
                      <span>{pid}</span>
                    </label>
                  ))}
                </div>
              )}

              <div className="flex items-center gap-2">
                <input
                  value={isAr ? f.maintenanceMessageAr : f.maintenanceMessageEn}
                  onChange={(e) => {
                    const val = e.target.value;
                    setFlags((prev) =>
                      prev.map((x, i) =>
                        i === origIdx
                          ? {
                              ...x,
                              ...(isAr
                                ? { maintenanceMessageAr: val }
                                : { maintenanceMessageEn: val }),
                            }
                          : x
                      )
                    );
                  }}
                  placeholder={isAr ? 'رسالة الصيانة...' : 'Maintenance notice...'}
                  className="flex-1 px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
                <button
                  onClick={() => handleSave(flags[origIdx])}
                  className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg"
                >
                  {isAr ? 'حفظ' : 'Save'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
