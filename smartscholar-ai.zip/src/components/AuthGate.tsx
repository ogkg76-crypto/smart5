import React, { useState } from 'react';
import {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  updateProfile,
  signOut,
  User,
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { DevSessionUser, Language, ThemeMode } from '../types';
import { t } from '../i18n';
import { unifiedLogin } from '../services/devApi';
import {
  BookOpen,
  Globe,
  Moon,
  Sun,
  Mail,
  Lock,
  User as UserIcon,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
} from 'lucide-react';

interface Props {
  lang: Language;
  theme: ThemeMode;
  onToggleLang: () => void;
  onToggleTheme: () => void;
  unverifiedUser: User | null;
  onReloadUser: () => Promise<void>;
  onDevLoginSuccess: (token: string, user: DevSessionUser) => void;
}

export const AuthGate: React.FC<Props> = ({
  lang,
  theme,
  onToggleLang,
  onToggleTheme,
  unverifiedUser,
  onReloadUser,
  onDevLoginSuccess,
}) => {
  const dict = t(lang);
  const isAr = lang === 'ar';
  const [mode, setMode] = useState<'signin' | 'signup' | 'reset'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');

  const [needs2fa, setNeeds2fa] = useState(false);
  const [totpCode, setTotpCode] = useState('');

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  const formatAuthError = (err: unknown): string => {
    const raw = err instanceof Error ? err.message : String(err);
    const codeMatch = raw.match(/auth\/[a-z0-9-]+/i);
    const code = codeMatch ? codeMatch[0].toLowerCase() : '';

    if (
      code === 'auth/operation-not-allowed' ||
      code === 'auth/admin-restricted-operation' ||
      code === 'auth/configuration-not-found'
    ) {
      return isAr
        ? 'طريقة تسجيل الدخول هذه غير متاحة حاليًا. يمكنك تسجيل الدخول باستخدام Google أدناه.'
        : 'This sign-in method is currently unavailable. Please use Google Sign-In below.';
    }
    if (code === 'auth/popup-blocked') {
      return isAr
        ? 'قام المتصفح بحظر نافذة تسجيل الدخول. اسمح بالنوافذ المنبثقة ثم أعد المحاولة.'
        : 'Browser blocked the sign-in popup. Allow pop-ups and try again.';
    }
    if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
      return isAr
        ? 'تم إغلاق نافذة تسجيل الدخول قبل إتمام العملية.'
        : 'Sign-in window was closed before completing.';
    }
    if (code === 'auth/email-already-in-use') {
      return isAr
        ? 'هذا البريد الإلكتروني مسجل بالفعل. انتقل إلى "تسجيل الدخول".'
        : 'This email is already registered. Switch to Sign In.';
    }
    if (code === 'auth/invalid-email') {
      return isAr ? 'صيغة البريد الإلكتروني غير صحيحة.' : 'Please enter a valid email address.';
    }
    if (code === 'auth/weak-password') {
      return isAr
        ? 'كلمة المرور ضعيفة، يجب أن تتكون من 6 أحرف على الأقل.'
        : 'Password should be at least 6 characters.';
    }
    if (
      code === 'auth/invalid-credential' ||
      code === 'auth/wrong-password' ||
      code === 'auth/user-not-found'
    ) {
      return isAr ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'Invalid email or password.';
    }
    if (code === 'auth/too-many-requests') {
      return isAr
        ? 'محاولات كثيرة متتالية. انتظر قليلًا ثم حاول مرة أخرى.'
        : 'Too many attempts. Please wait a moment and try again.';
    }
    if (code === 'auth/unauthorized-domain') {
      return isAr
        ? 'تعذر تسجيل الدخول من هذا الرابط حاليًا. يرجى التواصل مع الدعم الفني.'
        : 'Sign-in is temporarily unavailable from this link. Please contact support.';
    }
    if (code === 'auth/network-request-failed') {
      return isAr
        ? 'تعذر الاتصال بالشبكة. تحقق من الاتصال وحاول مرة أخرى.'
        : 'Network error. Please check your connection and try again.';
    }
    return raw;
  };

  const handleGoogleSignIn = async () => {
    setError('');
    setInfo('');
    setBusy(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setError(formatAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfo('');
    setBusy(true);
    try {
      if (mode === 'signin') {
        const unified = await unifiedLogin({
          email: email.trim(),
          password,
          totpCode: needs2fa ? totpCode.trim() : undefined,
        });

        if (unified.requires2fa) {
          setNeeds2fa(true);
          setBusy(false);
          return;
        }

        if (unified.token && unified.user) {
          onDevLoginSuccess(unified.token, unified.user);
          return;
        }

        if (unified.delegateToFirebase) {
          await signInWithEmailAndPassword(auth, email.trim(), password);
        }
      } else if (mode === 'signup') {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        if (displayName.trim()) {
          await updateProfile(cred.user, { displayName: displayName.trim() });
        }
        await sendEmailVerification(cred.user);
        setInfo(
          isAr
            ? 'تم إنشاء الحساب وإرسال رابط التفعيل إلى بريدك الإلكتروني.'
            : 'Account created and verification email sent.'
        );
      } else {
        await sendPasswordResetEmail(auth, email.trim());
        setInfo(
          isAr
            ? 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك.'
            : 'Password reset link sent to your email.'
        );
        setMode('signin');
      }
    } catch (err) {
      setError(formatAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  if (unverifiedUser) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#0B1120] flex items-center justify-center p-6">
        <div className="max-w-md w-full glass-surface border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-8 space-y-5 shadow-xl">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-blue-600 dark:text-sky-400 shrink-0" />
            <h1 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
              {dict.auth.verifyTitle}
            </h1>
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            {dict.auth.verifyBody} ({unverifiedUser.email})
          </p>
          {info && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
              {info}
            </div>
          )}
          {error && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
              {error}
            </div>
          )}
          <div className="flex flex-col gap-3">
            <button
              onClick={onReloadUser}
              className="w-full py-2.5 px-4 accent-btn-gradient text-white text-sm font-medium rounded-xl transition-opacity hover:opacity-95"
            >
              {dict.auth.refreshVerify}
            </button>
            <button
              onClick={async () => {
                try {
                  await sendEmailVerification(unverifiedUser);
                  setInfo(isAr ? 'تم إعادة إرسال الرابط.' : 'Verification email re-sent.');
                } catch (err) {
                  setError(err instanceof Error ? err.message : 'Failed to send verification.');
                }
              }}
              className="w-full py-2.5 px-4 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-sm font-medium rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              {dict.auth.resendVerify}
            </button>
            <button
              onClick={() => signOut(auth)}
              className="w-full py-2 px-4 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            >
              {dict.auth.signOut}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0B1120] flex flex-col">
      <header className="w-full border-b border-slate-200/80 dark:border-slate-800/80 glass-surface px-6 py-4 flex items-center justify-between gap-8">
        <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
          <div className="w-8 h-8 rounded-xl accent-btn-gradient text-white flex items-center justify-center shrink-0">
            <BookOpen className="w-4 h-4" />
          </div>
          <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {dict.appName}
          </span>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onToggleLang}
            className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{isAr ? 'English' : 'العربية'}</span>
          </button>
          <button
            onClick={onToggleTheme}
            aria-label="Toggle theme"
            className="p-2 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      <main className="relative flex-1 flex items-center justify-center px-6 py-10 overflow-hidden">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-32 start-1/4 w-[28rem] h-[28rem] rounded-full bg-blue-600/10 dark:bg-blue-600/15 blur-3xl" />
          <div className="absolute -bottom-32 end-1/4 w-[26rem] h-[26rem] rounded-full bg-violet-600/10 dark:bg-violet-600/15 blur-3xl" />
        </div>

        <div className="relative z-10 max-w-5xl w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          <div className="lg:col-span-6 space-y-5 text-center lg:text-start">
            <p className="text-xs font-semibold tracking-wider text-blue-600 dark:text-sky-400">
              {dict.appName}
            </p>
            <h1 className="text-4xl sm:text-5xl font-bold text-slate-900 dark:text-white leading-[1.18] tracking-tight [text-wrap:balance]">
              {isAr ? 'مذاكرتك الجامعية، بذكاء.' : 'Study smarter. Master faster.'}
            </h1>
            <p className="text-base text-slate-600 dark:text-slate-400 leading-relaxed max-w-md mx-auto lg:mx-0">
              {isAr
                ? 'حوّل أي محاضرة إلى شرح، ملخصات، واختبارات في لحظات.'
                : 'Turn any lecture into clear lessons, summaries, and practice exams.'}
            </p>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-500 pt-1">
              {isAr
                ? 'المدرس الذكي · البودكاست · السبورة · مختبر البرمجة'
                : 'AI Tutor · Podcasts · Whiteboard · Code Lab'}
            </p>
          </div>

          <div className="lg:col-span-6">
            <div className="max-w-md w-full mx-auto rounded-2xl bg-white/95 dark:bg-slate-900/80 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-7 sm:p-9 shadow-2xl space-y-5">
              <div className="text-center space-y-1.5">
                <div className="w-11 h-11 rounded-2xl accent-btn-gradient text-white flex items-center justify-center mx-auto shadow-lg">
                  <BookOpen className="w-5 h-5" />
                </div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white pt-1">
                  {isAr ? 'تسجيل الدخول' : 'Welcome back'}
                </h2>
              </div>

              {error && (
                <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800/80 text-xs text-red-700 dark:text-red-200">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
                    <span className="leading-relaxed font-medium select-text break-words">
                      {error}
                    </span>
                  </div>
                </div>
              )}

              {info && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
                  {info}
                </div>
              )}

              <div className="space-y-4">
                <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl">
                  <button
                    type="button"
                    onClick={() => {
                      setMode('signin');
                      setNeeds2fa(false);
                      setError('');
                      setInfo('');
                    }}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                      mode === 'signin'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {dict.auth.signIn}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('signup');
                      setNeeds2fa(false);
                      setError('');
                      setInfo('');
                    }}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                      mode === 'signup'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {dict.auth.signUp}
                  </button>
                </div>

                <form onSubmit={handleEmailSubmit} className="space-y-3.5">
                  {mode === 'signup' && (
                    <div className="space-y-1.5">
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                        {dict.auth.nameLabel}
                      </label>
                      <div className="relative">
                        <UserIcon className="w-4 h-4 text-slate-400 absolute top-3 start-3" />
                        <input
                          type="text"
                          required
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                          className="w-full ps-9 pe-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                        />
                      </div>
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {dict.auth.emailLabel}
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute top-3 start-3" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          setNeeds2fa(false);
                        }}
                        className="w-full ps-9 pe-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>
                  </div>

                  {mode !== 'reset' && (
                    <div className="space-y-1.5">
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                        {dict.auth.passwordLabel}
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-400 absolute top-3 start-3" />
                        <input
                          type="password"
                          required
                          minLength={6}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full ps-9 pe-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                        />
                      </div>
                    </div>
                  )}

                  {needs2fa && mode === 'signin' && (
                    <div className="space-y-1.5">
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                        {isAr ? 'رمز التحقق (2FA)' : '2FA Code'}
                      </label>
                      <div className="relative">
                        <ShieldCheck className="w-4 h-4 text-emerald-500 absolute top-3 start-3" />
                        <input
                          type="text"
                          required
                          maxLength={6}
                          value={totpCode}
                          onChange={(e) => setTotpCode(e.target.value)}
                          placeholder="000000"
                          className="w-full ps-9 pe-3 py-2 text-sm font-mono bg-slate-50 dark:bg-slate-950 border border-emerald-400 dark:border-emerald-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                        />
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={busy}
                    className="w-full py-2.5 px-4 accent-btn-gradient text-white text-sm font-semibold rounded-xl transition-opacity hover:opacity-95 disabled:opacity-60 shadow-md"
                  >
                    {busy
                      ? dict.common.loading
                      : mode === 'signin'
                        ? dict.auth.signIn
                        : mode === 'signup'
                          ? dict.auth.signUp
                          : dict.auth.resetPass}
                  </button>

                  {mode === 'signin' && (
                    <button
                      type="button"
                      onClick={() => setMode('reset')}
                      className="w-full text-xs text-blue-600 dark:text-sky-400 hover:underline text-center"
                    >
                      {dict.auth.resetPass}
                    </button>
                  )}
                  {mode === 'reset' && (
                    <button
                      type="button"
                      onClick={() => setMode('signin')}
                      className="w-full text-xs text-slate-500 hover:underline text-center"
                    >
                      {dict.auth.signIn}
                    </button>
                  )}
                </form>

                <div className="flex items-center gap-3 text-[11px] text-slate-400">
                  <div className="h-px flex-1 bg-slate-200 dark:bg-slate-800" />
                  <span>{isAr ? 'أو' : 'or'}</span>
                  <div className="h-px flex-1 bg-slate-200 dark:bg-slate-800" />
                </div>

                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={busy}
                  className="w-full py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 text-sm font-medium transition-colors disabled:opacity-60 flex items-center justify-center gap-3 whitespace-nowrap"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  <span>{dict.auth.googleBtn}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
