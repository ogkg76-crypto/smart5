import React, { useEffect, useRef, useState } from 'react';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import {
  Language,
  Lecture,
  PodcastEpisode,
  PodcastScriptLine,
  SubscriptionPlan,
  Subject,
  UserProfile,
} from '../types';
import { generatePodcastScript, synthesizePodcastAudio } from '../services/api';
import {
  awardStudyXp,
  cachePodcastAudio,
  deleteDocSafe,
  getCachedPodcastAudio,
  getEffectiveLimit,
  makeId,
  trackAiUsageAndNotify,
} from '../services/firestoreHelpers';
import {
  Headphones,
  Loader2,
  Play,
  Pause,
  Download,
  Trash2,
  AlertCircle,
  Volume2,
} from 'lucide-react';

interface Props {
  lang: Language;
  uid: string;
  profile: UserProfile | null;
  activePlan: SubscriptionPlan | null;
  subjects: Subject[];
  lectures: Lecture[];
  podcasts: PodcastEpisode[];
  selectedLectureId: string;
  onSelectLecture: (id: string) => void;
}

export const PodcastPanel: React.FC<Props> = ({
  lang,
  uid,
  profile,
  activePlan,
  subjects,
  lectures,
  podcasts,
  selectedLectureId,
  onSelectLecture,
}) => {
  const isAr = lang === 'ar';
  const [lengthMode, setLengthMode] = useState<'short' | 'long'>('short');
  const [podcastLang, setPodcastLang] = useState<Language>(profile?.explanationLang || lang);
  const [busy, setBusy] = useState(false);
  const [audioBusy, setAudioBusy] = useState(false);
  const [error, setError] = useState('');

  const [activeEpisodeId, setActiveEpisodeId] = useState<string>(podcasts[0]?.id || '');
  const [audioSrc, setAudioSrc] = useState<string>('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState<number>(profile?.voiceSpeed || 1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const activeEpisode = podcasts.find((p) => p.id === activeEpisodeId) || podcasts[0] || null;

  useEffect(() => {
    if (!activeEpisode) {
      setAudioSrc('');
      return;
    }
    let mounted = true;
    getCachedPodcastAudio(activeEpisode.id).then((cached) => {
      if (mounted) {
        setAudioSrc(cached ? `data:audio/wav;base64,${cached}` : '');
      }
    });
    return () => {
      mounted = false;
    };
  }, [activeEpisode?.id]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  }, [speed, audioSrc]);

  const handleGenerateEpisode = async () => {
    const lec = lectures.find((l) => l.id === selectedLectureId);
    if (!lec) {
      setError(isAr ? 'اختر محاضرة أولًا.' : 'Select a lecture first.');
      return;
    }
    const limit = activePlan?.aiRequestLimit ?? 30;
    if (getEffectiveLimit(limit, profile?.aiRequestsUsed ?? 0).exceeded) {
      setError(isAr ? 'تم الوصول للحد الشهري لطلبات AI.' : 'Monthly AI quota reached.');
      return;
    }

    setError('');
    setBusy(true);
    try {
      const fullText = lec.fullTextPreview || lec.extractedPages.map((p) => p.content).join('\n\n');
      const scriptRes = await generatePodcastScript({
        lectureTitle: lec.title,
        fullText,
        lengthMode,
        lang: podcastLang,
      });

      const epId = makeId('pod');
      await setDoc(doc(db, 'podcasts', epId), {
        ownerId: uid,
        lectureId: lec.id,
        subjectId: lec.subjectId,
        title: (scriptRes.title || lec.title).slice(0, 200),
        lengthMode,
        lang: podcastLang,
        summaryText: (scriptRes.summaryText || '').slice(0, 3000),
        scriptLines: (scriptRes.scriptLines || []).slice(0, 80),
        createdAt: serverTimestamp(),
      });
      setActiveEpisodeId(epId);

      setAudioBusy(true);
      const audioRes = await synthesizePodcastAudio({
        scriptLines: scriptRes.scriptLines,
        lang: podcastLang,
      });
      await cachePodcastAudio(epId, audioRes.audioBase64);
      setAudioSrc(`data:${audioRes.mimeType};base64,${audioRes.audioBase64}`);

      await trackAiUsageAndNotify({
        uid,
        enableNotif: profile?.notifAiReady !== false,
        notifTitle: isAr ? 'بودكاست المحاضرة جاهز' : 'AI Podcast Ready',
        notifBody: isAr ? `تم إنتاج بودكاست "${lec.title}".` : `Podcast "${lec.title}" is ready to listen.`,
        notifCategory: 'ai',
        xpDelta: 25,
      });
      await awardStudyXp(uid, profile, 25);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate AI podcast.');
    } finally {
      setBusy(false);
      setAudioBusy(false);
    }
  };

  const handleSynthesizeExisting = async (episode: PodcastEpisode) => {
    setError('');
    setAudioBusy(true);
    try {
      const audioRes = await synthesizePodcastAudio({
        scriptLines: episode.scriptLines as PodcastScriptLine[],
        lang: episode.lang,
      });
      await cachePodcastAudio(episode.id, audioRes.audioBase64);
      setAudioSrc(`data:${audioRes.mimeType};base64,${audioRes.audioBase64}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Audio synthesis failed.');
    } finally {
      setAudioBusy(false);
    }
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.playbackRate = speed;
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleDownloadWav = () => {
    if (!audioSrc || !activeEpisode) return;
    const link = document.createElement('a');
    link.href = audioSrc;
    link.download = `${activeEpisode.title.replace(/[^a-zA-Z0-9\u0600-\u06FF_-]/g, '_')}.wav`;
    link.click();
  };

  const fmtSec = (sec: number) => {
    if (!Number.isFinite(sec)) return '00:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Generator Bar */}
      <div className="glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 flex-1">
            <select
              value={selectedLectureId}
              onChange={(e) => onSelectLecture(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg min-w-[220px]"
            >
              <option value="">{isAr ? 'اختر محاضرة...' : 'Select lecture...'}</option>
              {lectures.map((l) => {
                const s = subjects.find((sub) => sub.id === l.subjectId);
                return (
                  <option key={l.id} value={l.id}>
                    {s ? `${s.name} — ` : ''}
                    {l.title}
                  </option>
                );
              })}
            </select>

            <select
              value={lengthMode}
              onChange={(e) => setLengthMode(e.target.value as 'short' | 'long')}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="short">{isAr ? 'حوار قصير (3–5 د)' : 'Short Episode'}</option>
              <option value="long">{isAr ? 'حوار مفصل (8–12 د)' : 'Deep Dive Episode'}</option>
            </select>

            <select
              value={podcastLang}
              onChange={(e) => setPodcastLang(e.target.value as Language)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="ar">{isAr ? 'بودكاست بالعربية' : 'Arabic Podcast'}</option>
              <option value="en">{isAr ? 'بودكاست بالإنجليزية' : 'English Podcast'}</option>
            </select>
          </div>

          <button
            disabled={!selectedLectureId || busy}
            onClick={handleGenerateEpisode}
            className="px-5 py-2.5 accent-btn-gradient disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Headphones className="w-4 h-4" />}
            <span>{isAr ? 'توليد بودكاست AI' : 'Generate AI Podcast'}</span>
          </button>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          {isAr
            ? 'يحول المحاضرة إلى حوار صوتي تفاعلي بين أستاذ جامعي وطالب بصوتين مميزين مع حفظ للاستماع لاحقًا.'
            : 'Converts any lecture into an engaging dual-speaker Professor & Student audio podcast with WAV download.'}
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex items-center gap-3 text-sm text-red-700 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Saved Episodes List */}
        <div className="lg:col-span-4 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2 max-h-[540px] overflow-y-auto">
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 px-2 pb-1">
            {isAr ? `الحلقات المحفوظة (${podcasts.length})` : `Saved Episodes (${podcasts.length})`}
          </p>
          {podcasts.length === 0 ? (
            <p className="text-xs text-slate-500 p-6 text-center">
              {isAr ? 'لم تنشئ أي حلقات بودكاست بعد.' : 'No podcast episodes generated yet.'}
            </p>
          ) : (
            podcasts.map((ep) => (
              <div
                key={ep.id}
                onClick={() => {
                  setActiveEpisodeId(ep.id);
                  setIsPlaying(false);
                }}
                className={`p-3 rounded-xl cursor-pointer border transition-colors flex items-start justify-between gap-2 ${
                  activeEpisode?.id === ep.id
                    ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-300 dark:border-blue-800'
                    : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                    {ep.title}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                    {ep.lang.toUpperCase()} · {ep.lengthMode} · {ep.scriptLines.length}{' '}
                    {isAr ? 'مقطع' : 'turns'}
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteDocSafe('podcasts', ep.id);
                  }}
                  className="p-1 text-slate-400 hover:text-red-500"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Audio Studio & Dialogue Script */}
        <div className="lg:col-span-8 glass-surface border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
          {!activeEpisode ? (
            <div className="py-16 text-center space-y-2 text-slate-500">
              <Headphones className="w-8 h-8 mx-auto opacity-50" />
              <p className="text-sm">
                {isAr
                  ? 'اختر محاضرة واضغط "توليد بودكاست AI" للاستماع إلى حوار ذكي يشرح المحاضرة.'
                  : 'Select a lecture and generate an AI Podcast episode.'}
              </p>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                    {activeEpisode.title}
                  </h2>
                  {activeEpisode.summaryText && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      {activeEpisode.summaryText}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={speed}
                    onChange={(e) => setSpeed(Number(e.target.value))}
                    className="px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-950 font-mono"
                  >
                    <option value={0.85}>0.85x</option>
                    <option value={1}>1.0x</option>
                    <option value={1.25}>1.25x</option>
                    <option value={1.5}>1.5x</option>
                  </select>
                  {audioSrc && (
                    <button
                      onClick={handleDownloadWav}
                      className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{isAr ? 'تحميل الصوت WAV' : 'Download WAV'}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Player Bar */}
              <div className="p-4 rounded-xl bg-slate-900 dark:bg-slate-950 text-white border border-slate-800 space-y-3">
                {audioSrc ? (
                  <>
                    <audio
                      ref={audioRef}
                      src={audioSrc}
                      onTimeUpdate={() => setCurrentTime(audioRef.current?.currentTime || 0)}
                      onLoadedMetadata={() => setDuration(audioRef.current?.duration || 0)}
                      onEnded={() => setIsPlaying(false)}
                    />
                    <div className="flex items-center gap-4">
                      <button
                        onClick={togglePlay}
                        className="w-10 h-10 rounded-full accent-btn-gradient flex items-center justify-center shrink-0"
                        aria-label="Play or pause podcast"
                      >
                        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ms-0.5" />}
                      </button>
                      <div className="flex-1 space-y-1">
                        <input
                          type="range"
                          min={0}
                          max={duration || 1}
                          step={0.1}
                          value={currentTime}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            if (audioRef.current) audioRef.current.currentTime = val;
                            setCurrentTime(val);
                          }}
                          className="w-full accent-blue-500 cursor-pointer"
                        />
                        <div className="flex justify-between text-[11px] font-mono text-slate-400 tabular-nums">
                          <span>{fmtSec(currentTime)}</span>
                          <span>{fmtSec(duration)}</span>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2 text-xs text-slate-300">
                      <Volume2 className="w-4 h-4 text-sky-400" />
                      <span>
                        {audioBusy
                          ? isAr
                            ? 'جاري توليد الصوت الثنائي عالي الجودة...'
                            : 'Synthesizing dual-speaker podcast audio...'
                          : isAr
                            ? 'النص جاهز — اضغط لتوليد الصوت وتشغيله.'
                            : 'Dialogue script ready — click to synthesize audio.'}
                      </span>
                    </div>
                    <button
                      disabled={audioBusy}
                      onClick={() => handleSynthesizeExisting(activeEpisode)}
                      className="px-4 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {audioBusy && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      <span>{isAr ? 'توليد الصوت الآن' : 'Synthesize Audio'}</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Script Transcript */}
              <div className="space-y-3 max-h-[360px] overflow-y-auto pe-1">
                {activeEpisode.scriptLines.map((line, i) => {
                  const isProf = line.speaker === 'Professor';
                  return (
                    <div
                      key={i}
                      className={`p-3.5 rounded-xl border text-sm leading-relaxed ${
                        isProf
                          ? 'bg-blue-50/70 dark:bg-blue-950/25 border-blue-200/70 dark:border-blue-900/60'
                          : 'bg-purple-50/70 dark:bg-purple-950/25 border-purple-200/70 dark:border-purple-900/60'
                      }`}
                    >
                      <p className="text-xs font-bold mb-1 text-slate-800 dark:text-slate-200">
                        {isProf
                          ? isAr
                            ? 'الأستاذ الجامعي (Professor)'
                            : 'Professor'
                          : isAr
                            ? 'الطالب (Student)'
                            : 'Student'}
                      </p>
                      <p className="text-slate-700 dark:text-slate-300">{line.text}</p>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
