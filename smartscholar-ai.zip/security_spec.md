# Security Specification & Payload-First TDD (`Smart Student / SmartScholar AI`)

## 1. Data Invariants
1. **Strict Ownership Isolation**: Every student-owned resource (`subjects`, `folders`, `lectures`, `explanations`, `summaries`, `exams`, `flashcards`, `mindmaps`, `studyPlans`, `chatSessions`, `podcasts`, `mistakes`, `whiteboards`, `codingProjects`, `notifications`, `payments`) MUST carry `ownerId == request.auth.uid` on creation and immutable `ownerId` on update.
2. **Verified Identity**: All writes and private reads require `request.auth != null && request.auth.token.email_verified == true`.
3. **Referential Integrity**: Creating a `folder`, `lecture`, `explanation`, `summary`, `mindmap`, or `podcast` MUST verify the parent `subject` (and `lecture` where applicable) exists and belongs to `request.auth.uid` via `get()`. Creating a `groupDiscussion` message MUST verify parent `studyGroup` exists.
4. **Server Timestamp Integrity**: `createdAt` and `updatedAt` MUST equal `request.time` (`serverTimestamp()`) and `createdAt` MUST remain immutable after creation.
5. **PII Isolation**: User profiles (`/users/{userId}`) containing `email` are readable/writable strictly by the profile owner (`userId == request.auth.uid`) or a verified Admin.
6. **Privilege Escalation Prevention**: Only verified Admins (`khaledsayed46829@gmail.com` with `email_verified == true`, or `/admins/{uid}` doc) may mutate `subscriptionPlans`, `promoCodes`, `admins`, `reports` status, or read global `systemLogs` / `payments`.
7. **Consent-Gated Sharing & Public Battle Bounds**: `sharedResources` MUST have `consentConfirmed == true` and `ownerId == request.auth.uid`. `studyBattles` allow verified users to append/update their own participant score only when `existing().status != 'finished'`, while only the battle owner or admin may mutate `status` (`open` -> `active` -> `finished`) or delete.
8. **Terminal State Locking**: Once an `ExamAttempt` reaches `status == 'completed'`, non-admin updates cannot alter `questions`, `scorePercent`, `correctCount`, or `status`. Once a `StudyBattle` reaches `status == 'finished'`, non-admin updates cannot alter `participants` or `questions`.

## 2. Dirty Dozen Attack Payloads (All Must Return PERMISSION_DENIED)
1. **Identity Spoofing on Lecture/Mistake/Whiteboard Create**: `{ ownerId: "other-uid", ... }` -> Denied (`ownerId != request.auth.uid`).
2. **Unverified Email Spoofing Admin**: Token `{ email: "khaledsayed46829@gmail.com", email_verified: false }` attempting write to `/subscriptionPlans/pro` -> Denied (`email_verified != true`).
3. **Shadow Ghost Field Injection**: `users/{uid}` update with `{ displayName: "Ali", isAdmin: true }` -> Denied (`affectedKeys().hasOnly(...)` rejects unknown keys).
4. **Cross-Tenant Subject/Lecture Reference**: Creating a `podcast` or `lecture` with `ownerId == auth.uid` pointing to `subjectId`/`lectureId` owned by `"victim-uid"` -> Denied (`get(...).data.ownerId != auth.uid`).
5. **ID Poisoning**: Creating `/subjects/${"a".repeat(200)}` -> Denied (`isValidId` length `<= 128` and regex `^[a-zA-Z0-9_-]+$`).
6. **Client Timestamp Forgery**: Creating `/mistakes/m1` with `createdAt: "2020-01-01T00:00:00Z"` -> Denied (`createdAt != request.time`).
7. **Immortal Field Tampering**: Updating `/codingProjects/p1` or `/whiteboards/w1` attempting to mutate `createdAt` or `ownerId` -> Denied.
8. **Terminal Exam / Battle Tampering**: Updating `/exams/e1` where `existing().status == 'completed'` or `/studyBattles/b1` where `existing().status == 'finished'` -> Denied.
9. **Blanket List Query Scraping**: `getDocs(collection(db, "mistakes"))` without `ownerId == uid` constraint -> Denied (`allow list` evaluates `resource.data.ownerId == request.auth.uid`).
10. **PII Leak Attempt**: Signed-in student A calling `getDoc(doc(db, "users", "student-B"))` -> Denied.
11. **Denial-of-Wallet Oversized Payload**: Creating a `whiteboard` with `snapshotDataUrl` > 350KB or `codingProject` with `code` > 50KB -> Denied.
12. **Orphan Group Discussion Injection**: Creating `/groupDiscussions/msg1` pointing to non-existent `groupId` -> Denied (`exists(/studyGroups/...)` check).
