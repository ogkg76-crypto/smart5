import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { spawn } from 'child_process';
import multer from 'multer';
import mammoth from 'mammoth';
import JSZip from 'jszip';
import { createServer as createViteServer } from 'vite';
import { initializeApp as initializeAdminApp, getApps as getAdminApps, getApp as getAdminApp } from 'firebase-admin/app';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import {
  registerControlCenterRoutes,
  enforceStudentRuntimeGate,
  trackAiServiceResult,
} from './server/controlCenter';

const PORT = 3000;

// Load Firebase projectId safely for ID token verification (no IAM required)
const firebaseConfigPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
const firebaseConfig = fs.existsSync(firebaseConfigPath)
  ? JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf-8'))
  : { projectId: '' };

const adminApp = getAdminApps().length
  ? getAdminApp()
  : initializeAdminApp({ projectId: firebaseConfig.projectId || undefined });

// Server-side Gemini client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in server environment Secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function withRetry<T>(fn: () => Promise<T>, retries = 2): Promise<T> {
  let lastError: unknown;
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      if (i < retries) {
        await new Promise((r) => setTimeout(r, 400 * Math.pow(2, i)));
      }
    }
  }
  throw lastError;
}

function parseJsonSafe<T>(raw: string | undefined, fallbackMsg: string): T {
  if (!raw) throw new Error(fallbackMsg);
  const cleaned = raw.trim().replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
  return JSON.parse(cleaned) as T;
}

// Per-UID rate limiting (60 requests / 60s)
const rateBuckets = new Map<string, number[]>();
function checkRateLimit(uid: string): boolean {
  const now = Date.now();
  const windowMs = 60_000;
  const maxReq = 60;
  const list = (rateBuckets.get(uid) || []).filter((ts) => now - ts < windowMs);
  if (list.length >= maxReq) {
    rateBuckets.set(uid, list);
    return false;
  }
  list.push(now);
  rateBuckets.set(uid, list);
  return true;
}

interface AuthenticatedRequest extends Request {
  user?: {
    uid: string;
    email?: string;
    emailVerified?: boolean;
  };
}

async function requireFirebaseAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Authentication required. Please sign in first.' });
      return;
    }
    const token = authHeader.slice(7).trim();
    const decoded = await getAdminAuth(adminApp).verifyIdToken(token);
    if (!decoded.email_verified) {
      res.status(403).json({ error: 'Please verify your email address to use AI features.' });
      return;
    }
    if (!checkRateLimit(decoded.uid)) {
      res.status(429).json({ error: 'Rate limit exceeded. Please wait a minute and try again.' });
      return;
    }
    req.user = {
      uid: decoded.uid,
      email: decoded.email,
      emailVerified: decoded.email_verified,
    };
    next();
  } catch (err) {
    res.status(401).json({ error: err instanceof Error ? err.message : 'Invalid auth token.' });
  }
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
});

function splitTextIntoPages(text: string, charsPerPage = 2400): { pageNumber: number; heading: string; content: string }[] {
  const normalized = text.replace(/\r\n/g, '\n').trim();
  if (!normalized) {
    return [{ pageNumber: 1, heading: 'Page 1', content: 'No readable text found.' }];
  }
  const paragraphs = normalized.split(/\n{2,}/);
  const pages: { pageNumber: number; heading: string; content: string }[] = [];
  let current = '';
  let pageNum = 1;

  for (const para of paragraphs) {
    if (current.length + para.length > charsPerPage && current.length > 0) {
      const firstLine = current.split('\n')[0].slice(0, 80).trim();
      pages.push({
        pageNumber: pageNum++,
        heading: firstLine || `Section ${pageNum - 1}`,
        content: current.trim(),
      });
      current = para;
    } else {
      current += (current ? '\n\n' : '') + para;
    }
  }
  if (current.trim()) {
    const firstLine = current.split('\n')[0].slice(0, 80).trim();
    pages.push({
      pageNumber: pageNum,
      heading: firstLine || `Section ${pageNum}`,
      content: current.trim(),
    });
  }
  return pages.slice(0, 120);
}

async function extractPptxSlides(buffer: Buffer): Promise<{ pageNumber: number; heading: string; content: string }[]> {
  const zip = await JSZip.loadAsync(buffer);
  const slideEntries = Object.keys(zip.files)
    .filter((name) => /^ppt\/slides\/slide\d+\.xml$/.test(name))
    .sort((a, b) => {
      const numA = Number(a.match(/slide(\d+)\.xml/)?.[1] || 0);
      const numB = Number(b.match(/slide(\d+)\.xml/)?.[1] || 0);
      return numA - numB;
    });

  const pages: { pageNumber: number; heading: string; content: string }[] = [];
  for (let i = 0; i < slideEntries.length && i < 120; i++) {
    const xml = await zip.files[slideEntries[i]].async('string');
    const textMatches = Array.from(xml.matchAll(/<a:t[^>]*>([\s\S]*?)<\/a:t>/g)).map((m) =>
      m[1]
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
    );
    const joined = textMatches.join(' ').replace(/\s+/g, ' ').trim();
    pages.push({
      pageNumber: i + 1,
      heading: textMatches[0]?.slice(0, 80) || `Slide ${i + 1}`,
      content: joined || `(Slide ${i + 1} has no extractable text)`,
    });
  }
  return pages.length ? pages : [{ pageNumber: 1, heading: 'Slide 1', content: 'No slides found.' }];
}

function sendApiError(res: Response, err: unknown) {
  console.error('API Error:', err);
  const msg = err instanceof Error ? err.message : 'Unexpected server error';
  const status = msg.includes('GEMINI_API_KEY') ? 500 : 502;
  res.status(status).json({ error: msg });
}

function runtimeGate(featureId: string, aiServiceId?: string, costUsd = 0.0025) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const uid = req.user?.uid || '';
    const gate = enforceStudentRuntimeGate({
      uid,
      email: req.user?.email,
      featureId,
      aiServiceId,
      fileSizeBytes: req.file?.size,
    });
    if (!gate.allowed) {
      res.status(gate.status).json({ error: gate.reason || 'Feature temporarily unavailable.' });
      return;
    }
    if (aiServiceId) {
      const startedAt = Date.now();
      res.on('finish', () => {
        if (res.statusCode !== 400 && res.statusCode !== 401 && res.statusCode !== 403 && res.statusCode !== 503) {
          trackAiServiceResult(aiServiceId, Date.now() - startedAt, res.statusCode < 400, costUsd);
        }
      });
    }
    next();
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '20mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', hasGeminiKey: Boolean(process.env.GEMINI_API_KEY) });
  });

  // 1. Lecture File Extraction (PDF, DOCX, PPTX, Image OCR, Text, Audio, Video)
  app.post('/api/files/extract', requireFirebaseAuth, upload.single('file'), runtimeGate('pdfUpload', 'lectureExplanation', 0.003), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const file = req.file;
      if (!file) {
        res.status(400).json({ error: 'No file uploaded.' });
        return;
      }

      const ext = path.extname(file.originalname).toLowerCase();
      const mime = file.mimetype.toLowerCase();

      if (ext === '.txt' || ext === '.md' || ext === '.csv' || mime.startsWith('text/')) {
        const text = file.buffer.toString('utf-8');
        const pages = splitTextIntoPages(text);
        res.json({ fileType: 'text', pages, fullTextPreview: text.slice(0, 48000) });
        return;
      }

      if (ext === '.docx' || ext === '.doc' || mime.includes('wordprocessingml') || mime.includes('msword')) {
        const result = await mammoth.extractRawText({ buffer: file.buffer });
        const pages = splitTextIntoPages(result.value || '');
        res.json({ fileType: 'docx', pages, fullTextPreview: (result.value || '').slice(0, 48000) });
        return;
      }

      if (ext === '.pptx' || ext === '.ppt' || mime.includes('presentationml') || mime.includes('powerpoint')) {
        const pages = await extractPptxSlides(file.buffer);
        const fullText = pages.map((p) => `[Slide ${p.pageNumber}] ${p.heading}\n${p.content}`).join('\n\n');
        res.json({ fileType: 'pptx', pages, fullTextPreview: fullText.slice(0, 48000) });
        return;
      }

      const ai = getGeminiClient();
      const base64Data = file.buffer.toString('base64');

      if (ext === '.pdf' || mime === 'application/pdf') {
        const response = await withRetry(() =>
          ai.models.generateContent({
            model: 'gemini-4-hydrogen',
            contents: {
              parts: [
                { inlineData: { mimeType: 'application/pdf', data: base64Data } },
                {
                  text: 'Extract the complete academic content of this PDF page by page. Preserve headings, mathematical equations, code blocks, and tables accurately without inventing anything.',
                },
              ],
            },
            config: {
              thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  pages: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        pageNumber: { type: Type.INTEGER },
                        heading: { type: Type.STRING },
                        content: { type: Type.STRING },
                      },
                      required: ['pageNumber', 'heading', 'content'],
                    },
                  },
                },
                required: ['pages'],
              },
            },
          })
        );
        const parsed = parseJsonSafe<{ pages: { pageNumber: number; heading: string; content: string }[] }>(
          response.text,
          'Failed to parse PDF extraction response.'
        );
        const pages = (parsed.pages || []).slice(0, 120);
        const fullText = pages.map((p) => `[Page ${p.pageNumber}] ${p.heading}\n${p.content}`).join('\n\n');
        res.json({ fileType: 'pdf', pages, fullTextPreview: fullText.slice(0, 48000) });
        return;
      }

      if (mime.startsWith('image/') || ['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) {
        const safeMime = mime.startsWith('image/') ? mime : 'image/png';
        const response = await withRetry(() =>
          ai.models.generateContent({
            model: 'gemini-4-hydrogen',
            contents: {
              parts: [
                { inlineData: { mimeType: safeMime, data: base64Data } },
                {
                  text: 'Perform academic OCR on this lecture image. Extract all text, tables (formatted clearly), equations, and diagram labels accurately. Flag any illegible portion clearly.',
                },
              ],
            },
            config: {
              thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  heading: { type: Type.STRING },
                  content: { type: Type.STRING },
                },
                required: ['heading', 'content'],
              },
            },
          })
        );
        const parsed = parseJsonSafe<{ heading: string; content: string }>(
          response.text,
          'Failed to extract image OCR.'
        );
        const pages = [{ pageNumber: 1, heading: parsed.heading || 'Lecture Image', content: parsed.content }];
        res.json({ fileType: 'image', pages, fullTextPreview: parsed.content.slice(0, 48000) });
        return;
      }

      if (mime.startsWith('audio/') || ['.mp3', '.wav', '.webm', '.m4a', '.ogg'].includes(ext)) {
        const safeMime = mime.startsWith('audio/') ? mime : 'audio/mp3';
        const transcriptResp = await withRetry(() =>
          ai.models.generateContent({
            model: 'gemini-3.5-transcribe',
            contents: {
              parts: [
                { inlineData: { mimeType: safeMime, data: base64Data } },
                { text: 'Transcribe this university lecture audio accurately, noting speaker changes if distinct.' },
              ],
            },
          })
        );
        const transcript = transcriptResp.text || '';
        const structuredResp = await withRetry(() =>
          ai.models.generateContent({
            model: 'gemini-4-hydrogen',
            contents: `Segment this lecture transcript into logical chapters/sections with headings:\n\n${transcript.slice(0, 35000)}`,
            config: {
              thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  pages: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        pageNumber: { type: Type.INTEGER },
                        heading: { type: Type.STRING },
                        timestamp: { type: Type.STRING },
                        content: { type: Type.STRING },
                      },
                      required: ['pageNumber', 'heading', 'content'],
                    },
                  },
                },
                required: ['pages'],
              },
            },
          })
        );
        const parsed = parseJsonSafe<{
          pages: { pageNumber: number; heading: string; timestamp?: string; content: string }[];
        }>(structuredResp.text, 'Failed to structure audio transcript.');
        res.json({
          fileType: 'audio',
          pages: parsed.pages || splitTextIntoPages(transcript),
          fullTextPreview: transcript.slice(0, 48000),
        });
        return;
      }

      if (mime.startsWith('video/') || ['.mp4', '.mov', '.webm'].includes(ext)) {
        const safeMime = mime.startsWith('video/') ? mime : 'video/mp4';
        const response = await withRetry(() =>
          ai.models.generateContent({
            model: 'gemini-4-hydrogen',
            contents: {
              parts: [
                { inlineData: { mimeType: safeMime, data: base64Data } },
                {
                  text: 'Analyze this recorded university lecture video. Produce a structured transcript divided into timestamped chapters/segments, capturing spoken explanations, slide text, and key equations.',
                },
              ],
            },
            config: {
              thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  pages: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        pageNumber: { type: Type.INTEGER },
                        heading: { type: Type.STRING },
                        timestamp: { type: Type.STRING },
                        content: { type: Type.STRING },
                      },
                      required: ['pageNumber', 'heading', 'timestamp', 'content'],
                    },
                  },
                },
                required: ['pages'],
              },
            },
          })
        );
        const parsed = parseJsonSafe<{
          pages: { pageNumber: number; heading: string; timestamp?: string; content: string }[];
        }>(response.text, 'Failed to analyze video lecture.');
        const fullText = (parsed.pages || [])
          .map((p) => `[${p.timestamp || `Part ${p.pageNumber}`}] ${p.heading}\n${p.content}`)
          .join('\n\n');
        res.json({ fileType: 'video', pages: parsed.pages || [], fullTextPreview: fullText.slice(0, 48000) });
        return;
      }

      res.status(400).json({ error: `Unsupported file format: ${ext || mime}` });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 2. AI Tutor: Explain Lecture (4 levels + 4 personal professor personas, grounded in lecture pages)
  app.post('/api/ai/explain', requireFirebaseAuth, runtimeGate('lectureExplanation', 'lectureExplanation', 0.004), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { lectureTitle, pages, level = 'intermediate', persona = 'professor', lang = 'ar' } = req.body;
      if (!lectureTitle || !Array.isArray(pages) || pages.length === 0) {
        res.status(400).json({ error: 'lectureTitle and extracted pages are required.' });
        return;
      }

      const levelGuidance: Record<string, string> = {
        beginner: 'Beginner (من الصفر): Assume zero prior background. Explain every basic concept step-by-step with intuitive analogies.',
        intermediate: 'Intermediate (متوسط): Clear, structured academic explanation suitable for university coursework.',
        advanced: 'Advanced (متقدم): Deep technical/theoretical rigor, edge cases, formal proofs, and architectural nuances.',
        revision: 'Quick Revision (مراجعة سريعة): Concise, high-yield exam-focused synthesis of key points.',
      };

      const personaGuidance: Record<string, string> = {
        professor: 'Persona — Professor: Formal, structured academic lecturer delivering methodical definitions, theorems, and rigorous university-grade examples.',
        simple: 'Persona — Simple Tutor: Explain from scratch using everyday analogies, plain friendly wording, and crystal-clear small steps.',
        exam_coach: 'Persona — Exam Coach: Focus on high-yield exam concepts, common pitfalls, tricky distinctions professors test, and how points appear on exams.',
        coding_mentor: 'Persona — Coding Mentor: Emphasize algorithmic trace, implementation logic, edge cases, time/space complexity, and practical code walkthroughs.',
      };

      const lectureContext = pages
        .slice(0, 40)
        .map((p: { pageNumber: number; heading: string; content: string }) => `--- Page ${p.pageNumber}: ${p.heading} ---\n${p.content}`)
        .join('\n\n')
        .slice(0, 42000);

      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Lecture Title: ${lectureTitle}\nTarget Depth: ${levelGuidance[level] || levelGuidance.intermediate}\nTeaching Style: ${personaGuidance[persona] || personaGuidance.professor}\nPrimary Language: ${lang === 'en' ? 'English with bilingual technical clarity' : 'Arabic (العربية الفصحى المبسطة) while preserving English scientific/technical terms and explaining them in Arabic'}\n\nSource Material:\n${lectureContext}`,
          config: {
            systemInstruction:
              'You are a dedicated University Professor & Personal AI Tutor adopting the requested Teaching Style persona. Explain the lecture thoroughly from start to finish, organized by sections and referencing exact page numbers (e.g. "Page 2"). NEVER invent facts or attribute claims to the professor/file that are not grounded in the provided Source Material. Break down difficult formulas, code snippets, and compare similar concepts clearly.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                overview: { type: Type.STRING },
                sections: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      sourcePage: { type: Type.STRING },
                      simplifiedArabic: { type: Type.STRING },
                      englishTerms: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            term: { type: Type.STRING },
                            meaning: { type: Type.STRING },
                          },
                          required: ['term', 'meaning'],
                        },
                      },
                      practicalExample: { type: Type.STRING },
                      codeOrFormula: { type: Type.STRING },
                      conceptComparison: { type: Type.STRING },
                    },
                    required: ['title', 'sourcePage', 'simplifiedArabic', 'englishTerms', 'practicalExample'],
                  },
                },
              },
              required: ['overview', 'sections'],
            },
          },
        })
      );

      const result = parseJsonSafe(response.text, 'Failed to generate structured explanation.');
      res.json(result);
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 3. AI Tutor: Re-explain a specific section
  app.post('/api/ai/reexplain', requireFirebaseAuth, runtimeGate('lectureExplanation', 'lectureExplanation', 0.002), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { sectionTitle, sourceText, style = 'simpler', lang = 'ar' } = req.body;
      if (!sectionTitle || !sourceText) {
        res.status(400).json({ error: 'sectionTitle and sourceText are required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Re-explain "${sectionTitle}" using style "${style}" in ${lang === 'en' ? 'English' : 'clear Arabic with English key terms'}.\n\nContext:\n${String(sourceText).slice(0, 8000)}`,
          config: {
            systemInstruction:
              'Re-explain the given lecture section using fresh intuitive analogies, concrete step-by-step walkthroughs, and crystal-clear formatting without fabricating external claims.',
          },
        })
      );
      res.json({ explanation: response.text || '' });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 4. Smart Summary Generator
  app.post('/api/ai/summarize', requireFirebaseAuth, runtimeGate('lectureExplanation', 'summarization', 0.003), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { lectureTitle, fullText, detailLevel = 'medium', lang = 'ar' } = req.body;
      if (!lectureTitle || !fullText) {
        res.status(400).json({ error: 'lectureTitle and fullText are required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Lecture: ${lectureTitle}\nSummary Depth: ${detailLevel}\nLanguage: ${lang === 'en' ? 'English' : 'Arabic with English technical terminology'}\n\nSource Text:\n${String(fullText).slice(0, 42000)}`,
          config: {
            systemInstruction:
              'Generate a high-yield university study summary strictly from the provided lecture. Include structured markdown overview, key points, key definitions, laws/formulas, important concept comparisons, and pre-exam revision alerts.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                contentMarkdown: { type: Type.STRING },
                keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
                definitions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: { term: { type: Type.STRING }, definition: { type: Type.STRING } },
                    required: ['term', 'definition'],
                  },
                },
                formulas: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      expression: { type: Type.STRING },
                      note: { type: Type.STRING },
                    },
                    required: ['name', 'expression'],
                  },
                },
                comparisons: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      topicA: { type: Type.STRING },
                      topicB: { type: Type.STRING },
                      difference: { type: Type.STRING },
                    },
                    required: ['topicA', 'topicB', 'difference'],
                  },
                },
                revisionAlerts: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ['contentMarkdown', 'keyPoints', 'definitions', 'formulas', 'comparisons', 'revisionAlerts'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to generate summary.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 5. Smart Question & Exam Generator
  app.post('/api/ai/questions', requireFirebaseAuth, runtimeGate('aiExams', 'questionGenerator', 0.003), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const {
        sourceText,
        count = 6,
        types = ['mcq', 'true_false'],
        difficulty = 'medium',
        lang = 'ar',
      } = req.body;
      if (!sourceText) {
        res.status(400).json({ error: 'sourceText is required.' });
        return;
      }
      const clampedCount = Math.min(Math.max(Number(count) || 5, 1), 30);
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Generate exactly ${clampedCount} university exam questions.\nAllowed Question Types: ${Array.isArray(types) ? types.join(', ') : 'mcq'}\nDifficulty: ${difficulty}\nLanguage: ${lang === 'en' ? 'English' : 'Arabic (with English code/terms as appropriate)'}\n\nLecture Material:\n${String(sourceText).slice(0, 42000)}`,
          config: {
            systemInstruction:
              'Create rigorous university-level exam questions grounded ONLY in the provided lecture material. For MCQ, provide 4 distinct options and set correctAnswer exactly matching one option. For true_false, options must be ["True", "False"] or ["صح", "خطأ"]. For every question, specify the topic name, exact sourceCitation (e.g. "Page 3"), correctAnswer, and clear explanation.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                questions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      type: { type: Type.STRING },
                      topic: { type: Type.STRING },
                      question: { type: Type.STRING },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      correctAnswer: { type: Type.STRING },
                      explanation: { type: Type.STRING },
                      sourceCitation: { type: Type.STRING },
                    },
                    required: ['id', 'type', 'topic', 'question', 'correctAnswer', 'explanation', 'sourceCitation'],
                  },
                },
              },
              required: ['questions'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to generate questions.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 6. AI Essay / Practical / Code Grading
  app.post('/api/ai/grade-essay', requireFirebaseAuth, runtimeGate('aiExams', 'exams', 0.002), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { question, expectedAnswer, studentAnswer, lang = 'ar' } = req.body;
      if (!question || !studentAnswer) {
        res.status(400).json({ error: 'question and studentAnswer are required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Question: ${question}\nReference Answer: ${expectedAnswer || ''}\nStudent Answer: ${studentAnswer}\nFeedback Language: ${lang === 'en' ? 'English' : 'Arabic'}`,
          config: {
            systemInstruction:
              'Grade the university student answer fairly on a 0-10 scale. Mark isCorrect=true if score >= 6. Give constructive academic feedback explaining missing concepts or strengths.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                scoreOutOf10: { type: Type.NUMBER },
                isCorrect: { type: Type.BOOLEAN },
                feedback: { type: Type.STRING },
              },
              required: ['scoreOutOf10', 'isCorrect', 'feedback'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to grade essay answer.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 7. Contextual AI Chat (Lecture / Subject / General + Persona)
  app.post('/api/ai/chat', requireFirebaseAuth, runtimeGate('aiTutor', 'chat', 0.002), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { message, sourceMode = 'lecture', persona = 'professor', contextText = '', history = [], lang = 'ar' } = req.body;
      if (!message) {
        res.status(400).json({ error: 'message is required.' });
        return;
      }
      const modeRule =
        sourceMode === 'general'
          ? 'Use general university academic knowledge to help the student thoroughly.'
          : 'Answer STRICTLY using the provided lecture/subject material. Cite exact lecture titles and numeric page numbers (e.g. "Page 3" or "3") in citations so the student can jump straight to that page. If the answer is not present in the material, clearly state that it is not covered in the uploaded lecture(s).';

      const personaInstruction: Record<string, string> = {
        professor: 'Respond with academic depth, precision, and clear structured reasoning.',
        simple: 'Respond as a friendly Simple Tutor: start from fundamentals with simple words and everyday analogies.',
        exam_coach: 'Respond as an Exam Coach: highlight what professors typically test, common traps, and concise scoring points.',
        coding_mentor: 'Respond as a Coding Mentor: break down logic, trace variables step-by-step, and highlight implementation bugs/complexity.',
      };

      const historyStr = Array.isArray(history)
        ? history
            .slice(-6)
            .map((h: { role: string; text: string }) => `${h.role === 'user' ? 'Student' : 'Tutor'}: ${h.text}`)
            .join('\n')
        : '';

      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Recent Conversation:\n${historyStr}\n\nStudent Question: ${message}\n\nUploaded Course Context:\n${String(contextText).slice(0, 36000)}`,
          config: {
            systemInstruction: `You are an interactive AI University Tutor responding in ${lang === 'en' ? 'English' : 'Arabic with English technical terms where helpful'}. ${personaInstruction[persona] || personaInstruction.professor} ${modeRule}`,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                reply: { type: Type.STRING },
                citations: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      lectureTitle: { type: Type.STRING },
                      page: { type: Type.STRING },
                      excerpt: { type: Type.STRING },
                    },
                    required: ['lectureTitle', 'page', 'excerpt'],
                  },
                },
              },
              required: ['reply', 'citations'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to generate chat response.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 8. Camera / Photo Problem Solver
  app.post('/api/ai/solve-photo', requireFirebaseAuth, upload.single('image'), runtimeGate('aiCamera', 'imageSolver', 0.0035), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const file = req.file;
      const lang = req.body.lang || 'ar';
      if (!file) {
        res.status(400).json({ error: 'Please upload or capture an image of the problem.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: {
            parts: [
              { inlineData: { mimeType: file.mimetype || 'image/png', data: file.buffer.toString('base64') } },
              {
                text: `Analyze this university problem/question image and solve it in ${lang === 'en' ? 'English' : 'Arabic with clear mathematical/code notation'}. If any symbol, exponent, or line is blurry or illegible, set clarityStatus to "unclear" and explicitly describe what is ambiguous in unclearNote instead of guessing.`,
              },
            ],
          },
          config: {
            systemInstruction:
              'You are a careful STEM & Academic problem solver. Extract equations/text accurately, identify the topic, explain the underlying principle, walk through step-by-step, and state the final answer. Never guess illegible handwriting.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                clarityStatus: { type: Type.STRING },
                unclearNote: { type: Type.STRING },
                recognizedProblem: { type: Type.STRING },
                topic: { type: Type.STRING },
                coreConcept: { type: Type.STRING },
                steps: { type: Type.ARRAY, items: { type: Type.STRING } },
                finalAnswer: { type: Type.STRING },
              },
              required: ['clarityStatus', 'recognizedProblem', 'topic', 'coreConcept', 'steps', 'finalAnswer'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to solve image problem.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 9. Flashcards Generator
  app.post('/api/ai/flashcards', requireFirebaseAuth, runtimeGate('flashcards', 'flashcards', 0.0025), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { lectureTitle, fullText, count = 10, lang = 'ar' } = req.body;
      if (!fullText) {
        res.status(400).json({ error: 'fullText is required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Create ${Math.min(Math.max(Number(count) || 10, 4), 20)} spaced-repetition flashcards from "${lectureTitle || 'Lecture'}" in ${lang === 'en' ? 'English' : 'Arabic + English terms'}.\n\nContent:\n${String(fullText).slice(0, 35000)}`,
          config: {
            systemInstruction:
              'Generate concise, high-retention active recall flashcards. Front should be a sharp question or term; back should be a crisp accurate definition or answer grounded in the lecture.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                cards: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      front: { type: Type.STRING },
                      back: { type: Type.STRING },
                    },
                    required: ['front', 'back'],
                  },
                },
              },
              required: ['cards'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to generate flashcards.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 10. Mind Map Generator
  app.post('/api/ai/mindmap', requireFirebaseAuth, runtimeGate('mindMaps', 'mindMaps', 0.0025), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { lectureTitle, fullText, lang = 'ar' } = req.body;
      if (!fullText) {
        res.status(400).json({ error: 'fullText is required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Convert lecture "${lectureTitle || 'Lecture'}" into a hierarchical Mind Map JSON tree in ${lang === 'en' ? 'English' : 'Arabic with English technical terms'}.\n\nContent:\n${String(fullText).slice(0, 35000)}`,
          config: {
            systemInstruction:
              'Build a clear 3-level mind map tree (root -> 4-6 main topics -> 2-4 subtopics/definitions/formulas/classifications per topic). Keep node labels concise (3-7 words) and put concise definitions/laws in "detail".',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                rootNode: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    label: { type: Type.STRING },
                    category: { type: Type.STRING },
                    detail: { type: Type.STRING },
                    children: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          id: { type: Type.STRING },
                          label: { type: Type.STRING },
                          category: { type: Type.STRING },
                          detail: { type: Type.STRING },
                          children: {
                            type: Type.ARRAY,
                            items: {
                              type: Type.OBJECT,
                              properties: {
                                id: { type: Type.STRING },
                                label: { type: Type.STRING },
                                category: { type: Type.STRING },
                                detail: { type: Type.STRING },
                              },
                              required: ['id', 'label', 'category'],
                            },
                          },
                        },
                        required: ['id', 'label', 'category'],
                      },
                    },
                  },
                  required: ['id', 'label', 'category', 'children'],
                },
              },
              required: ['rootNode'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to generate mind map.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 11. Smart Study Plan Generator
  app.post('/api/ai/study-plan', requireFirebaseAuth, runtimeGate('studyPlanner', 'summarization', 0.0025), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { subjects, dailyHours = 3, startDate, lang = 'ar' } = req.body;
      if (!Array.isArray(subjects) || subjects.length === 0) {
        res.status(400).json({ error: 'At least one subject is required to build a study plan.' });
        return;
      }
      const today = startDate || new Date().toISOString().slice(0, 10);
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Start Date: ${today}\nDaily Available Hours: ${dailyHours}\nLanguage: ${lang === 'en' ? 'English' : 'Arabic'}\nSubjects Data: ${JSON.stringify(subjects)}`,
          config: {
            systemInstruction:
              'Design a realistic 7-to-14 day study schedule starting on Start Date. Allocate more time and extra review blocks to subjects with low understandingLevel, high priority, or nearer exam dates. Return YYYY-MM-DD scheduledDate values.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                tasks: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      subjectId: { type: Type.STRING },
                      subjectName: { type: Type.STRING },
                      title: { type: Type.STRING },
                      scheduledDate: { type: Type.STRING },
                      durationMinutes: { type: Type.INTEGER },
                      taskType: { type: Type.STRING },
                      priority: { type: Type.STRING },
                    },
                    required: ['subjectName', 'title', 'scheduledDate', 'durationMinutes', 'taskType', 'priority'],
                  },
                },
              },
              required: ['tasks'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to generate study plan.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 12. Voice Question Transcription (Speech-to-Text)
  app.post('/api/ai/transcribe-voice', requireFirebaseAuth, upload.single('audio'), runtimeGate('voiceTutor', 'voiceTutor', 0.003), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const file = req.file;
      if (!file) {
        res.status(400).json({ error: 'Audio recording is required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-3.5-transcribe',
          contents: {
            parts: [
              { inlineData: { mimeType: file.mimetype || 'audio/webm', data: file.buffer.toString('base64') } },
              { text: 'Transcribe this student voice question accurately in its spoken language (Arabic or English).' },
            ],
          },
        })
      );
      res.json({ text: (response.text || '').trim() });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 13. Text-to-Speech (TTS) for Explanations & Summaries
  app.post('/api/ai/tts', requireFirebaseAuth, runtimeGate('voiceTutor', 'voiceTutor', 0.003), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { text, voiceName = 'Kore', style = 'Clear, calm university lecturer' } = req.body;
      if (!text || String(text).trim().length === 0) {
        res.status(400).json({ error: 'Text is required for TTS.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: String(text).slice(0, 3500),
                  speechMetadata: { style },
                },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName },
              },
            },
          },
        })
      );
      const audioBase64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!audioBase64) {
        res.status(502).json({ error: 'TTS audio generation returned empty audio.' });
        return;
      }
      res.json({ audioBase64, mimeType: 'audio/wav' });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 14. AI Podcast Script Generator (Teacher & Student Dialogue)
  app.post('/api/ai/podcast', requireFirebaseAuth, runtimeGate('voiceTutor', 'voiceTutor', 0.003), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { lectureTitle, fullText, lengthMode = 'short', lang = 'ar' } = req.body;
      if (!lectureTitle || !fullText) {
        res.status(400).json({ error: 'lectureTitle and fullText are required.' });
        return;
      }
      const turnsTarget = lengthMode === 'long' ? '14 to 18 dialogue turns' : '8 to 10 dialogue turns';
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Create an engaging educational podcast dialogue based ONLY on this lecture: "${lectureTitle}".
Length: ${turnsTarget} (short spoken sentences ideal for audio listening).
Language: ${lang === 'en' ? 'Natural spoken academic English' : 'Clear spoken Arabic (العربية الفصحى المبسطة) preserving essential English technical terms'}.

Lecture Content:
${String(fullText).slice(0, 32000)}`,
          config: {
            systemInstruction:
              'You produce a smart university podcast featuring two speakers: "Professor" (warm, knowledgeable mentor) and "Student" (curious learner asking clarifying questions and recapping key insights). Output strictly valid JSON with title, summaryText, and scriptLines array.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                summaryText: { type: Type.STRING },
                scriptLines: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      speaker: { type: Type.STRING },
                      text: { type: Type.STRING },
                    },
                    required: ['speaker', 'text'],
                  },
                },
              },
              required: ['title', 'summaryText', 'scriptLines'],
            },
          },
        })
      );
      const parsed = parseJsonSafe<{
        title: string;
        summaryText: string;
        scriptLines: { speaker: string; text: string }[];
      }>(response.text, 'Failed to generate podcast script.');
      const normalizedLines = (parsed.scriptLines || []).map((line) => ({
        speaker: line.speaker?.toLowerCase().includes('stud') ? ('Student' as const) : ('Professor' as const),
        text: String(line.text || '').trim(),
      })).filter((l) => l.text.length > 0);
      res.json({
        title: parsed.title || lectureTitle,
        summaryText: parsed.summaryText || '',
        scriptLines: normalizedLines,
      });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 15. AI Podcast Multi-Speaker Audio Synthesis (gemini-3.8-flash-tts)
  app.post('/api/ai/podcast-audio', requireFirebaseAuth, runtimeGate('voiceTutor', 'voiceTutor', 0.0045), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { scriptLines, lang = 'ar' } = req.body;
      if (!Array.isArray(scriptLines) || scriptLines.length === 0) {
        res.status(400).json({ error: 'scriptLines array is required.' });
        return;
      }
      const screenplay = scriptLines
        .slice(0, 22)
        .map((line: { speaker: string; text: string }) => {
          const spk = line.speaker === 'Student' ? 'Student' : 'Professor';
          return `${spk}: ${String(line.text || '').trim()}`;
        })
        .join('\n')
        .slice(0, 6000);

      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-3.8-flash-tts',
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: `Read this ${lang === 'en' ? 'English' : 'Arabic'} university study podcast naturally:\n\n${screenplay}`,
                },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              multiSpeakerVoiceConfig: {
                speakerVoiceConfigs: [
                  {
                    speaker: 'Professor',
                    voiceConfig: {
                      prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                  },
                  {
                    speaker: 'Student',
                    voiceConfig: {
                      prebuiltVoiceConfig: { voiceName: 'Puck' },
                    },
                  },
                ],
              },
            },
          },
        })
      );
      const audioBase64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!audioBase64) {
        res.status(502).json({ error: 'Podcast audio synthesis returned empty audio.' });
        return;
      }
      res.json({ audioBase64, mimeType: 'audio/wav' });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 16. AI Interactive Whiteboard Vision Analyzer
  app.post('/api/ai/whiteboard-analyze', requireFirebaseAuth, runtimeGate('aiProblemSolver', 'imageSolver', 0.0035), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { imageBase64, mode = 'solve', prompt = '', lang = 'ar' } = req.body;
      if (!imageBase64 || typeof imageBase64 !== 'string') {
        res.status(400).json({ error: 'Whiteboard canvas image is required.' });
        return;
      }
      const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z+]+;base64,/, '');
      const modePrompts: Record<string, string> = {
        solve: 'Solve the mathematical problem, circuit, or academic exercise drawn on this whiteboard step-by-step and state the final answer clearly.',
        equation: 'Recognize the handwritten mathematical/scientific equations on this whiteboard, format them cleanly, verify algebraic steps, and compute the solution.',
        diagram: 'Explain the scientific, engineering, or software diagram sketched on this whiteboard, describing every component and relationship.',
        ocr: 'Accurately transcribe all handwritten notes, formulas, and labels drawn on this whiteboard into clean structured notes.',
        check: 'Check the student solution written on this whiteboard for errors. Point out what is correct, identify exact mistakes if any, and show the corrected steps.',
      };
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: {
            parts: [
              { inlineData: { mimeType: 'image/png', data: cleanBase64 } },
              {
                text: `${modePrompts[mode] || modePrompts.solve}\n${prompt ? `Student Note: ${String(prompt).slice(0, 500)}\n` : ''}Respond in ${lang === 'en' ? 'English' : 'clear Arabic with clean English equations/symbols'}.`,
              },
            ],
          },
          config: {
            systemInstruction:
              'You are a careful STEM & University Whiteboard Tutor. Read only what is clearly visible on the canvas. If parts are illegible or ambiguous, note them explicitly rather than guessing.',
          },
        })
      );
      res.json({ analysis: (response.text || '').trim() });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 17. Sandboxed Code Execution Runner (JS, Python, C, C++ live; honest status for Java)
  app.post('/api/code/run', requireFirebaseAuth, runtimeGate('codingPlayground'), async (req: AuthenticatedRequest, res: Response) => {
    const { language, code, stdin = '' } = req.body;
    if (!language || typeof code !== 'string' || code.trim().length === 0) {
      res.status(400).json({ error: 'language and code are required.' });
      return;
    }
    if (code.length > 50000) {
      res.status(400).json({ error: 'Code exceeds maximum 50KB limit.' });
      return;
    }
    if (language === 'java') {
      res.json({
        success: false,
        stdout: '',
        stderr: 'Java JDK (javac/java) is not installed in this Linux container sandbox. Use "AI Code Mentor" to trace logic, check syntax, and analyze complexity, or run JavaScript / Python / C / C++ live.',
        exitCode: 1,
        executionMs: 0,
      });
      return;
    }

    const supported = ['javascript', 'python', 'c', 'cpp'];
    if (!supported.includes(language)) {
      res.status(400).json({ error: `Unsupported runtime language: ${language}` });
      return;
    }

    const runProcess = (
      cmd: string,
      args: string[],
      cwd: string,
      inputText: string,
      timeoutMs = 5000
    ): Promise<{ stdout: string; stderr: string; exitCode: number; timedOut: boolean }> =>
      new Promise((resolve) => {
        const child = spawn(cmd, args, {
          cwd,
          shell: false,
          env: { PATH: process.env.PATH || '/usr/local/bin:/usr/bin:/bin', HOME: cwd, TMPDIR: cwd },
        });
        let stdout = '';
        let stderr = '';
        let timedOut = false;
        const cap = 64 * 1024;

        const timer = setTimeout(() => {
          timedOut = true;
          child.kill('SIGKILL');
        }, timeoutMs);

        child.stdout.on('data', (chunk: Buffer) => {
          if (stdout.length < cap) stdout += chunk.toString('utf-8').slice(0, cap - stdout.length);
        });
        child.stderr.on('data', (chunk: Buffer) => {
          if (stderr.length < cap) stderr += chunk.toString('utf-8').slice(0, cap - stderr.length);
        });
        child.on('error', (err) => {
          clearTimeout(timer);
          resolve({ stdout, stderr: stderr + err.message, exitCode: 1, timedOut });
        });
        child.on('close', (codeVal) => {
          clearTimeout(timer);
          resolve({
            stdout,
            stderr: timedOut ? `${stderr}\n[Execution timed out after ${timeoutMs / 1000}s]` : stderr,
            exitCode: codeVal ?? 1,
            timedOut,
          });
        });

        if (inputText) {
          child.stdin.write(String(inputText).slice(0, 8192));
        }
        child.stdin.end();
      });

    const tmpDir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'ss-code-'));
    const started = Date.now();
    try {
      if (language === 'javascript') {
        const filePath = path.join(tmpDir, 'main.mjs');
        await fs.promises.writeFile(filePath, code, 'utf-8');
        const out = await runProcess('node', ['--max-old-space-size=64', filePath], tmpDir, stdin);
        res.json({
          success: out.exitCode === 0 && !out.timedOut,
          stdout: out.stdout,
          stderr: out.stderr,
          exitCode: out.exitCode,
          executionMs: Date.now() - started,
        });
        return;
      }

      if (language === 'python') {
        const filePath = path.join(tmpDir, 'main.py');
        await fs.promises.writeFile(filePath, code, 'utf-8');
        const out = await runProcess('python3', ['-I', filePath], tmpDir, stdin);
        res.json({
          success: out.exitCode === 0 && !out.timedOut,
          stdout: out.stdout,
          stderr: out.stderr,
          exitCode: out.exitCode,
          executionMs: Date.now() - started,
        });
        return;
      }

      const isCpp = language === 'cpp';
      const srcPath = path.join(tmpDir, isCpp ? 'main.cpp' : 'main.c');
      const binPath = path.join(tmpDir, 'program');
      await fs.promises.writeFile(srcPath, code, 'utf-8');
      const compiler = isCpp ? 'g++' : 'gcc';
      const compileOut = await runProcess(compiler, [srcPath, '-O2', '-o', binPath], tmpDir, '', 7000);
      if (compileOut.exitCode !== 0 || compileOut.timedOut) {
        res.json({
          success: false,
          stdout: compileOut.stdout,
          stderr: compileOut.stderr || 'Compilation failed.',
          exitCode: compileOut.exitCode,
          executionMs: Date.now() - started,
        });
        return;
      }
      const runOut = await runProcess(binPath, [], tmpDir, stdin);
      res.json({
        success: runOut.exitCode === 0 && !runOut.timedOut,
        stdout: runOut.stdout,
        stderr: runOut.stderr,
        exitCode: runOut.exitCode,
        executionMs: Date.now() - started,
      });
    } catch (err) {
      sendApiError(res, err);
    } finally {
      await fs.promises.rm(tmpDir, { recursive: true, force: true }).catch(() => {});
    }
  });

  // 18. AI Code Mentor (Explain, Debug, Optimize)
  app.post('/api/ai/code-mentor', requireFirebaseAuth, runtimeGate('codingPlayground', 'chat', 0.0025), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { language, code, stderr = '', action = 'review', lang = 'ar' } = req.body;
      if (!code) {
        res.status(400).json({ error: 'code is required.' });
        return;
      }
      const actionPrompts: Record<string, string> = {
        review: 'Review this code for correctness, edge cases, Big-O time/space complexity, and clean improvements.',
        debug: 'Diagnose why this code failed or misbehaves based on the error output, explain the bug clearly, and provide corrected code.',
        explain: 'Explain this code line-by-line and algorithmically so a computer science student understands how it executes.',
      };
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Language: ${language}\nTask: ${actionPrompts[action] || actionPrompts.review}\nResponse Language: ${lang === 'en' ? 'English' : 'Arabic with English technical terms and code'}\n\nCode:\n\`\`\`${language}\n${String(code).slice(0, 20000)}\n\`\`\`\n${stderr ? `\nCompiler/Runtime Error:\n${String(stderr).slice(0, 4000)}` : ''}`,
          config: {
            systemInstruction:
              'You are an expert Computer Science Coding Mentor. Be concise, educational, and provide working fixed/improved snippets when helpful.',
          },
        })
      );
      res.json({ review: (response.text || '').trim() });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 19. AI Exam Prediction Engine (Content-Frequency Analysis + Disclaimer)
  app.post('/api/ai/exam-predict', requireFirebaseAuth, runtimeGate('aiExams', 'exams', 0.0035), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { subjectName, lecturesText, pastExamText = '', lang = 'ar' } = req.body;
      if (!lecturesText) {
        res.status(400).json({ error: 'lecturesText is required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Subject: ${subjectName || 'Course'}\nLanguage: ${lang === 'en' ? 'English' : 'Arabic with English technical terms'}\n\nCourse Lectures Content:\n${String(lecturesText).slice(0, 32000)}\n\n${pastExamText ? `Past Exam / Sample Questions Uploaded by Student:\n${String(pastExamText).slice(0, 12000)}` : ''}`,
          config: {
            systemInstruction:
              'Analyze the uploaded lectures (and optional past exam) to estimate recurring high-weight concepts, core definitions, and likely exam practice topics based on topic emphasis and syllabus structure. Clearly note that these are study estimates, not guaranteed real exam questions.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                disclaimer: { type: Type.STRING },
                recurringTopics: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      topic: { type: Type.STRING },
                      importanceScore: { type: Type.INTEGER },
                      rationale: { type: Type.STRING },
                    },
                    required: ['topic', 'importanceScore', 'rationale'],
                  },
                },
                predictedQuestions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      type: { type: Type.STRING },
                      topic: { type: Type.STRING },
                      question: { type: Type.STRING },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      correctAnswer: { type: Type.STRING },
                      explanation: { type: Type.STRING },
                      sourceCitation: { type: Type.STRING },
                    },
                    required: ['id', 'type', 'topic', 'question', 'correctAnswer', 'explanation', 'sourceCitation'],
                  },
                },
              },
              required: ['disclaimer', 'recurringTopics', 'predictedQuestions'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to analyze exam predictions.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 20. Lecture Translator (AR <-> EN keeping scientific terms + glossary)
  app.post('/api/ai/translate', requireFirebaseAuth, runtimeGate('lectureExplanation', 'translation', 0.0025), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { text, targetLang = 'ar' } = req.body;
      if (!text || String(text).trim().length === 0) {
        res.status(400).json({ error: 'Text to translate is required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Translate this academic lecture excerpt into ${targetLang === 'en' ? 'clear Academic English' : 'clear Academic Arabic (العربية الفصحى المبسطة)'}. Keep key scientific/programming terminology alongside its translation so university students learn both.\n\nText:\n${String(text).slice(0, 16000)}`,
          config: {
            systemInstruction:
              'Provide an accurate, faithful academic translation preserving formulas/code and extracting a concise bilingual glossary of technical terms.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                translatedText: { type: Type.STRING },
                glossary: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      originalTerm: { type: Type.STRING },
                      translatedTerm: { type: Type.STRING },
                      note: { type: Type.STRING },
                    },
                    required: ['originalTerm', 'translatedTerm'],
                  },
                },
              },
              required: ['translatedText', 'glossary'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to translate lecture content.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 21. Revision / Cram Mode Generator (Single Lecture or Full Subject)
  app.post('/api/ai/revision-pack', requireFirebaseAuth, runtimeGate('adaptiveLearning', 'summarization', 0.003), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { title, sourceText, weakTopics = [], lang = 'ar' } = req.body;
      if (!sourceText) {
        res.status(400).json({ error: 'sourceText is required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Build a fast Exam-Night Revision Pack for "${title || 'Course'}" in ${lang === 'en' ? 'English' : 'Arabic with English scientific terms'}.\nPrioritize these weak areas if relevant: ${Array.isArray(weakTopics) ? weakTopics.join(', ') : ''}\n\nSource Material:\n${String(sourceText).slice(0, 40000)}`,
          config: {
            systemInstruction:
              'Create a crisp, ultra-scannable pre-exam cram pack containing: rapidBulletSummary, mustKnowDefinitions, keyFormulasOrRules, comparisons, and rapidQaCheck.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                rapidBulletSummary: { type: Type.ARRAY, items: { type: Type.STRING } },
                mustKnowDefinitions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: { term: { type: Type.STRING }, definition: { type: Type.STRING } },
                    required: ['term', 'definition'],
                  },
                },
                keyFormulasOrRules: { type: Type.ARRAY, items: { type: Type.STRING } },
                rapidQaCheck: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: { question: { type: Type.STRING }, answer: { type: Type.STRING } },
                    required: ['question', 'answer'],
                  },
                },
              },
              required: ['rapidBulletSummary', 'mustKnowDefinitions', 'keyFormulasOrRules', 'rapidQaCheck'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed to generate revision pack.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 22. Weekly AI Performance Report (Grounded in Real Metrics)
  app.post('/api/ai/weekly-report', requireFirebaseAuth, runtimeGate('adaptiveLearning', 'summarization', 0.002), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { metrics, lang = 'ar' } = req.body;
      if (!metrics || typeof metrics !== 'object') {
        res.status(400).json({ error: 'metrics object is required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Analyze these real university student study metrics and write an encouraging, actionable weekly progress report in ${lang === 'en' ? 'English' : 'Arabic'}:\n${JSON.stringify(metrics)}`,
          config: {
            systemInstruction:
              'Ground every number strictly in the supplied metrics object. Highlight achievements, weak exam topics to revisit, and 3 concrete actions for next week.',
          },
        })
      );
      res.json({ report: (response.text || '').trim() });
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // 23. Semantic Smart Search Ranking across Student Corpus
  app.post('/api/ai/semantic-search', requireFirebaseAuth, runtimeGate('smartSearch', 'chat', 0.002), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { queryText, items, lang = 'ar' } = req.body;
      if (!queryText || !Array.isArray(items) || items.length === 0) {
        res.status(400).json({ error: 'queryText and indexed items are required.' });
        return;
      }
      const ai = getGeminiClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Student Search Query: "${String(queryText).slice(0, 300)}"\nLanguage: ${lang}\n\nIndexed Items:\n${JSON.stringify(items.slice(0, 40))}`,
          config: {
            systemInstruction:
              'Return the top 8 most semantically relevant item IDs with a short reason explaining why each matches the student query.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                matches: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      type: { type: Type.STRING },
                      reason: { type: Type.STRING },
                    },
                    required: ['id', 'type', 'reason'],
                  },
                },
              },
              required: ['matches'],
            },
          },
        })
      );
      res.json(parseJsonSafe(response.text, 'Failed semantic search.'));
    } catch (err) {
      sendApiError(res, err);
    }
  });

  // Developer Control Center, Unified Login & Student Runtime Telemetry Routes
  registerControlCenterRoutes(app, adminApp, requireFirebaseAuth as (req: Request, res: Response, next: NextFunction) => Promise<void>);

  // Vite dev middleware or production static build
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SmartScholar AI server running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
