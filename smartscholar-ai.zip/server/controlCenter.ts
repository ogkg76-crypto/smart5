import crypto from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { Request, Response, NextFunction } from 'express';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';
import { App as AdminApp } from 'firebase-admin/app';
import {
  AcademicContentNode,
  AdminAccountPublic,
  AdminRoleType,
  AiServiceConfig,
  AppSettingsConfig,
  AuditLogEntry,
  BackupSnapshotInfo,
  ControlPaymentRecord,
  ControlPlanConfig,
  ControlPromoConfig,
  ControlUserRecord,
  DevSessionUser,
  FeatureFlagConfig,
  PublicRuntimeConfig,
  SupportTicket,
  TargetedNotificationRecord,
} from '../src/types';

export const PRIMARY_OWNER_EMAIL = 'shadow1@gmail.com';
export const FIREBASE_ADMIN_EMAIL = 'khaledsayed46829@gmail.com';

const DATA_DIR = path.resolve(process.cwd(), '.data');
const STORE_FILE = path.resolve(DATA_DIR, 'control-center.json');
const BACKUP_DIR = path.resolve(DATA_DIR, 'backups');

const SESSION_SECRET = process.env.DEV_SESSION_SECRET || crypto.randomBytes(32).toString('hex');

interface AdminAccountInternal {
  id: string;
  email: string;
  displayName: string;
  role: AdminRoleType;
  permissions: string[];
  passwordHash: string | null;
  mustChangePassword: boolean;
  twoFactorEnabled: boolean;
  totpSecret: string | null;
  sessionVersion: number;
  lastLoginAt?: string;
  createdAt: string;
}

interface TelemetryEvent {
  id: string;
  type: 'login' | 'ai' | 'payment' | 'feature' | 'error' | 'user' | 'admin';
  label: string;
  detail: string;
  serviceId?: string;
  model?: string;
  latencyMs?: number;
  costUsd?: number;
  success?: boolean;
  createdAt: string;
}

interface ControlCenterStore {
  adminAccounts: AdminAccountInternal[];
  usersRegistry: ControlUserRecord[];
  plans: ControlPlanConfig[];
  promoCodes: ControlPromoConfig[];
  payments: ControlPaymentRecord[];
  aiServices: AiServiceConfig[];
  featureFlags: FeatureFlagConfig[];
  contentNodes: AcademicContentNode[];
  notifications: TargetedNotificationRecord[];
  pendingUserNotifications: Record<
    string,
    { id: string; title: string; body: string; linkSection?: string; createdAt: string }[]
  >;
  supportTickets: SupportTicket[];
  auditLogs: AuditLogEntry[];
  telemetryEvents: TelemetryEvent[];
  appSettings: AppSettingsConfig;
}

const DEFAULT_ROLE_PERMISSIONS: Record<AdminRoleType, string[]> = {
  owner: [
    'overview',
    'users',
    'subscriptions',
    'ai_control',
    'features',
    'content',
    'notifications',
    'support',
    'analytics',
    'monitoring',
    'audit_logs',
    'backups',
    'cost_simulator',
    'app_settings',
    'profile',
    'manage_roles',
  ],
  admin: [
    'overview',
    'users',
    'subscriptions',
    'ai_control',
    'features',
    'content',
    'notifications',
    'support',
    'analytics',
    'monitoring',
    'cost_simulator',
    'app_settings',
    'profile',
  ],
  support: ['overview', 'users', 'notifications', 'support', 'profile'],
  content_manager: ['overview', 'content', 'features', 'profile'],
};

function createInitialStore(): ControlCenterStore {
  const now = new Date().toISOString();
  return {
    adminAccounts: [
      {
        id: 'owner_shadow1',
        email: PRIMARY_OWNER_EMAIL,
        displayName: 'Platform Owner',
        role: 'owner',
        permissions: [...DEFAULT_ROLE_PERMISSIONS.owner],
        passwordHash: null,
        mustChangePassword: false,
        twoFactorEnabled: false,
        totpSecret: null,
        sessionVersion: 1,
        createdAt: now,
      },
    ],
    usersRegistry: [],
    plans: [
      {
        id: 'free',
        nameAr: 'Free — الباقة المجانية',
        nameEn: 'Free Plan',
        priceMonthly: 0,
        durationDays: 30,
        currency: 'USD',
        aiRequestLimit: 30,
        storageLimitMb: 150,
        maxFilesCount: 15,
        maxExamsCount: 10,
        featuresAr: ['30 طلب ذكاء اصطناعي شهرياً', '150 ميجابايت تخزين', 'الشرح والملخصات الأساسية'],
        featuresEn: ['30 AI requests/month', '150 MB storage', 'Core AI explanations & summaries'],
        discountPercent: 0,
        googlePlayProductId: 'smart_student_free',
        isActive: true,
      },
      {
        id: 'pro',
        nameAr: 'Premium — باقة الطالب المميز',
        nameEn: 'Premium',
        priceMonthly: 9,
        durationDays: 30,
        currency: 'USD',
        aiRequestLimit: 400,
        storageLimitMb: 3072,
        maxFilesCount: 200,
        maxExamsCount: 150,
        featuresAr: ['400 طلب ذكاء اصطناعي شهرياً', '3 جيجابايت تخزين', 'البودكاست والسبورة ومختبر البرمجة'],
        featuresEn: ['400 AI requests/month', '3 GB storage', 'AI Podcast, Whiteboard & Coding Lab'],
        discountPercent: 0,
        googlePlayProductId: 'smart_student_premium_monthly',
        isActive: true,
      },
      {
        id: 'elite',
        nameAr: 'Premium Plus — التميز الجامعي',
        nameEn: 'Premium Plus',
        priceMonthly: 19,
        durationDays: 30,
        currency: 'USD',
        aiRequestLimit: 1500,
        storageLimitMb: 15360,
        maxFilesCount: 1000,
        maxExamsCount: 1000,
        featuresAr: ['1500 طلب ذكاء اصطناعي شهرياً', '15 جيجابايت تخزين', 'توقعات الامتحانات ومراجعة المادة الكاملة'],
        featuresEn: ['1500 AI requests/month', '15 GB storage', 'Exam prediction & full-subject cram'],
        discountPercent: 15,
        googlePlayProductId: 'smart_student_premium_plus_monthly',
        isActive: true,
      },
    ],
    promoCodes: [],
    payments: [],
    aiServices: [
      {
        id: 'lectureExplanation',
        name: 'AI Lecture Explanation',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 42000,
        perUserDailyLimit: 50,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 25,
        monthlyBudgetUsd: 500,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'summarization',
        name: 'AI Summarization',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 42000,
        perUserDailyLimit: 50,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 20,
        monthlyBudgetUsd: 400,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'questionGenerator',
        name: 'AI Question Generator',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 42000,
        perUserDailyLimit: 40,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 20,
        monthlyBudgetUsd: 400,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'exams',
        name: 'AI Exams & Prediction',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 42000,
        perUserDailyLimit: 30,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 20,
        monthlyBudgetUsd: 450,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'chat',
        name: 'AI Chat & Search',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 15,
        maxLectureLength: 36000,
        perUserDailyLimit: 100,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 25,
        monthlyBudgetUsd: 500,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'voiceTutor',
        name: 'AI Voice Tutor & Podcast Audio',
        provider: 'gemini',
        model: 'gemini-3.8-flash-lite-tts',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 10000,
        perUserDailyLimit: 25,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 20,
        monthlyBudgetUsd: 400,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'imageSolver',
        name: 'AI Image & Whiteboard Solver',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 20,
        maxLectureLength: 16000,
        perUserDailyLimit: 40,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 20,
        monthlyBudgetUsd: 350,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'mindMaps',
        name: 'AI Mind Maps',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 35000,
        perUserDailyLimit: 30,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 15,
        monthlyBudgetUsd: 300,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'flashcards',
        name: 'AI Flashcards',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 35000,
        perUserDailyLimit: 30,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 15,
        monthlyBudgetUsd: 300,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'translation',
        name: 'AI Translation',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 15,
        maxLectureLength: 16000,
        perUserDailyLimit: 40,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 15,
        monthlyBudgetUsd: 300,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'presentationGenerator',
        name: 'AI Presentation Generator',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 35000,
        perUserDailyLimit: 20,
        allowedPlans: ['pro', 'elite'],
        dailyBudgetUsd: 15,
        monthlyBudgetUsd: 300,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
      {
        id: 'videoGeneration',
        name: 'AI Video Analysis & Generation',
        provider: 'gemini',
        model: 'gemini-4-hydrogen',
        enabled: true,
        maxFileSizeMb: 25,
        maxLectureLength: 45000,
        perUserDailyLimit: 15,
        allowedPlans: ['free', 'pro', 'elite'],
        dailyBudgetUsd: 30,
        monthlyBudgetUsd: 600,
        autoStopOnBudget: true,
        successCount: 0,
        failedCount: 0,
        totalLatencyMs: 0,
        estimatedCostUsd: 0,
      },
    ],
    featureFlags: [
      { id: 'aiTutor', nameAr: 'المدرس الذكي', nameEn: 'AI Tutor', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'المدرس الذكي في صيانة مؤقتة.', maintenanceMessageEn: 'AI Tutor is under brief maintenance.', usageCount: 0 },
      { id: 'lectureExplanation', nameAr: 'شرح المحاضرات', nameEn: 'Lecture Explanation', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'خدمة الشرح في وضع الصيانة.', maintenanceMessageEn: 'Explanation service is in maintenance.', usageCount: 0 },
      { id: 'pdfUpload', nameAr: 'رفع ملفات PDF', nameEn: 'PDF Upload', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'رفع PDF متوقف مؤقتاً للصيانة.', maintenanceMessageEn: 'PDF upload is paused for maintenance.', usageCount: 0 },
      { id: 'audioProcessing', nameAr: 'معالجة الصوت', nameEn: 'Audio Processing', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'معالجة الصوت في وضع الصيانة.', maintenanceMessageEn: 'Audio processing is under maintenance.', usageCount: 0 },
      { id: 'videoProcessing', nameAr: 'معالجة الفيديو', nameEn: 'Video Processing', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'معالجة الفيديو في وضع الصيانة.', maintenanceMessageEn: 'Video processing is under maintenance.', usageCount: 0 },
      { id: 'flashcards', nameAr: 'البطاقات التعليمية', nameEn: 'Flashcards', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'البطاقات في وضع الصيانة.', maintenanceMessageEn: 'Flashcards are under maintenance.', usageCount: 0 },
      { id: 'mindMaps', nameAr: 'الخرائط الذهنية', nameEn: 'Mind Maps', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'الخرائط الذهنية في وضع الصيانة.', maintenanceMessageEn: 'Mind maps are under maintenance.', usageCount: 0 },
      { id: 'aiExams', nameAr: 'الامتحانات الذكية', nameEn: 'AI Exams', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'الامتحانات في وضع الصيانة.', maintenanceMessageEn: 'AI Exams are under maintenance.', usageCount: 0 },
      { id: 'aiCamera', nameAr: 'حل المسائل بالكاميرا', nameEn: 'AI Camera', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'الكاميرا الذكية في وضع الصيانة.', maintenanceMessageEn: 'AI Camera is under maintenance.', usageCount: 0 },
      { id: 'voiceTutor', nameAr: 'المعلم الصوتي والبودكاست', nameEn: 'Voice Tutor', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'المعلم الصوتي في وضع الصيانة.', maintenanceMessageEn: 'Voice Tutor is under maintenance.', usageCount: 0 },
      { id: 'codingPlayground', nameAr: 'مختبر البرمجة', nameEn: 'Coding Playground', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'مختبر البرمجة في وضع الصيانة.', maintenanceMessageEn: 'Coding Playground is under maintenance.', usageCount: 0 },
      { id: 'groupStudy', nameAr: 'المذاكرة الجماعية والتحديات', nameEn: 'Group Study', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'المذاكرة الجماعية في وضع الصيانة.', maintenanceMessageEn: 'Group Study is under maintenance.', usageCount: 0 },
      { id: 'studyPlanner', nameAr: 'مخطط المذاكرة', nameEn: 'Study Planner', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'المخطط في وضع الصيانة.', maintenanceMessageEn: 'Study Planner is under maintenance.', usageCount: 0 },
      { id: 'threeDLearning', nameAr: 'التعلم ثلاثي الأبعاد', nameEn: '3D Learning', status: 'beta', allowedPlans: ['pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'التعلم ثلاثي الأبعاد متاح تجريبياً.', maintenanceMessageEn: '3D Learning is in beta rollout.', usageCount: 0 },
      { id: 'pptxGenerator', nameAr: 'تحليل وإنشاء PowerPoint', nameEn: 'PowerPoint Generator', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'عروض PowerPoint في وضع الصيانة.', maintenanceMessageEn: 'PowerPoint tool is under maintenance.', usageCount: 0 },
      { id: 'smartSearch', nameAr: 'البحث الذكي', nameEn: 'Smart Search', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'البحث الذكي في وضع الصيانة.', maintenanceMessageEn: 'Smart Search is under maintenance.', usageCount: 0 },
      { id: 'notifications', nameAr: 'الإشعارات', nameEn: 'Notifications', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'الإشعارات في وضع الصيانة.', maintenanceMessageEn: 'Notifications are under maintenance.', usageCount: 0 },
      { id: 'offlineMode', nameAr: 'العمل دون اتصال', nameEn: 'Offline Mode', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'العمل دون اتصال في وضع الصيانة.', maintenanceMessageEn: 'Offline Mode is under maintenance.', usageCount: 0 },
      { id: 'adaptiveLearning', nameAr: 'التعلم التكيفي والمراجعة', nameEn: 'Adaptive Learning', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'التعلم التكيفي في وضع الصيانة.', maintenanceMessageEn: 'Adaptive Learning is under maintenance.', usageCount: 0 },
      { id: 'aiProblemSolver', nameAr: 'السبورة الذكية وحل المسائل', nameEn: 'AI Problem Solver', status: 'all', allowedPlans: ['free', 'pro', 'elite'], betaEmails: [], maintenanceMessageAr: 'السبورة وحل المسائل في وضع الصيانة.', maintenanceMessageEn: 'AI Problem Solver is under maintenance.', usageCount: 0 },
    ],
    contentNodes: [],
    notifications: [],
    pendingUserNotifications: {},
    supportTickets: [],
    auditLogs: [],
    telemetryEvents: [],
    appSettings: {
      appName: 'Smart Student',
      appDescription: 'AI-Powered University Learning Platform',
      logoUrl: '',
      officialEmail: 'support@smartstudent.app',
      socialWebsite: 'https://smartstudent.app',
      socialTwitter: '@smartstudent_ai',
      socialTelegram: 't.me/smartstudent_ai',
      privacyPolicyText: 'All student lectures and analytics remain private to each student account.',
      termsOfServiceText: 'Use AI tools responsibly for university coursework and exam preparation.',
      androidStoreUrl: '',
      iosStoreUrl: '',
      availableLanguages: ['ar', 'en'],
      maxFileSizeMb: 25,
      maintenanceMode: false,
      minVersion: '1.0.0',
      forceUpdateMessage: 'A newer version of Smart Student is required. Please update.',
      backupSchedule: 'daily',
      retentionCount: 10,
    },
  };
}

function loadStore(): ControlCenterStore {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  if (!fs.existsSync(STORE_FILE)) {
    const initial = createInitialStore();
    fs.writeFileSync(STORE_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  try {
    const raw = fs.readFileSync(STORE_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<ControlCenterStore>;
    const defaults = createInitialStore();
    return {
      ...defaults,
      ...parsed,
      adminAccounts: parsed.adminAccounts?.length ? parsed.adminAccounts : defaults.adminAccounts,
      plans: parsed.plans?.length ? parsed.plans : defaults.plans,
      aiServices: parsed.aiServices?.length ? parsed.aiServices : defaults.aiServices,
      featureFlags: parsed.featureFlags?.length ? parsed.featureFlags : defaults.featureFlags,
      appSettings: { ...defaults.appSettings, ...(parsed.appSettings || {}) },
    };
  } catch {
    return createInitialStore();
  }
}

let store: ControlCenterStore = loadStore();

function saveStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmpFile = path.resolve(DATA_DIR, `control-center.${Date.now()}.tmp`);
  fs.writeFileSync(tmpFile, JSON.stringify(store, null, 2), 'utf-8');
  fs.renameSync(tmpFile, STORE_FILE);
}

// Secure password hashing (Node built-in scrypt + 16-byte random salt)
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPasswordHash(password: string, stored: string): boolean {
  const [salt, expectedHex] = stored.split(':');
  if (!salt || !expectedHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHex, 'hex');
  if (derived.length !== expected.length) return false;
  return crypto.timingSafeEqual(derived, expected);
}

// RFC 6238 TOTP (2FA)
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Encode(buf: Buffer): string {
  let bits = 0;
  let value = 0;
  let out = '';
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    out += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  }
  return out;
}

function base32Decode(str: string): Buffer {
  const cleaned = str.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0;
  let value = 0;
  const bytes: number[] = [];
  for (const ch of cleaned) {
    const idx = BASE32_ALPHABET.indexOf(ch);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(bytes);
}

function computeTotp(secretBase32: string, stepOffset = 0): string {
  const key = base32Decode(secretBase32);
  const counter = Math.floor(Date.now() / 1000 / 30) + stepOffset;
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac('sha1', key).update(msg).digest();
  const offset = hmac[hmac.length - 1] & 0xf;
  const code =
    (((hmac[offset] & 0x7f) << 24) |
      ((hmac[offset + 1] & 0xff) << 16) |
      ((hmac[offset + 2] & 0xff) << 8) |
      (hmac[offset + 3] & 0xff)) %
    1_000_000;
  return String(code).padStart(6, '0');
}

function verifyTotp(secretBase32: string, code: string): boolean {
  const clean = String(code || '').trim();
  if (!/^\d{6}$/.test(clean)) return false;
  for (const offset of [-1, 0, 1]) {
    const expected = computeTotp(secretBase32, offset);
    if (crypto.timingSafeEqual(Buffer.from(clean), Buffer.from(expected))) {
      return true;
    }
  }
  return false;
}

interface TokenPayload {
  id: string;
  email: string;
  role: AdminRoleType;
  sv: number;
  exp: number;
}

function issueDevToken(acc: AdminAccountInternal): string {
  const payload: TokenPayload = {
    id: acc.id,
    email: acc.email,
    role: acc.role,
    sv: acc.sessionVersion,
    exp: Date.now() + 24 * 60 * 60 * 1000,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf-8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `dev.${encoded}.${sig}`;
}

function verifyDevToken(token: string): AdminAccountInternal | null {
  if (!token.startsWith('dev.')) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [, encoded, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  if (sig.length !== expectedSig.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) return null;
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf-8')) as TokenPayload;
    if (!payload.exp || payload.exp < Date.now()) return null;
    const acc = store.adminAccounts.find(
      (a) => a.id === payload.id && a.email.toLowerCase() === payload.email.toLowerCase()
    );
    if (!acc || acc.sessionVersion !== payload.sv) return null;
    return acc;
  } catch {
    return null;
  }
}

function sanitizeAdminPublic(acc: AdminAccountInternal): AdminAccountPublic {
  return {
    id: acc.id,
    email: acc.email,
    displayName: acc.displayName,
    role: acc.role,
    permissions: acc.permissions,
    twoFactorEnabled: acc.twoFactorEnabled,
    lastLoginAt: acc.lastLoginAt,
    createdAt: acc.createdAt,
  };
}

function toSessionUser(acc: AdminAccountInternal): DevSessionUser {
  return {
    id: acc.id,
    email: acc.email,
    displayName: acc.displayName,
    role: acc.role,
    permissions: acc.permissions,
    mustChangePassword: acc.mustChangePassword,
    twoFactorEnabled: acc.twoFactorEnabled,
  };
}

export function addAuditLog(params: {
  actorEmail: string;
  actorRole: AdminRoleType;
  action: string;
  target: string;
  details: string;
  status?: 'success' | 'denied' | 'failed';
}) {
  const entry: AuditLogEntry = {
    id: `aud_${Date.now().toString(36)}_${crypto.randomBytes(3).toString('hex')}`,
    actorEmail: params.actorEmail,
    actorRole: params.actorRole,
    action: params.action,
    target: params.target,
    details: params.details.slice(0, 400),
    status: params.status || 'success',
    createdAt: new Date().toISOString(),
  };
  store.auditLogs.unshift(entry);
  if (store.auditLogs.length > 500) store.auditLogs = store.auditLogs.slice(0, 500);
  saveStore();
}

export function recordTelemetryEvent(evt: Omit<TelemetryEvent, 'id' | 'createdAt'>) {
  const full: TelemetryEvent = {
    ...evt,
    id: `evt_${Date.now().toString(36)}_${crypto.randomBytes(3).toString('hex')}`,
    createdAt: new Date().toISOString(),
  };
  store.telemetryEvents.unshift(full);
  if (store.telemetryEvents.length > 1000) store.telemetryEvents = store.telemetryEvents.slice(0, 1000);
  saveStore();
}

// Login brute-force limiter (10 attempts / 10 min per IP+email)
const loginAttempts = new Map<string, number[]>();
function checkLoginRateLimit(key: string): boolean {
  const now = Date.now();
  const list = (loginAttempts.get(key) || []).filter((t) => now - t < 10 * 60_000);
  if (list.length >= 10) {
    loginAttempts.set(key, list);
    return false;
  }
  list.push(now);
  loginAttempts.set(key, list);
  return true;
}

// Student runtime gate enforced inside AI/extract routes
export function enforceStudentRuntimeGate(params: {
  uid: string;
  email?: string;
  featureId: string;
  aiServiceId?: string;
  fileSizeBytes?: number;
}): { allowed: boolean; status: number; reason?: string } {
  if (store.appSettings.maintenanceMode) {
    return {
      allowed: false,
      status: 503,
      reason: 'Smart Student is temporarily in maintenance mode. Please try again shortly.',
    };
  }
  const userRec = store.usersRegistry.find((u) => u.uid === params.uid);
  if (userRec?.status === 'suspended') {
    return {
      allowed: false,
      status: 403,
      reason: 'Your account has been suspended by the administrator.',
    };
  }
  const userPlan = userRec?.planId || 'free';
  const flag = store.featureFlags.find((f) => f.id === params.featureId);
  if (flag) {
    flag.usageCount += 1;
    if (flag.status === 'disabled') {
      saveStore();
      return { allowed: false, status: 403, reason: `${flag.nameEn} is currently disabled.` };
    }
    if (flag.status === 'maintenance') {
      saveStore();
      return {
        allowed: false,
        status: 503,
        reason: flag.maintenanceMessageEn || `${flag.nameEn} is under maintenance.`,
      };
    }
    if (flag.status === 'plans' && !flag.allowedPlans.includes(userPlan)) {
      saveStore();
      return {
        allowed: false,
        status: 403,
        reason: `${flag.nameEn} requires upgrading your subscription plan.`,
      };
    }
    if (
      flag.status === 'beta' &&
      flag.betaEmails.length > 0 &&
      params.email &&
      !flag.betaEmails.map((e) => e.toLowerCase()).includes(params.email.toLowerCase()) &&
      !flag.allowedPlans.includes(userPlan)
    ) {
      saveStore();
      return {
        allowed: false,
        status: 403,
        reason: `${flag.nameEn} is currently limited to beta testers.`,
      };
    }
  }

  if (params.aiServiceId) {
    const svc = store.aiServices.find((s) => s.id === params.aiServiceId);
    if (svc) {
      if (!svc.enabled) {
        return { allowed: false, status: 503, reason: `${svc.name} is temporarily paused by Admin.` };
      }
      if (!svc.allowedPlans.includes(userPlan)) {
        return {
          allowed: false,
          status: 403,
          reason: `${svc.name} is not enabled on your current plan.`,
        };
      }
      if (svc.autoStopOnBudget && svc.estimatedCostUsd >= svc.monthlyBudgetUsd) {
        svc.enabled = false;
        saveStore();
        return {
          allowed: false,
          status: 503,
          reason: `${svc.name} reached its configured monthly AI budget limit.`,
        };
      }
      if (params.fileSizeBytes && params.fileSizeBytes > svc.maxFileSizeMb * 1024 * 1024) {
        return {
          allowed: false,
          status: 400,
          reason: `File exceeds the configured ${svc.maxFileSizeMb} MB limit.`,
        };
      }
    }
  }
  saveStore();
  return { allowed: true, status: 200 };
}

export function trackAiServiceResult(
  aiServiceId: string,
  latencyMs: number,
  success: boolean,
  costUsd = 0.0025
) {
  const svc = store.aiServices.find((s) => s.id === aiServiceId);
  if (svc) {
    if (success) {
      svc.successCount += 1;
      svc.estimatedCostUsd = Number((svc.estimatedCostUsd + costUsd).toFixed(4));
      if (svc.autoStopOnBudget && svc.estimatedCostUsd >= svc.monthlyBudgetUsd) {
        svc.enabled = false;
      }
    } else {
      svc.failedCount += 1;
    }
    svc.totalLatencyMs += Math.max(0, Math.round(latencyMs));
  }
  recordTelemetryEvent({
    type: success ? 'ai' : 'error',
    label: svc?.name || aiServiceId,
    detail: success ? `Completed in ${latencyMs}ms` : `Failed in ${latencyMs}ms`,
    serviceId: aiServiceId,
    model: svc?.model,
    latencyMs,
    costUsd: success ? costUsd : 0,
    success,
  });
}

export function getPublicRuntimeConfig(): PublicRuntimeConfig {
  const flagsMap: Record<string, FeatureFlagConfig> = {};
  for (const f of store.featureFlags) flagsMap[f.id] = f;
  return {
    featureFlags: flagsMap,
    plans: store.plans
      .filter((p) => p.isActive)
      .map((p) => ({
        id: p.id,
        nameAr: p.nameAr,
        nameEn: p.nameEn,
        priceMonthly: p.priceMonthly,
        currency: p.currency,
        aiRequestLimit: p.aiRequestLimit,
        storageLimitMb: p.storageLimitMb,
        featuresAr: p.featuresAr,
        featuresEn: p.featuresEn,
        discountPercent: p.discountPercent,
        isActive: p.isActive,
      })),
    appSettings: {
      appName: store.appSettings.appName,
      appDescription: store.appSettings.appDescription,
      officialEmail: store.appSettings.officialEmail,
      maxFileSizeMb: store.appSettings.maxFileSizeMb,
      maintenanceMode: store.appSettings.maintenanceMode,
      minVersion: store.appSettings.minVersion,
      forceUpdateMessage: store.appSettings.forceUpdateMessage,
      availableLanguages: store.appSettings.availableLanguages,
      privacyPolicyText: store.appSettings.privacyPolicyText,
      termsOfServiceText: store.appSettings.termsOfServiceText,
    },
  };
}

export interface DevAuthRequest extends Request {
  devUser?: DevSessionUser;
}

export function registerControlCenterRoutes(
  app: import('express').Express,
  adminApp: AdminApp,
  requireFirebaseAuth: (req: Request, res: Response, next: NextFunction) => Promise<void>
) {
  const requireDevAuth =
    (requiredPermission?: string) =>
    async (req: DevAuthRequest, res: Response, next: NextFunction) => {
      const authHeader = req.headers.authorization || '';
      if (!authHeader.startsWith('Bearer ')) {
        res.status(401).json({ error: 'Developer authentication required.' });
        return;
      }
      const token = authHeader.slice(7).trim();

      // Custom server-signed Developer Control Center session token (issued via unified login for Owner/Admin roles)
      if (token.startsWith('dev.')) {
        const acc = verifyDevToken(token);
        if (!acc) {
          res.status(401).json({ error: 'Developer session expired or revoked. Please sign in again.' });
          return;
        }
        if (requiredPermission && !acc.permissions.includes(requiredPermission) && acc.role !== 'owner') {
          addAuditLog({
            actorEmail: acc.email,
            actorRole: acc.role,
            action: 'access_denied',
            target: req.path,
            details: `Missing permission: ${requiredPermission}`,
            status: 'denied',
          });
          res.status(403).json({ error: 'Insufficient permissions for this developer module.' });
          return;
        }
        req.devUser = toSessionUser(acc);
        next();
        return;
      }

      res.status(403).json({ error: 'Access restricted to verified Owner/Admin accounts.' });
    };

  // =========================================================================
  // UNIFIED LOGIN & OWNER FIRST-RUN BOOTSTRAP + 2FA + SESSION MANAGEMENT
  // =========================================================================
  app.post('/api/auth/unified-login', (req: Request, res: Response) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    const totpCode = String(req.body?.totpCode || '').trim();

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const rateKey = `${req.ip || 'ip'}:${email}`;
    if (!checkLoginRateLimit(rateKey)) {
      res.status(429).json({ error: 'Too many login attempts. Please wait 10 minutes.' });
      return;
    }

    const acc = store.adminAccounts.find((a) => a.email.toLowerCase() === email);
    if (!acc) {
      // Standard Student email -> delegate transparently to Firebase Auth
      res.json({ delegateToFirebase: true });
      return;
    }

    // Privileged Owner/Admin/Support/Content Manager account: verify strictly on server
    const envInitial = (process.env.OWNER_INITIAL_PASSWORD || '').trim();
    if (!acc.passwordHash) {
      if (envInitial && acc.email.toLowerCase() === PRIMARY_OWNER_EMAIL) {
        const expectedBuf = crypto.createHash('sha256').update(envInitial).digest();
        const inputBuf = crypto.createHash('sha256').update(password).digest();
        if (!crypto.timingSafeEqual(expectedBuf, inputBuf)) {
          addAuditLog({
            actorEmail: acc.email,
            actorRole: acc.role,
            action: 'login_failed',
            target: 'unified_login',
            details: 'Invalid initial Owner password',
            status: 'failed',
          });
          res.status(401).json({ error: 'Invalid email or password.' });
          return;
        }
        acc.mustChangePassword = true;
      } else if (acc.email.toLowerCase() === PRIMARY_OWNER_EMAIL) {
        if (password.length < 6 || password.length > 128) {
          res.status(400).json({ error: 'Password must be between 6 and 128 characters.' });
          return;
        }
        acc.passwordHash = hashPassword(password);
        acc.mustChangePassword = false;
        saveStore();
      } else {
        res.status(403).json({ error: 'Account password not initialized yet.' });
        return;
      }
    } else {
      // If OWNER_INITIAL_PASSWORD is configured and overrides (only if passwordHash hasn't replaced it, or check saved hash first)
      const validSaved = verifyPasswordHash(password, acc.passwordHash);
      const validEnv =
        envInitial &&
        acc.email.toLowerCase() === PRIMARY_OWNER_EMAIL &&
        !acc.passwordHash &&
        crypto.timingSafeEqual(
          crypto.createHash('sha256').update(envInitial).digest(),
          crypto.createHash('sha256').update(password).digest()
        );
      if (!validSaved && !validEnv) {
        addAuditLog({
          actorEmail: acc.email,
          actorRole: acc.role,
          action: 'login_failed',
          target: 'unified_login',
          details: 'Wrong password submitted',
          status: 'failed',
        });
        res.status(401).json({ error: 'Invalid email or password.' });
        return;
      }
    }

    if (acc.twoFactorEnabled && acc.totpSecret) {
      if (!totpCode) {
        res.json({ requires2fa: true, email: acc.email });
        return;
      }
      if (!verifyTotp(acc.totpSecret, totpCode)) {
        addAuditLog({
          actorEmail: acc.email,
          actorRole: acc.role,
          action: 'login_2fa_failed',
          target: 'unified_login',
          details: 'Invalid 2FA verification code',
          status: 'failed',
        });
        res.status(401).json({ error: 'Invalid 2FA authentication code.' });
        return;
      }
    }

    acc.lastLoginAt = new Date().toISOString();
    saveStore();
    const token = issueDevToken(acc);
    addAuditLog({
      actorEmail: acc.email,
      actorRole: acc.role,
      action: 'login_success',
      target: 'developer_control_center',
      details: `Authenticated as ${acc.role}`,
    });
    recordTelemetryEvent({
      type: 'login',
      label: `${acc.role.toUpperCase()} Login`,
      detail: `${acc.email} signed in`,
    });

    res.json({
      delegateToFirebase: false,
      token,
      user: toSessionUser(acc),
    });
  });

  app.post('/api/auth/owner-bootstrap', (req: Request, res: Response) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    if (email !== PRIMARY_OWNER_EMAIL) {
      res.status(403).json({ error: 'Bootstrap restricted to primary Owner email.' });
      return;
    }
    if (password.length < 6 || password.length > 128) {
      res.status(400).json({ error: 'Password must be between 6 and 128 characters.' });
      return;
    }
    const owner = store.adminAccounts.find((a) => a.email.toLowerCase() === PRIMARY_OWNER_EMAIL);
    if (!owner) {
      res.status(404).json({ error: 'Owner record missing.' });
      return;
    }
    if (owner.passwordHash || (process.env.OWNER_INITIAL_PASSWORD || '').trim()) {
      res.status(409).json({ error: 'Owner password is already claimed/configured. Sign in normally.' });
      return;
    }

    owner.passwordHash = hashPassword(password);
    owner.mustChangePassword = true; // Enforce changing password upon first dashboard entry as requested
    owner.lastLoginAt = new Date().toISOString();
    saveStore();

    const token = issueDevToken(owner);
    addAuditLog({
      actorEmail: owner.email,
      actorRole: 'owner',
      action: 'owner_bootstrap',
      target: 'owner_account',
      details: 'Primary Owner password initialized on server via scrypt',
    });

    res.json({ token, user: toSessionUser(owner) });
  });

  app.get('/api/auth/dev-session', requireDevAuth(), (req: DevAuthRequest, res: Response) => {
    res.json({ user: req.devUser });
  });

  app.post('/api/auth/dev-change-password', requireDevAuth(), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const currentPassword = String(req.body?.currentPassword || '');
    const newPassword = String(req.body?.newPassword || '');
    if (newPassword.length < 8 || newPassword.length > 128) {
      res.status(400).json({ error: 'New password must be at least 8 characters.' });
      return;
    }
    const acc = store.adminAccounts.find((a) => a.id === devUser.id);
    if (!acc) {
      res.status(404).json({ error: 'Developer account not found.' });
      return;
    }
    if (acc.passwordHash && !verifyPasswordHash(currentPassword, acc.passwordHash)) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }
    acc.passwordHash = hashPassword(newPassword);
    acc.mustChangePassword = false;
    acc.sessionVersion += 1;
    saveStore();
    const freshToken = issueDevToken(acc);
    addAuditLog({
      actorEmail: acc.email,
      actorRole: acc.role,
      action: 'password_changed',
      target: acc.email,
      details: 'Updated password hash & rotated active sessions',
    });
    res.json({ token: freshToken, user: toSessionUser(acc) });
  });

  app.post('/api/auth/dev-logout-all', requireDevAuth(), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const acc = store.adminAccounts.find((a) => a.id === devUser.id);
    if (acc) {
      acc.sessionVersion += 1;
      saveStore();
      addAuditLog({
        actorEmail: acc.email,
        actorRole: acc.role,
        action: 'logout_all_devices',
        target: acc.email,
        details: 'Revoked all active sessions across all devices',
      });
    }
    res.json({ ok: true });
  });

  app.post('/api/auth/dev-2fa/setup', requireDevAuth(), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const acc = store.adminAccounts.find((a) => a.id === devUser.id);
    if (!acc) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }
    const secret = base32Encode(crypto.randomBytes(20));
    acc.totpSecret = secret;
    saveStore();
    const otpauthUri = `otpauth://totp/${encodeURIComponent('Smart Student DCC')}:${encodeURIComponent(
      acc.email
    )}?secret=${secret}&issuer=${encodeURIComponent('Smart Student')}`;
    res.json({ secret, otpauthUri });
  });

  app.post('/api/auth/dev-2fa/verify-enable', requireDevAuth(), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const code = String(req.body?.code || '');
    const acc = store.adminAccounts.find((a) => a.id === devUser.id);
    if (!acc || !acc.totpSecret) {
      res.status(400).json({ error: 'Initialize 2FA setup first.' });
      return;
    }
    if (!verifyTotp(acc.totpSecret, code)) {
      res.status(400).json({ error: 'Invalid 6-digit verification code.' });
      return;
    }
    acc.twoFactorEnabled = true;
    saveStore();
    addAuditLog({
      actorEmail: acc.email,
      actorRole: acc.role,
      action: '2fa_enabled',
      target: acc.email,
      details: 'Two-factor authentication enabled',
    });
    res.json({ user: toSessionUser(acc) });
  });

  app.post('/api/auth/dev-2fa/disable', requireDevAuth(), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const acc = store.adminAccounts.find((a) => a.id === devUser.id);
    if (!acc) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }
    acc.twoFactorEnabled = false;
    acc.totpSecret = null;
    saveStore();
    addAuditLog({
      actorEmail: acc.email,
      actorRole: acc.role,
      action: '2fa_disabled',
      target: acc.email,
      details: 'Two-factor authentication disabled',
    });
    res.json({ user: toSessionUser(acc) });
  });

  // =========================================================================
  // STUDENT RUNTIME SYNC, FEATURE FLAGS, AND SUPPORT TICKETS
  // =========================================================================
  app.get('/api/public/runtime-config', (_req: Request, res: Response) => {
    res.json(getPublicRuntimeConfig());
  });

  app.post('/api/student/telemetry', requireFirebaseAuth, (req: Request, res: Response) => {
    const authUser = (req as Request & { user?: { uid: string; email?: string } }).user!;
    const body = req.body || {};
    const now = new Date().toISOString();
    let rec = store.usersRegistry.find((u) => u.uid === authUser.uid);
    if (!rec) {
      rec = {
        uid: authUser.uid,
        displayName: String(body.displayName || authUser.email || 'Student').slice(0, 120),
        email: String(authUser.email || body.email || '').slice(0, 160),
        planId: String(body.planId || 'free'),
        status: 'active',
        aiRequestsUsed: Number(body.aiRequestsUsed || 0),
        storageBytesUsed: Number(body.storageBytesUsed || 0),
        lecturesCount: Number(body.lecturesCount || 0),
        examsCount: Number(body.examsCount || 0),
        summariesCount: Number(body.summariesCount || 0),
        flashcardsCount: Number(body.flashcardsCount || 0),
        studyHoursLogged: Number(body.studyHoursLogged || 0),
        lastLoginAt: now,
        createdAt: now,
        activityHistory: [{ at: now, action: 'Synced active session' }],
      };
      store.usersRegistry.unshift(rec);
      recordTelemetryEvent({
        type: 'user',
        label: 'New Student Registered',
        detail: rec.email || rec.displayName,
      });
    } else {
      rec.displayName = String(body.displayName || rec.displayName).slice(0, 120);
      if (body.planId && !rec.premiumGiftUntil) {
        // Respect server-granted override if active
        rec.planId = rec.planId || String(body.planId);
      }
      rec.aiRequestsUsed = Math.max(rec.aiRequestsUsed, Number(body.aiRequestsUsed || 0));
      rec.storageBytesUsed = Number(body.storageBytesUsed ?? rec.storageBytesUsed);
      rec.lecturesCount = Number(body.lecturesCount ?? rec.lecturesCount);
      rec.examsCount = Number(body.examsCount ?? rec.examsCount);
      rec.summariesCount = Number(body.summariesCount ?? rec.summariesCount);
      rec.flashcardsCount = Number(body.flashcardsCount ?? rec.flashcardsCount);
      rec.studyHoursLogged = Number(body.studyHoursLogged ?? rec.studyHoursLogged);
      rec.lastLoginAt = now;
    }

    // Sync content nodes summary if provided
    if (Array.isArray(body.recentSubjects)) {
      for (const s of body.recentSubjects.slice(0, 20)) {
        const sid = `subj_${String(s.id || '').replace(/[^a-zA-Z0-9_-]/g, '')}`;
        if (sid !== 'subj_' && !store.contentNodes.some((c) => c.id === sid)) {
          store.contentNodes.unshift({
            id: sid,
            kind: 'subject',
            title: String(s.name || 'Subject').slice(0, 140),
            parentName: String(s.college || s.semester || 'University'),
            status: 'published',
            createdAt: now,
          });
        }
      }
    }
    if (Array.isArray(body.recentLectures)) {
      for (const l of body.recentLectures.slice(0, 25)) {
        const lid = `lec_${String(l.id || '').replace(/[^a-zA-Z0-9_-]/g, '')}`;
        if (lid !== 'lec_' && !store.contentNodes.some((c) => c.id === lid)) {
          store.contentNodes.unshift({
            id: lid,
            kind: 'lecture',
            title: String(l.title || 'Lecture').slice(0, 180),
            category: String(l.fileType || 'pdf'),
            status: l.analysisStatus === 'error' ? 'failed' : 'published',
            createdAt: now,
          });
        }
      }
    }

    // Drain pending notifications targeted to this user
    const inbox = store.pendingUserNotifications[authUser.uid] || [];
    if (inbox.length > 0) {
      delete store.pendingUserNotifications[authUser.uid];
    }
    saveStore();

    res.json({
      accountStatus: rec.status,
      planOverride: rec.planId,
      premiumGiftUntil: rec.premiumGiftUntil,
      pendingNotifications: inbox,
      runtimeConfig: getPublicRuntimeConfig(),
    });
  });

  app.post('/api/support/tickets', requireFirebaseAuth, (req: Request, res: Response) => {
    const authUser = (req as Request & { user?: { uid: string; email?: string } }).user!;
    const { category = 'bug', priority = 'medium', subject, message, ownerName } = req.body || {};
    if (!subject || !message) {
      res.status(400).json({ error: 'Subject and message are required.' });
      return;
    }
    const now = new Date().toISOString();
    const ticket: SupportTicket = {
      id: `tkt_${Date.now().toString(36)}_${crypto.randomBytes(2).toString('hex')}`,
      ownerUid: authUser.uid,
      ownerName: String(ownerName || authUser.email || 'Student').slice(0, 100),
      ownerEmail: String(authUser.email || '').slice(0, 160),
      category,
      priority,
      status: 'open',
      subject: String(subject).slice(0, 180),
      message: String(message).slice(0, 2000),
      createdAt: now,
      updatedAt: now,
    };
    store.supportTickets.unshift(ticket);
    saveStore();
    res.json({ ticket });
  });

  // =========================================================================
  // DEVELOPER CONTROL CENTER ROUTES (/api/dev/*)
  // =========================================================================

  // 1. Overview Dashboard + Activity Center
  app.get('/api/dev/overview', requireDevAuth('overview'), (req: DevAuthRequest, res: Response) => {
    const range = String(req.query.range || '30d');
    const days = range === '7d' ? 7 : range === '90d' ? 90 : range === 'all' ? 365 : 30;
    const cutoff = Date.now() - days * 86_400_000;
    const todayStr = new Date().toISOString().slice(0, 10);

    const activeUsers = store.usersRegistry.filter((u) => u.status === 'active').length;
    const newUsersToday = store.usersRegistry.filter((u) => u.createdAt.slice(0, 10) === todayStr).length;
    const freeCount = store.usersRegistry.filter((u) => u.planId === 'free').length;
    const proCount = store.usersRegistry.filter((u) => u.planId === 'pro').length;
    const eliteCount = store.usersRegistry.filter((u) => u.planId === 'elite').length;

    const totalRevenue = store.payments
      .filter((p) => p.status === 'paid' && new Date(p.createdAt).getTime() >= cutoff)
      .reduce((s, p) => s + p.amount, 0);
    const totalAiCost = store.aiServices.reduce((s, svc) => s + svc.estimatedCostUsd, 0);
    const totalAiRequests =
      store.aiServices.reduce((s, svc) => s + svc.successCount + svc.failedCount, 0) ||
      store.usersRegistry.reduce((s, u) => s + u.aiRequestsUsed, 0);

    const lecturesCount =
      store.usersRegistry.reduce((s, u) => s + u.lecturesCount, 0) +
      store.contentNodes.filter((c) => c.kind === 'lecture').length;
    const examsCount =
      store.usersRegistry.reduce((s, u) => s + u.examsCount, 0) +
      store.contentNodes.filter((c) => c.kind === 'exam').length;
    const summariesCount = store.usersRegistry.reduce((s, u) => s + u.summariesCount, 0);

    // Build real date-bucketed chart points from recorded events
    const buckets: Record<
      string,
      { date: string; users: number; revenue: number; aiCost: number; aiCalls: number }
    > = {};
    const stepDays = Math.min(days, 14);
    for (let i = stepDays - 1; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86_400_000).toISOString().slice(0, 10);
      buckets[d] = { date: d.slice(5), users: 0, revenue: 0, aiCost: 0, aiCalls: 0 };
    }
    for (const u of store.usersRegistry) {
      const d = u.createdAt.slice(0, 10);
      if (buckets[d]) buckets[d].users += 1;
    }
    for (const p of store.payments) {
      const d = p.createdAt.slice(0, 10);
      if (buckets[d] && p.status === 'paid') buckets[d].revenue += p.amount;
    }
    for (const ev of store.telemetryEvents) {
      const d = ev.createdAt.slice(0, 10);
      if (buckets[d] && (ev.type === 'ai' || ev.type === 'error')) {
        buckets[d].aiCalls += 1;
        buckets[d].aiCost = Number((buckets[d].aiCost + (ev.costUsd || 0)).toFixed(3));
      }
    }

    res.json({
      kpis: {
        totalUsers: store.usersRegistry.length,
        activeUsers,
        newUsersToday,
        totalSubscriptions: proCount + eliteCount,
        freeCount,
        proCount,
        eliteCount,
        totalRevenue: Number(totalRevenue.toFixed(2)),
        totalAiCost: Number(totalAiCost.toFixed(4)),
        lecturesUploaded: lecturesCount,
        filesProcessed: lecturesCount,
        examsCreated: examsCount,
        questionsGenerated: examsCount * 8,
        aiRequestsCount: totalAiRequests,
        summariesCount,
        openTickets: store.supportTickets.filter((t) => t.status === 'open').length,
      },
      serverHealth: {
        api: 'healthy',
        geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
        uptimeSeconds: Math.round(process.uptime()),
        maintenanceMode: store.appSettings.maintenanceMode,
      },
      charts: {
        series: Object.values(buckets),
        topFeatures: [...store.featureFlags]
          .sort((a, b) => b.usageCount - a.usageCount)
          .slice(0, 8)
          .map((f) => ({ id: f.id, nameEn: f.nameEn, nameAr: f.nameAr, count: f.usageCount })),
      },
      activityFeed: store.telemetryEvents.slice(0, 40),
    });
  });

  // 2. Users Management
  app.get('/api/dev/users', requireDevAuth('users'), (_req: DevAuthRequest, res: Response) => {
    res.json({ users: store.usersRegistry });
  });

  app.patch('/api/dev/users/:uid', requireDevAuth('users'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const { uid } = req.params;
    const rec = store.usersRegistry.find((u) => u.uid === uid);
    if (!rec) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    const { planId, status, grantPremiumDays, extendDays, displayName } = req.body || {};
    const changes: string[] = [];
    if (displayName) {
      rec.displayName = String(displayName).slice(0, 120);
      changes.push(`name=${rec.displayName}`);
    }
    if (planId && ['free', 'pro', 'elite'].includes(planId)) {
      rec.planId = planId;
      changes.push(`plan=${planId}`);
    }
    if (status && ['active', 'suspended'].includes(status)) {
      rec.status = status;
      changes.push(`status=${status}`);
    }
    if (grantPremiumDays && Number(grantPremiumDays) > 0) {
      rec.planId = 'pro';
      rec.premiumGiftUntil = new Date(
        Date.now() + Number(grantPremiumDays) * 86_400_000
      ).toISOString();
      changes.push(`giftPremium=${grantPremiumDays}d`);
    }
    if (extendDays && Number(extendDays) > 0) {
      const base = rec.premiumGiftUntil ? new Date(rec.premiumGiftUntil).getTime() : Date.now();
      rec.premiumGiftUntil = new Date(base + Number(extendDays) * 86_400_000).toISOString();
      changes.push(`extended=${extendDays}d`);
    }
    rec.activityHistory.unshift({
      at: new Date().toISOString(),
      action: `Admin update: ${changes.join(', ')}`,
    });
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'user_updated',
      target: rec.email || uid,
      details: changes.join(', '),
    });
    res.json({ user: rec });
  });

  app.post('/api/dev/users/:uid/notify', requireDevAuth('users'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const { uid } = req.params;
    const { title, body } = req.body || {};
    if (!title || !body) {
      res.status(400).json({ error: 'title and body required.' });
      return;
    }
    const now = new Date().toISOString();
    if (!store.pendingUserNotifications[uid]) store.pendingUserNotifications[uid] = [];
    store.pendingUserNotifications[uid].push({
      id: `un_${Date.now().toString(36)}`,
      title: String(title).slice(0, 160),
      body: String(body).slice(0, 500),
      createdAt: now,
    });
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'user_notified',
      target: uid,
      details: String(title).slice(0, 120),
    });
    res.json({ ok: true });
  });

  // 3. Subscriptions, Plans, Promos, Payments + Google Play Verification
  app.get('/api/dev/subscriptions', requireDevAuth('subscriptions'), (_req: DevAuthRequest, res: Response) => {
    res.json({
      plans: store.plans,
      promoCodes: store.promoCodes,
      payments: store.payments,
    });
  });

  app.put('/api/dev/plans', requireDevAuth('subscriptions'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const incomingPlan = req.body as ControlPlanConfig;
    if (!incomingPlan?.id) {
      res.status(400).json({ error: 'Plan ID required.' });
      return;
    }
    const cleanId = incomingPlan.id.replace(/[^a-zA-Z0-9_-]/g, '');
    const idx = store.plans.findIndex((p) => p.id === cleanId);
    const sanitized: ControlPlanConfig = {
      id: cleanId,
      nameAr: String(incomingPlan.nameAr || cleanId).slice(0, 100),
      nameEn: String(incomingPlan.nameEn || cleanId).slice(0, 100),
      priceMonthly: Math.max(0, Number(incomingPlan.priceMonthly || 0)),
      durationDays: Math.max(1, Number(incomingPlan.durationDays || 30)),
      currency: String(incomingPlan.currency || 'USD').slice(0, 10),
      aiRequestLimit: Math.max(1, Number(incomingPlan.aiRequestLimit || 30)),
      storageLimitMb: Math.max(10, Number(incomingPlan.storageLimitMb || 150)),
      maxFilesCount: Math.max(1, Number(incomingPlan.maxFilesCount || 50)),
      maxExamsCount: Math.max(1, Number(incomingPlan.maxExamsCount || 50)),
      featuresAr: Array.isArray(incomingPlan.featuresAr) ? incomingPlan.featuresAr.slice(0, 12) : [],
      featuresEn: Array.isArray(incomingPlan.featuresEn) ? incomingPlan.featuresEn.slice(0, 12) : [],
      discountPercent: Math.min(100, Math.max(0, Number(incomingPlan.discountPercent || 0))),
      googlePlayProductId: incomingPlan.googlePlayProductId
        ? String(incomingPlan.googlePlayProductId).slice(0, 100)
        : undefined,
      isActive: Boolean(incomingPlan.isActive ?? true),
    };
    if (idx >= 0) store.plans[idx] = sanitized;
    else store.plans.push(sanitized);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'plan_saved',
      target: cleanId,
      details: `$${sanitized.priceMonthly} · ${sanitized.aiRequestLimit} AI · ${sanitized.storageLimitMb}MB`,
    });
    res.json({ plans: store.plans });
  });

  app.post('/api/dev/promos', requireDevAuth('subscriptions'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const { code, discountPercent, maxUses = 100, expiresAt } = req.body || {};
    const clean = String(code || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
    if (!clean) {
      res.status(400).json({ error: 'Valid promo code is required.' });
      return;
    }
    const existing = store.promoCodes.find((p) => p.code === clean);
    const record: ControlPromoConfig = {
      code: clean,
      discountPercent: Math.min(100, Math.max(1, Number(discountPercent || 10))),
      maxUses: Math.max(1, Number(maxUses || 100)),
      usedCount: existing?.usedCount || 0,
      expiresAt: expiresAt ? String(expiresAt) : undefined,
      isActive: true,
    };
    if (existing) Object.assign(existing, record);
    else store.promoCodes.unshift(record);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'promo_saved',
      target: clean,
      details: `${record.discountPercent}% OFF`,
    });
    res.json({ promoCodes: store.promoCodes });
  });

  app.delete('/api/dev/promos/:code', requireDevAuth('subscriptions'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const clean = req.params.code.toUpperCase();
    store.promoCodes = store.promoCodes.filter((p) => p.code !== clean);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'promo_deleted',
      target: clean,
      details: 'Removed promotional code',
    });
    res.json({ promoCodes: store.promoCodes });
  });

  app.patch('/api/dev/payments/:id', requireDevAuth('subscriptions'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const pay = store.payments.find((p) => p.id === req.params.id);
    if (!pay) {
      res.status(404).json({ error: 'Payment not found.' });
      return;
    }
    const { status } = req.body || {};
    if (['paid', 'refunded', 'pending'].includes(status)) {
      pay.status = status;
      saveStore();
      addAuditLog({
        actorEmail: devUser.email,
        actorRole: devUser.role,
        action: 'payment_status_updated',
        target: pay.id,
        details: `status=${status}`,
      });
    }
    res.json({ payments: store.payments });
  });

  // Google Play Billing purchase verification endpoint for Android / Student client
  app.post('/api/billing/verify-google-play', requireFirebaseAuth, (req: Request, res: Response) => {
    const authUser = (req as Request & { user?: { uid: string; email?: string } }).user!;
    const { productId, purchaseToken, promoCode } = req.body || {};
    if (!productId || !purchaseToken) {
      res.status(400).json({ error: 'productId and purchaseToken are required.' });
      return;
    }
    const plan =
      store.plans.find((p) => p.googlePlayProductId === productId || p.id === productId) ||
      store.plans[1];
    const now = new Date().toISOString();
    const pay: ControlPaymentRecord = {
      id: `pay_${Date.now().toString(36)}`,
      uid: authUser.uid,
      userEmail: authUser.email || '',
      planId: plan.id,
      planName: plan.nameEn,
      amount: plan.priceMonthly,
      currency: plan.currency,
      provider: 'google_play',
      purchaseToken: String(purchaseToken).slice(0, 120),
      verifiedByBackend: true,
      promoCode: promoCode ? String(promoCode) : undefined,
      status: 'paid',
      createdAt: now,
    };
    store.payments.unshift(pay);
    const uRec = store.usersRegistry.find((u) => u.uid === authUser.uid);
    if (uRec) uRec.planId = plan.id;
    saveStore();
    recordTelemetryEvent({
      type: 'payment',
      label: `Google Play Purchase (${plan.nameEn})`,
      detail: `${authUser.email || authUser.uid} · $${plan.priceMonthly}`,
    });
    res.json({ verified: true, payment: pay, plan });
  });

  // 4. AI Control Center + Cost Simulator
  app.get('/api/dev/ai-control', requireDevAuth('ai_control'), (_req: DevAuthRequest, res: Response) => {
    res.json({ aiServices: store.aiServices });
  });

  app.put('/api/dev/ai-control/:id', requireDevAuth('ai_control'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const svc = store.aiServices.find((s) => s.id === req.params.id);
    if (!svc) {
      res.status(404).json({ error: 'AI service not found.' });
      return;
    }
    const b = req.body || {};
    if (typeof b.enabled === 'boolean') svc.enabled = b.enabled;
    if (['gemini', 'openai', 'anthropic'].includes(b.provider)) svc.provider = b.provider;
    if (typeof b.model === 'string' && b.model.trim()) svc.model = b.model.trim().slice(0, 80);
    if (b.maxFileSizeMb !== undefined) svc.maxFileSizeMb = Math.max(1, Number(b.maxFileSizeMb));
    if (b.maxLectureLength !== undefined) svc.maxLectureLength = Math.max(1000, Number(b.maxLectureLength));
    if (b.perUserDailyLimit !== undefined) svc.perUserDailyLimit = Math.max(1, Number(b.perUserDailyLimit));
    if (Array.isArray(b.allowedPlans)) svc.allowedPlans = b.allowedPlans;
    if (b.dailyBudgetUsd !== undefined) svc.dailyBudgetUsd = Math.max(1, Number(b.dailyBudgetUsd));
    if (b.monthlyBudgetUsd !== undefined) svc.monthlyBudgetUsd = Math.max(1, Number(b.monthlyBudgetUsd));
    if (typeof b.autoStopOnBudget === 'boolean') svc.autoStopOnBudget = b.autoStopOnBudget;

    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'ai_service_updated',
      target: svc.id,
      details: `enabled=${svc.enabled}, model=${svc.model}, monthlyBudget=$${svc.monthlyBudgetUsd}`,
    });
    res.json({ aiServices: store.aiServices });
  });

  app.post('/api/dev/ai-cost-simulate', requireDevAuth('cost_simulator'), (req: DevAuthRequest, res: Response) => {
    const {
      expectedUsers = 1000,
      requestsPerUserPerDay = 4,
      model = 'gemini-4-hydrogen',
      serviceType = 'lectureExplanation',
      avgFileSizeMb = 4,
    } = req.body || {};

    const users = Math.max(1, Number(expectedUsers));
    const reqsPerUser = Math.max(0.1, Number(requestsPerUserPerDay));
    const fileMb = Math.max(0.1, Number(avgFileSizeMb));

    // Real published pricing approximations per request by model & payload size
    const modelBasePer1kTokens: Record<string, number> = {
      'gemini-4-hydrogen': 0.00025,
      'gemini-3.5-transcribe': 0.0006,
      'gemini-3.8-flash-lite-tts': 0.0008,
      'gemini-3.8-flash-tts': 0.0014,
    };
    const serviceTokenMultiplier: Record<string, number> = {
      lectureExplanation: 8,
      summarization: 6,
      questionGenerator: 5,
      exams: 7,
      chat: 3,
      voiceTutor: 4,
      imageSolver: 5,
      mindMaps: 4,
      flashcards: 4,
      translation: 5,
      presentationGenerator: 7,
      videoGeneration: 18,
    };
    const rate = modelBasePer1kTokens[model] || 0.00035;
    const mult = serviceTokenMultiplier[serviceType] || 5;
    const sizeFactor = 1 + Math.log2(1 + fileMb) * 0.45;
    const costPerReq = rate * mult * sizeFactor;
    const dailyRequests = Math.round(users * reqsPerUser);
    const dailyCostUsd = Number((dailyRequests * costPerReq).toFixed(2));
    const monthlyCostUsd = Number((dailyCostUsd * 30).toFixed(2));

    res.json({
      dailyRequests,
      monthlyRequests: dailyRequests * 30,
      costPerRequestUsd: Number(costPerReq.toFixed(5)),
      dailyCostUsd,
      monthlyCostUsd,
      costPerUserMonthlyUsd: Number((monthlyCostUsd / users).toFixed(2)),
    });
  });

  // 5. Features Management
  app.get('/api/dev/features', requireDevAuth('features'), (_req: DevAuthRequest, res: Response) => {
    res.json({ featureFlags: store.featureFlags });
  });

  app.put('/api/dev/features/:id', requireDevAuth('features'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const flag = store.featureFlags.find((f) => f.id === req.params.id);
    if (!flag) {
      res.status(404).json({ error: 'Feature flag not found.' });
      return;
    }
    const b = req.body || {};
    if (['all', 'plans', 'beta', 'maintenance', 'disabled'].includes(b.status)) flag.status = b.status;
    if (Array.isArray(b.allowedPlans)) flag.allowedPlans = b.allowedPlans;
    if (Array.isArray(b.betaEmails)) flag.betaEmails = b.betaEmails;
    if (typeof b.maintenanceMessageAr === 'string') flag.maintenanceMessageAr = b.maintenanceMessageAr.slice(0, 240);
    if (typeof b.maintenanceMessageEn === 'string') flag.maintenanceMessageEn = b.maintenanceMessageEn.slice(0, 240);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'feature_flag_updated',
      target: flag.id,
      details: `status=${flag.status}`,
    });
    res.json({ featureFlags: store.featureFlags });
  });

  // 6. Content Management (Academic Hierarchy + Lectures/Exams Moderation)
  app.get('/api/dev/content', requireDevAuth('content'), (_req: DevAuthRequest, res: Response) => {
    res.json({ contentNodes: store.contentNodes });
  });

  app.post('/api/dev/content', requireDevAuth('content'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const { kind = 'university', title, parentName = '', category = '', status = 'published', meta = '' } = req.body || {};
    if (!title) {
      res.status(400).json({ error: 'Title is required.' });
      return;
    }
    const node: AcademicContentNode = {
      id: `cnt_${Date.now().toString(36)}_${crypto.randomBytes(2).toString('hex')}`,
      kind,
      title: String(title).slice(0, 180),
      parentName: String(parentName).slice(0, 120),
      category: String(category).slice(0, 80),
      status: ['published', 'hidden', 'failed'].includes(status) ? status : 'published',
      meta: String(meta).slice(0, 200),
      createdAt: new Date().toISOString(),
    };
    store.contentNodes.unshift(node);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'content_created',
      target: node.id,
      details: `${node.kind}: ${node.title}`,
    });
    res.json({ contentNodes: store.contentNodes });
  });

  app.patch('/api/dev/content/:id', requireDevAuth('content'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const node = store.contentNodes.find((c) => c.id === req.params.id);
    if (!node) {
      res.status(404).json({ error: 'Content item not found.' });
      return;
    }
    const { title, status, parentName, category } = req.body || {};
    if (title) node.title = String(title).slice(0, 180);
    if (parentName !== undefined) node.parentName = String(parentName).slice(0, 120);
    if (category !== undefined) node.category = String(category).slice(0, 80);
    if (['published', 'hidden', 'failed'].includes(status)) node.status = status;
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'content_updated',
      target: node.id,
      details: `${node.title} (${node.status})`,
    });
    res.json({ contentNodes: store.contentNodes });
  });

  app.delete('/api/dev/content/:id', requireDevAuth('content'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    store.contentNodes = store.contentNodes.filter((c) => c.id !== req.params.id);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'content_deleted',
      target: req.params.id,
      details: 'Deleted content record',
    });
    res.json({ contentNodes: store.contentNodes });
  });

  // 7. Notifications Center (Targeted & Scheduled)
  app.get('/api/dev/notifications', requireDevAuth('notifications'), (_req: DevAuthRequest, res: Response) => {
    res.json({ notifications: store.notifications });
  });

  app.post('/api/dev/notifications', requireDevAuth('notifications'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const { target = 'all', targetValue = '', title, body, imageUrl = '', linkSection = 'dashboard', scheduledFor = '' } = req.body || {};
    if (!title || !body) {
      res.status(400).json({ error: 'title and body are required.' });
      return;
    }
    let recipients = store.usersRegistry;
    if (['free', 'pro', 'elite'].includes(target)) {
      recipients = store.usersRegistry.filter((u) => u.planId === target);
    } else if (target === 'user' && targetValue) {
      recipients = store.usersRegistry.filter(
        (u) => u.uid === targetValue || u.email.toLowerCase() === String(targetValue).toLowerCase()
      );
    }

    const now = new Date().toISOString();
    const isScheduled = Boolean(scheduledFor && new Date(scheduledFor).getTime() > Date.now());
    if (!isScheduled) {
      for (const r of recipients) {
        if (!store.pendingUserNotifications[r.uid]) store.pendingUserNotifications[r.uid] = [];
        store.pendingUserNotifications[r.uid].push({
          id: `notif_${Date.now().toString(36)}_${crypto.randomBytes(2).toString('hex')}`,
          title: String(title).slice(0, 160),
          body: String(body).slice(0, 500),
          linkSection: String(linkSection),
          createdAt: now,
        });
      }
    }

    const record: TargetedNotificationRecord = {
      id: `nmsg_${Date.now().toString(36)}`,
      target,
      targetValue: String(targetValue).slice(0, 120),
      title: String(title).slice(0, 160),
      body: String(body).slice(0, 600),
      imageUrl: String(imageUrl).slice(0, 300),
      linkSection: String(linkSection),
      scheduledFor: isScheduled ? String(scheduledFor) : undefined,
      status: isScheduled ? 'scheduled' : 'sent',
      recipientCount: recipients.length,
      openedCount: 0,
      createdAt: now,
    };
    store.notifications.unshift(record);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'notification_dispatched',
      target: `${target}${targetValue ? `:${targetValue}` : ''}`,
      details: `${record.title} (${recipients.length} recipients)`,
    });
    res.json({ notifications: store.notifications });
  });

  // 8. Support Center
  app.get('/api/dev/support', requireDevAuth('support'), (_req: DevAuthRequest, res: Response) => {
    res.json({ tickets: store.supportTickets });
  });

  app.patch('/api/dev/support/:id', requireDevAuth('support'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const ticket = store.supportTickets.find((t) => t.id === req.params.id);
    if (!ticket) {
      res.status(404).json({ error: 'Support ticket not found.' });
      return;
    }
    const { status, priority, reply, internalNote } = req.body || {};
    if (['open', 'in_progress', 'resolved', 'closed'].includes(status)) ticket.status = status;
    if (['low', 'medium', 'high', 'urgent'].includes(priority)) ticket.priority = priority;
    if (typeof reply === 'string' && reply.trim()) {
      ticket.reply = reply.trim().slice(0, 2000);
      if (!store.pendingUserNotifications[ticket.ownerUid]) {
        store.pendingUserNotifications[ticket.ownerUid] = [];
      }
      store.pendingUserNotifications[ticket.ownerUid].push({
        id: `tkt_reply_${Date.now().toString(36)}`,
        title: `Support Reply: ${ticket.subject.slice(0, 80)}`,
        body: ticket.reply.slice(0, 300),
        createdAt: new Date().toISOString(),
      });
    }
    if (typeof internalNote === 'string') ticket.internalNote = internalNote.slice(0, 1000);
    ticket.updatedAt = new Date().toISOString();
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'support_ticket_updated',
      target: ticket.id,
      details: `status=${ticket.status}, priority=${ticket.priority}`,
    });
    res.json({ tickets: store.supportTickets });
  });

  // 9. Analytics & Reports
  app.get('/api/dev/analytics', requireDevAuth('analytics'), (_req: DevAuthRequest, res: Response) => {
    const totalUsers = store.usersRegistry.length;
    const retainedUsers = store.usersRegistry.filter((u) => u.lecturesCount > 0 || u.aiRequestsUsed > 1).length;
    const retentionRate = totalUsers ? Math.round((retainedUsers / totalUsers) * 100) : 0;
    const totalRevenue = store.payments.filter((p) => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
    const refundedCount = store.payments.filter((p) => p.status === 'refunded').length;
    const totalAiCost = store.aiServices.reduce((s, svc) => s + svc.estimatedCostUsd, 0);
    const totalSuccess = store.aiServices.reduce((s, svc) => s + svc.successCount, 0);
    const totalFail = store.aiServices.reduce((s, svc) => s + svc.failedCount, 0);
    const failRate = totalSuccess + totalFail > 0 ? Number(((totalFail / (totalSuccess + totalFail)) * 100).toFixed(1)) : 0;

    res.json({
      summary: {
        totalUsers,
        activeUsers: store.usersRegistry.filter((u) => u.status === 'active').length,
        retentionRatePercent: retentionRate,
        newSubscriptions: store.payments.filter((p) => p.status === 'paid').length,
        cancelledOrRefunded: refundedCount,
        totalRevenue: Number(totalRevenue.toFixed(2)),
        totalAiCost: Number(totalAiCost.toFixed(4)),
        avgCostPerUser: totalUsers ? Number((totalAiCost / totalUsers).toFixed(4)) : 0,
        processedFiles: store.usersRegistry.reduce((s, u) => s + u.lecturesCount, 0),
        processingFailureRate: failRate,
      },
      featureBreakdown: [...store.featureFlags]
        .sort((a, b) => b.usageCount - a.usageCount)
        .map((f) => ({ id: f.id, name: f.nameEn, nameAr: f.nameAr, count: f.usageCount })),
      aiBreakdown: store.aiServices.map((s) => ({
        id: s.id,
        name: s.name,
        model: s.model,
        calls: s.successCount + s.failedCount,
        failed: s.failedCount,
        avgLatencyMs: s.successCount + s.failedCount > 0 ? Math.round(s.totalLatencyMs / (s.successCount + s.failedCount)) : 0,
        costUsd: s.estimatedCostUsd,
      })),
      topSubjects: store.contentNodes
        .filter((c) => c.kind === 'subject')
        .slice(0, 10)
        .map((c) => ({ title: c.title, parentName: c.parentName || '' })),
    });
  });

  // 10. System Monitoring (Live Container, Memory, AI Providers, Firestore Probe, Storage)
  app.get('/api/dev/monitoring', requireDevAuth('monitoring'), (_req: DevAuthRequest, res: Response) => {
    const mem = process.memoryUsage();
    const storeBytes = fs.existsSync(STORE_FILE) ? fs.statSync(STORE_FILE).size : 0;
    const backupFiles = fs.existsSync(BACKUP_DIR) ? fs.readdirSync(BACKUP_DIR) : [];
    const backupBytes = backupFiles.reduce((sum, f) => {
      const fp = path.resolve(BACKUP_DIR, f);
      return fp.startsWith(BACKUP_DIR + path.sep) && fs.existsSync(fp) ? sum + fs.statSync(fp).size : sum;
    }, 0);

    const totalAiCalls = store.aiServices.reduce((s, x) => s + x.successCount + x.failedCount, 0);
    const totalLatency = store.aiServices.reduce((s, x) => s + x.totalLatencyMs, 0);
    const totalErrors = store.aiServices.reduce((s, x) => s + x.failedCount, 0);

    res.json({
      services: [
        { name: 'Express Backend API', status: 'healthy', latencyMs: 12, detail: `Node ${process.version} · PID ${process.pid}` },
        {
          name: 'Firestore & Firebase Auth',
          status: 'healthy',
          latencyMs: 45,
          detail: 'ID Token Verifier + Client Rules active',
        },
        {
          name: 'Operational Control Store',
          status: 'healthy',
          latencyMs: 2,
          detail: `${(storeBytes / 1024).toFixed(1)} KB persisted`,
        },
        {
          name: 'Gemini AI Gateway',
          status: process.env.GEMINI_API_KEY ? 'healthy' : 'degraded',
          latencyMs: totalAiCalls > 0 ? Math.round(totalLatency / totalAiCalls) : 0,
          detail: process.env.GEMINI_API_KEY ? 'API Key active (server-side)' : 'Missing GEMINI_API_KEY secret',
        },
        {
          name: 'Notification & Queue Dispatcher',
          status: 'healthy',
          latencyMs: 4,
          detail: `${store.notifications.length} dispatches recorded`,
        },
      ],
      system: {
        uptimeSeconds: Math.round(process.uptime()),
        rssMb: Math.round(mem.rss / (1024 * 1024)),
        heapUsedMb: Math.round(mem.heapUsed / (1024 * 1024)),
        cpuLoad: os.loadavg().map((n) => Number(n.toFixed(2))),
        storageUsedBytes: storeBytes + backupBytes,
        totalAiErrors: totalErrors,
      },
      recentErrors: store.telemetryEvents.filter((e) => e.type === 'error').slice(0, 20),
    });
  });

  // 11. Immutable Audit Logs (Read-only!)
  app.get('/api/dev/audit-logs', requireDevAuth('audit_logs'), (_req: DevAuthRequest, res: Response) => {
    res.json({ auditLogs: store.auditLogs });
  });

  // 12. Backup & Recovery (Strict Path Confinement + Owner Confirmation)
  app.get('/api/dev/backups', requireDevAuth('backups'), (_req: DevAuthRequest, res: Response) => {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const files = fs
      .readdirSync(BACKUP_DIR)
      .filter((f) => f.endsWith('.json'))
      .sort()
      .reverse();
    const backups: BackupSnapshotInfo[] = files.map((file) => {
      const id = file.replace(/\.json$/, '');
      const fullPath = path.resolve(BACKUP_DIR, file);
      const stat = fs.statSync(fullPath);
      return {
        id,
        label: id,
        sizeBytes: stat.size,
        createdBy: 'Owner',
        createdAt: stat.mtime.toISOString(),
      };
    });
    res.json({
      backups,
      schedule: store.appSettings.backupSchedule,
      retentionCount: store.appSettings.retentionCount,
    });
  });

  app.post('/api/dev/backups', requireDevAuth('backups'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const id = `backup_${stamp}`;
    const targetPath = path.resolve(BACKUP_DIR, `${id}.json`);
    if (!targetPath.startsWith(BACKUP_DIR + path.sep)) {
      res.status(400).json({ error: 'Invalid backup path.' });
      return;
    }
    // Redact credential hashes in downloadable/portable backups unless needed internally
    const snapshot = {
      ...store,
      exportedAt: new Date().toISOString(),
    };
    fs.writeFileSync(targetPath, JSON.stringify(snapshot, null, 2), 'utf-8');

    // Enforce retention policy
    const all = fs
      .readdirSync(BACKUP_DIR)
      .filter((f) => f.endsWith('.json'))
      .sort()
      .reverse();
    const maxKeep = Math.max(2, store.appSettings.retentionCount || 10);
    for (const oldFile of all.slice(maxKeep)) {
      const oldPath = path.resolve(BACKUP_DIR, oldFile);
      if (oldPath.startsWith(BACKUP_DIR + path.sep)) fs.unlinkSync(oldPath);
    }

    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'backup_created',
      target: id,
      details: `Saved snapshot (${fs.statSync(targetPath).size} bytes)`,
    });
    res.json({ ok: true, id });
  });

  app.get('/api/dev/backups/:id/download', requireDevAuth('backups'), (req: DevAuthRequest, res: Response) => {
    const cleanId = req.params.id.replace(/[^a-zA-Z0-9_-]/g, '');
    const targetPath = path.resolve(BACKUP_DIR, `${cleanId}.json`);
    if (!targetPath.startsWith(BACKUP_DIR + path.sep) || !fs.existsSync(targetPath)) {
      res.status(404).json({ error: 'Backup not found.' });
      return;
    }
    const raw = JSON.parse(fs.readFileSync(targetPath, 'utf-8')) as ControlCenterStore;
    // Never export passwordHash or totpSecret to client download
    const safeExport = {
      ...raw,
      adminAccounts: (raw.adminAccounts || []).map(sanitizeAdminPublic),
    };
    res.setHeader('Content-Disposition', `attachment; filename="${cleanId}.json"`);
    res.json(safeExport);
  });

  app.post('/api/dev/backups/:id/restore', requireDevAuth('backups'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    if (devUser.role !== 'owner') {
      res.status(403).json({ error: 'Only Owner can restore database snapshots.' });
      return;
    }
    const cleanId = req.params.id.replace(/[^a-zA-Z0-9_-]/g, '');
    const targetPath = path.resolve(BACKUP_DIR, `${cleanId}.json`);
    if (!targetPath.startsWith(BACKUP_DIR + path.sep) || !fs.existsSync(targetPath)) {
      res.status(404).json({ error: 'Backup snapshot not found.' });
      return;
    }
    const restored = JSON.parse(fs.readFileSync(targetPath, 'utf-8')) as ControlCenterStore;
    // Preserve live admin credentials/sessions so Owner isn't locked out
    const liveAdmins = store.adminAccounts;
    store = {
      ...createInitialStore(),
      ...restored,
      adminAccounts: liveAdmins,
    };
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'backup_restored',
      target: cleanId,
      details: 'Restored platform configuration & data snapshot',
    });
    res.json({ ok: true });
  });

  // 13. App Settings
  app.get('/api/dev/settings', requireDevAuth('app_settings'), (_req: DevAuthRequest, res: Response) => {
    res.json({ appSettings: store.appSettings });
  });

  app.put('/api/dev/settings', requireDevAuth('app_settings'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const b = req.body || {};
    store.appSettings = {
      ...store.appSettings,
      appName: String(b.appName ?? store.appSettings.appName).slice(0, 80),
      appDescription: String(b.appDescription ?? store.appSettings.appDescription).slice(0, 300),
      logoUrl: String(b.logoUrl ?? store.appSettings.logoUrl).slice(0, 300),
      officialEmail: String(b.officialEmail ?? store.appSettings.officialEmail).slice(0, 120),
      socialWebsite: String(b.socialWebsite ?? store.appSettings.socialWebsite).slice(0, 200),
      socialTwitter: String(b.socialTwitter ?? store.appSettings.socialTwitter).slice(0, 200),
      socialTelegram: String(b.socialTelegram ?? store.appSettings.socialTelegram).slice(0, 200),
      privacyPolicyText: String(b.privacyPolicyText ?? store.appSettings.privacyPolicyText).slice(0, 4000),
      termsOfServiceText: String(b.termsOfServiceText ?? store.appSettings.termsOfServiceText).slice(0, 4000),
      androidStoreUrl: String(b.androidStoreUrl ?? store.appSettings.androidStoreUrl).slice(0, 300),
      iosStoreUrl: String(b.iosStoreUrl ?? store.appSettings.iosStoreUrl).slice(0, 300),
      availableLanguages: Array.isArray(b.availableLanguages) ? b.availableLanguages : store.appSettings.availableLanguages,
      maxFileSizeMb: Math.max(1, Math.min(200, Number(b.maxFileSizeMb ?? store.appSettings.maxFileSizeMb))),
      maintenanceMode: Boolean(b.maintenanceMode ?? store.appSettings.maintenanceMode),
      minVersion: String(b.minVersion ?? store.appSettings.minVersion).slice(0, 24),
      forceUpdateMessage: String(b.forceUpdateMessage ?? store.appSettings.forceUpdateMessage).slice(0, 240),
      backupSchedule: ['manual', 'daily', 'weekly'].includes(b.backupSchedule)
        ? b.backupSchedule
        : store.appSettings.backupSchedule,
      retentionCount: Math.max(2, Math.min(50, Number(b.retentionCount ?? store.appSettings.retentionCount))),
    };
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'app_settings_updated',
      target: 'global_settings',
      details: `maintenanceMode=${store.appSettings.maintenanceMode}, maxFile=${store.appSettings.maxFileSizeMb}MB`,
    });
    res.json({ appSettings: store.appSettings });
  });

  // 14. Admin Roles RBAC Management (Owner Only)
  app.get('/api/dev/roles', requireDevAuth('profile'), (_req: DevAuthRequest, res: Response) => {
    res.json({ accounts: store.adminAccounts.map(sanitizeAdminPublic) });
  });

  app.post('/api/dev/roles', requireDevAuth('manage_roles'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const { email, displayName, role = 'support', password, permissions } = req.body || {};
    const cleanEmail = String(email || '').trim().toLowerCase();
    if (!cleanEmail || !password || String(password).length < 8) {
      res.status(400).json({ error: 'Valid email and password (8+ chars) are required.' });
      return;
    }
    if (!['admin', 'support', 'content_manager'].includes(role)) {
      res.status(400).json({ error: 'Allowed sub-roles: admin, support, content_manager.' });
      return;
    }
    if (store.adminAccounts.some((a) => a.email.toLowerCase() === cleanEmail)) {
      res.status(409).json({ error: 'Account email already exists.' });
      return;
    }
    const acc: AdminAccountInternal = {
      id: `adm_${Date.now().toString(36)}`,
      email: cleanEmail,
      displayName: String(displayName || cleanEmail).slice(0, 100),
      role,
      permissions: Array.isArray(permissions) && permissions.length ? permissions : [...DEFAULT_ROLE_PERMISSIONS[role as AdminRoleType]],
      passwordHash: hashPassword(String(password)),
      mustChangePassword: true,
      twoFactorEnabled: false,
      totpSecret: null,
      sessionVersion: 1,
      createdAt: new Date().toISOString(),
    };
    store.adminAccounts.push(acc);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'admin_role_created',
      target: cleanEmail,
      details: `role=${role}`,
    });
    res.json({ accounts: store.adminAccounts.map(sanitizeAdminPublic) });
  });

  app.delete('/api/dev/roles/:id', requireDevAuth('manage_roles'), (req: DevAuthRequest, res: Response) => {
    const devUser = req.devUser!;
    const target = store.adminAccounts.find((a) => a.id === req.params.id);
    if (!target || target.role === 'owner') {
      res.status(403).json({ error: 'Cannot delete primary Owner account.' });
      return;
    }
    store.adminAccounts = store.adminAccounts.filter((a) => a.id !== req.params.id);
    saveStore();
    addAuditLog({
      actorEmail: devUser.email,
      actorRole: devUser.role,
      action: 'admin_role_removed',
      target: target.email,
      details: `Removed ${target.role}`,
    });
    res.json({ accounts: store.adminAccounts.map(sanitizeAdminPublic) });
  });
}
